#include "globe_engine.h"

#include <string.h>

#include "student_hooks.h"
#include "wrap_words.h"

GlobeEngine* activeEngine = NULL;

// Номери попереджень. Кожне друкується в Serial лише раз, щоб торкання
// не заливали монітор однаковим текстом.
static const uint8_t WARN_UNKNOWN_COUNTRY = 0;
static const uint8_t WARN_BAD_ROW = 1;
static const uint8_t WARN_TOO_LONG = 2;
static const uint8_t WARN_NOT_LATIN = 3;
static const uint8_t WARN_NO_TASK1 = 4;
static const uint8_t WARN_NO_BUTTON = 5;
static const uint8_t WARN_DIVISION = 6;
static const uint8_t WARN_TARGET_PHASE = 7;
static const uint8_t WARN_ASK_PHASE = 8;

static const uint8_t SCREEN_ROWS = 6;
// Як QUIZ_MAX_QUESTIONS у globe_core/hooks.py.
static const uint8_t QUIZ_MAX_QUESTIONS = 50;

static bool isLatinOnly(const String& text) {
  for (unsigned int index = 0; index < text.length(); ++index) {
    char symbol = text[index];
    if (symbol < 32 || symbol > 126) {
      return false;
    }
  }
  return true;
}

bool loadCountry(uint8_t index, Country& country) {
  if (index >= COUNTRY_COUNT) {
    return false;
  }
  CountryData data;
  memcpy_P(&data, &COUNTRIES[index], sizeof(CountryData));
  country.id = String((const __FlashStringHelper*)data.id);
  country.lcdName = String((const __FlashStringHelper*)data.lcdName);
  country.lcdCapital = String((const __FlashStringHelper*)data.lcdCapital);
  country.track = data.track;
  return true;
}

int8_t findCountryIndex(const char* countryId) {
  if (countryId == NULL) {
    return -1;
  }
  for (uint8_t index = 0; index < COUNTRY_COUNT; ++index) {
    CountryData data;
    memcpy_P(&data, &COUNTRIES[index], sizeof(CountryData));
    if (strcasecmp_P(countryId, data.id) == 0) {
      return (int8_t)index;
    }
  }
  return -1;
}

void printCountryIds() {
  for (uint8_t index = 0; index < COUNTRY_COUNT; ++index) {
    CountryData data;
    memcpy_P(&data, &COUNTRIES[index], sizeof(CountryData));
    if (index > 0) {
      Serial.print(F(", "));
    }
    Serial.print((const __FlashStringHelper*)data.id);
  }
  Serial.println();
}

GlobeEngine::GlobeEngine(GlobeDisplay& display, DFPlayerSpeaker& speaker)
    : _display(display),
      _speaker(speaker),
      _buttonCount(0),
      _quizPauseMs(1500),
      _gameRounds(5),
      _gameTimeoutMs(5000),
      _gamePauseMs(1500),
      _hooks(0),
      _mode(MODE_NORMAL),
      _phase(PHASE_NONE),
      _answer(-1),
      _expected(-1),
      _reading(false),
      _inFact(false),
      _number(0),
      _score(0),
      _round(0),
      _roundStarted(0),
      _warned(0) {
  for (uint8_t index = 0; index < COUNTRY_COUNT; ++index) {
    _pressCounts[index] = 0;
  }
  activeEngine = this;
}

void GlobeEngine::configure(uint8_t buttonCount, unsigned long quizPauseMs,
                            uint8_t gameRounds, unsigned long gameTimeoutMs,
                            unsigned long gamePauseMs, uint16_t hooksPresent) {
  _buttonCount = buttonCount;
  _quizPauseMs = quizPauseMs;
  _gameRounds = gameRounds;
  _gameTimeoutMs = gameTimeoutMs;
  _gamePauseMs = gamePauseMs;
  _hooks = hooksPresent;
}

bool GlobeEngine::has(uint8_t hook) const { return (_hooks >> hook) & 1; }

bool GlobeEngine::warnOnce(uint8_t code) {
  uint16_t mask = (uint16_t)1 << code;
  if (_warned & mask) {
    return false;
  }
  _warned |= mask;
  return true;
}

void GlobeEngine::warnNoTask1() {
  if (warnOnce(WARN_NO_TASK1)) {
    Serial.println(F("[увага] Немає task1.py (функції on_button) - кнопки ні до чого не підключені."));
  }
}

int8_t GlobeEngine::countryIndex(const String& countryId, const __FlashStringHelper* function) {
  int8_t index = findCountryIndex(countryId.c_str());
  if (index < 0 && warnOnce(WARN_UNKNOWN_COUNTRY)) {
    Serial.print(F("[увага] "));
    Serial.print(function);
    Serial.print(F("(\""));
    Serial.print(countryId);
    Serial.println(F("\"): немає такої країни."));
    Serial.print(F("         Є: "));
    printCountryIds();
  }
  return index;
}

void GlobeEngine::clearRows(uint8_t first, uint8_t last) {
  for (uint8_t row = first; row <= last; ++row) {
    _display.writeRow(row, String(""));
  }
}

void GlobeEngine::reportExpected() {
  CountryData data;
  memcpy_P(&data, &COUNTRIES[_expected], sizeof(CountryData));
  Serial.print(F("(загадано: "));
  Serial.print((const __FlashStringHelper*)data.id);
  Serial.println(F(")"));
}

// ---------------------------------------------------------------------------
// Запуск і торкання
// ---------------------------------------------------------------------------
void GlobeEngine::boot() {
  _display.clear();
  student_loading();
  if (has(HOOK_HELLO_SCREEN)) {
    student_hello_screen();
  } else {
    _display.clear();
    _display.writeRow(0, F("TouchTheGlobe"));
    _display.writeRow(2, F("Touch country!"));
  }
  if (!has(HOOK_ON_BUTTON)) {
    warnNoTask1();
  }
}

void GlobeEngine::touchButton(uint8_t number) {
  if (_mode == MODE_FINISHED) {
    _mode = MODE_NORMAL;
  }
  if (number < 1 || number > _buttonCount) {
    if (warnOnce(WARN_NO_BUTTON)) {
      Serial.print(F("[увага] Кнопки "));
      Serial.print(number);
      Serial.print(F(" немає: у settings.py їх "));
      Serial.println(_buttonCount);
    }
    return;
  }

  if (_mode == MODE_NORMAL) {
    if (!has(HOOK_ON_BUTTON)) {
      warnNoTask1();
      return;
    }
    student_on_button(number);
    return;
  }

  // Гра чи вікторина: on_button лише "показує", яку країну обрали. Малювати
  // й чекати він тим часом не може - щоб не стерти питання й не з'їсти час.
  _answer = -1;
  _reading = true;
  student_button_answer(number);
  if (_answer < 0) {
    student_on_button(number);
  }
  _reading = false;
  if (_answer < 0) {
    return;
  }
  if (_mode == MODE_QUIZ) {
    finishQuestion(_answer);
  } else {
    finishRound(_answer, millis() - _roundStarted);
  }
}

void GlobeEngine::stop() { _speaker.stop(); }

// ---------------------------------------------------------------------------
// Функції для коду учнів
// ---------------------------------------------------------------------------
void GlobeEngine::playSound(const String& countryId) {
  if (_mode == MODE_QUIZ || _mode == MODE_GAME) {
    return;
  }
  int8_t index = countryIndex(countryId, F("play_sound"));
  if (index < 0) {
    return;
  }
  _speaker.play(pgm_read_byte(&COUNTRIES[index].track));
}

void GlobeEngine::showCountry(const String& countryId) {
  int8_t index = countryIndex(countryId, F("show_country"));
  if (index < 0) {
    return;
  }
  if (_mode == MODE_QUIZ || _mode == MODE_GAME) {
    if (_answer < 0) {
      _answer = index;
    }
    return;
  }

  Country country;
  loadCountry((uint8_t)index, country);
  uint16_t count = ++_pressCounts[index];

  _display.clear();
  _display.writeRow(0, country.lcdName, true);
  _display.writeRow(1, country.lcdCapital);
  _display.writeRow(5, String("x") + count);

  Serial.print(F("Країна "));
  Serial.print(country.id);
  Serial.print(F(", торкань: "));
  Serial.println(count);

  // show_country() усередині show_fact() лише малює країну, а факт удруге
  // не викликає - інакше вони викликали б одна одну, доки не скінчиться стек.
  if (_inFact) {
    return;
  }
  _inFact = true;
  student_show_fact(country);
  _inFact = false;
}

void GlobeEngine::showText(long row, const String& text) {
  if (_reading) {
    return;
  }
  if (row < 0 || row >= SCREEN_ROWS) {
    if (warnOnce(WARN_BAD_ROW)) {
      Serial.print(F("[увага] show_text("));
      Serial.print(row);
      Serial.println(F(", ...): на екрані 6 рядків, від 0 до 5."));
    }
    return;
  }
  if (text.length() > LCD_WIDTH && warnOnce(WARN_TOO_LONG)) {
    Serial.print(F("[увага] show_text: '"));
    Serial.print(text);
    Serial.println(F("' довший за 14 символів - зайве обріжеться."));
  }
  if (!isLatinOnly(text) && warnOnce(WARN_NOT_LATIN)) {
    Serial.println(F("[увага] show_text: екран не показує українські літери, буде '?'."));
  }
  _display.writeRow((uint8_t)row, text);
}

void GlobeEngine::clearScreen() {
  if (_reading) {
    return;
  }
  _display.clear();
}

void GlobeEngine::blink(long times) {
  if (_reading || times <= 0) {
    return;
  }
  _display.blink(times > 255 ? 255 : (uint8_t)times);
}

void GlobeEngine::wait(long ms) {
  if (_reading) {
    return;
  }
  if (ms > 0) {
    delay((unsigned long)ms);
  }
}

long GlobeEngine::randomNumber(long low, long high) {
  if (high < low) {
    return low;
  }
  return random(low, high + 1);
}

void GlobeEngine::target(const String& countryId, const String& hint) {
  if (_phase != PHASE_TARGET) {
    if (warnOnce(WARN_TARGET_PHASE)) {
      Serial.println(F("[увага] target() працює лише всередині next_target()."));
    }
    return;
  }
  int8_t index = countryIndex(countryId, F("target"));
  if (index < 0) {
    return;
  }
  _expected = index;
  _display.writeRow(1, hint);
}

void GlobeEngine::ask(const String& text, const String& countryId) {
  if (_phase != PHASE_QUESTION) {
    if (warnOnce(WARN_ASK_PHASE)) {
      Serial.println(F("[увага] ask() працює лише всередині question()."));
    }
    return;
  }
  int8_t index = countryIndex(countryId, F("ask"));
  if (index < 0) {
    return;
  }
  _expected = index;
  String lines[3];
  uint8_t count = wrapWords(text, lines, 3, LCD_WIDTH);
  for (uint8_t row = 0; row < count; ++row) {
    _display.writeRow(row, lines[row]);
  }
}

void GlobeEngine::loopStuck(const __FlashStringHelper* file, int line) {
  Serial.print(F("[увага] "));
  Serial.print(file);
  Serial.print(F(", рядок "));
  Serial.print(line);
  Serial.println(F(": схоже, while ніколи не закінчиться - перевір умову."));
}

void GlobeEngine::divisionByZero() {
  if (warnOnce(WARN_DIVISION)) {
    Serial.println(F("[увага] Ділення на нуль - результат буде 0."));
  }
}

// ---------------------------------------------------------------------------
// Вікторина (task3)
// ---------------------------------------------------------------------------
void GlobeEngine::touchQuiz() {
  if (_mode == MODE_QUIZ || _mode == MODE_GAME) {
    return;
  }
  _number = 1;
  _score = 0;
  nextQuestion();
}

void GlobeEngine::nextQuestion() {
  _display.clear();
  _expected = -1;
  _phase = PHASE_QUESTION;
  if (_number <= QUIZ_MAX_QUESTIONS) {
    student_question(_number);
  }
  _phase = PHASE_NONE;

  if (_expected < 0) {
    if (_number == 1) {
      _display.clear();
      _display.writeRow(2, F("No questions"));
      _mode = MODE_NORMAL;
      if (!has(HOOK_QUESTION)) {
        Serial.println(F("[увага] Немає task3.py - вікторині нема що питати."));
      }
      return;
    }
    quizFinal();
    return;
  }
  _mode = MODE_QUIZ;
  reportExpected();
}

void GlobeEngine::finishQuestion(int8_t answer) {
  bool correct = answer == _expected;
  if (correct) {
    _score++;
  }
  clearRows(3, 5);
  _display.writeRow(5, String("Score: ") + _score + "/" + _number);
  student_on_answer(correct, _score);
  if (_quizPauseMs > 0) {
    delay(_quizPauseMs);
  }
  _number++;
  nextQuestion();
}

void GlobeEngine::quizFinal() {
  uint8_t total = _number - 1;
  _display.clear();
  student_final(_score, total);
  _display.writeRow(5, String("Score: ") + _score + "/" + total);
  _mode = MODE_FINISHED;
}

// ---------------------------------------------------------------------------
// «Блискавка» (task2)
// ---------------------------------------------------------------------------
void GlobeEngine::touchGame() {
  if (_mode == MODE_QUIZ || _mode == MODE_GAME) {
    return;
  }
  _display.clear();
  _display.writeRow(1, F("Ready?"));
  for (uint8_t count = 3; count >= 1; --count) {
    _display.writeRow(2, String(count));
    delay(500);
  }
  _round = 1;
  _score = 0;
  startRound();
}

void GlobeEngine::startRound() {
  _display.clear();
  _display.writeRow(0, String("Round ") + _round + "/" + _gameRounds);
  _display.writeRow(5, String("Score: ") + _score);
  _expected = -1;
  _phase = PHASE_TARGET;
  student_next_target(_round);
  _phase = PHASE_NONE;

  if (_expected < 0) {
    if (_round == 1) {
      _display.clear();
      _display.writeRow(2, F("No game"));
      _mode = MODE_NORMAL;
      if (!has(HOOK_NEXT_TARGET)) {
        Serial.println(F("[увага] Немає task2.py - грі «Блискавка» нема що загадувати."));
      }
      return;
    }
    gameOver();
    return;
  }
  _mode = MODE_GAME;
  reportExpected();
  _roundStarted = millis();
}

void GlobeEngine::finishRound(int8_t answer, unsigned long ms) {
  bool correct = answer >= 0 && answer == _expected;
  if (ms > _gameTimeoutMs) {
    correct = false;
    ms = _gameTimeoutMs;
  }
  if (correct) {
    _score++;
  }
  clearRows(3, 4);
  _display.writeRow(5, String("Score: ") + _score);
  student_on_hit(correct, (long)ms);
  if (_gamePauseMs > 0) {
    delay(_gamePauseMs);
  }
  if (_round < _gameRounds) {
    _round++;
    startRound();
  } else {
    gameOver();
  }
}

void GlobeEngine::tick() {
  if (_mode == MODE_GAME && millis() - _roundStarted > _gameTimeoutMs) {
    finishRound(-1, _gameTimeoutMs);
  }
}

void GlobeEngine::gameOver() {
  _display.clear();
  student_game_over(_score, _gameRounds);
  _display.writeRow(5, String("Score: ") + _score + "/" + _gameRounds);
  _mode = MODE_FINISHED;
}
