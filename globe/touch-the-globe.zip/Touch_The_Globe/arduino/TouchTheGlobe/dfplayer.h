// Аудіомодуль DFPlayer Mini: грає mp3 з microSD.
//
// Модуль розуміє короткі команди по послідовному порту. Кожна команда -
// це рівно 10 байтів:
//
//     0x7E  початок
//     0xFF  версія протоколу
//     0x06  довжина
//     CMD   що зробити (наприклад 0x0F - "грай трек із папки")
//     0x00  чи потрібне підтвердження
//     DH    старший байт числа-параметра
//     DL    молодший байт числа-параметра
//     CS_H  контрольна сума
//     CS_L
//     0xEF  кінець
//
// Контрольна сума потрібна, щоб модуль не виконав команду, яка зіпсувалася
// дорогою по дроту. Через це власна бібліотека тут не потрібна: увесь
// протокол - це десяток байтів, і краще бачити їх, ніж ховати.

#ifndef DFPLAYER_H
#define DFPLAYER_H

#include <Arduino.h>
#include <SoftwareSerial.h>

// Команди DFPlayer Mini
const uint8_t CMD_PLAY_TRACK = 0x03;
const uint8_t CMD_SET_VOLUME = 0x06;
const uint8_t CMD_SELECT_DEVICE = 0x09;
const uint8_t CMD_RESET = 0x0C;
const uint8_t CMD_PAUSE = 0x0E;
const uint8_t CMD_PLAY_FOLDER = 0x0F;
const uint8_t CMD_STOP = 0x16;

const uint8_t DEVICE_SD = 0x02;

const uint8_t MAX_VOLUME = 30;
const long DFPLAYER_BAUDRATE = 9600;
const uint8_t FRAME_SIZE = 10;

// Складає ті самі 10 байтів, про які написано вище.
//
// Контрольна сума - це від'ємна сума байтів від "версії" до "DL"
// включно. Саме так її рахує офіційна бібліотека DFRobotDFPlayerMini.
// У PDF-інструкції до модуля приклади сум надруковані з помилкою.
void buildFrame(uint8_t command, uint16_t parameter, uint8_t* frame,
                bool feedback = false);

class DFPlayer {
 public:
  explicit DFPlayer(SoftwareSerial& serial);

  // Готує модуль: перезапуск, вибір SD-картки, гучність.
  // Після перезапуску модуль близько двох секунд читає картку - якщо
  // заговорити з ним раніше, він просто змовчить.
  void begin(uint8_t volume, uint8_t folder);

  void send(uint8_t command, uint16_t parameter = 0);
  void setVolume(uint8_t level);

  // Грає файл із нумерованої папки: 01/003.mp3 - це folder=1, track=3.
  // Повертає false, якщо номери виходять за межі, які модуль розуміє.
  bool playFolder(uint8_t folder, uint8_t track);

  void stop();

  uint8_t folder() const { return _folder; }
  uint8_t volume() const { return _volume; }

 private:
  SoftwareSerial& _serial;
  uint8_t _volume;
  uint8_t _folder;
};

// Перекладач між движком глобуса і DFPlayer.
//
// Движок передає номер треку, а тут він перетворюється на команду
// "грай файл із папки 01".
//
// Сказати довільний текст цей "динамік" не вміє, і це не забудькуватість:
// DFPlayer грає лише заздалегідь записані файли. Саме тому сюрприз з
// onRepeatPress() на платі видно на дисплеї, але не чути.
class DFPlayerSpeaker {
 public:
  DFPlayerSpeaker();

  void attach(DFPlayer* player);
  bool ready() const { return _player != NULL; }

  void play(uint8_t track);
  void stop();

 private:
  DFPlayer* _player;
};

#endif  // DFPLAYER_H
