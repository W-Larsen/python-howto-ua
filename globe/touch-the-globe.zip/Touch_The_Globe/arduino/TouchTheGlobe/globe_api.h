// Функції, які викликає код учнів (той самий набір, що в globe_core/hooks.py).
//
// Назви навмисно такі самі, як у Python: перекладач нічого не перейменовує,
// і згенерований student_code.h легко читати поруч з task*.py.

#ifndef GLOBE_API_H
#define GLOBE_API_H

#include <Arduino.h>

#include "country.h"
#include "py_ops.h"

void play_sound(const String& countryId);
void show_country(const String& countryId);
void show_text(long row, const String& text);
void clear_screen();
void blink(long times);
void wait(long ms);
long random_number(long low, long high);
void target(const String& countryId, const String& hint);
void ask(const String& text, const String& countryId);

// while повторився забагато разів (див. LOOP_LIMIT у globe_core/hooks.py).
void globe_loop_stuck(const __FlashStringHelper* file, int line);

#endif  // GLOBE_API_H
