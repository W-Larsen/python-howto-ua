// Хуки - функції, які пишуть учні, а викликає глобус.
//
// Самі функції генерує tools/build_student_code.py у student_code.h.
// Тут лише їхні оголошення, щоб ядро (globe_engine.cpp) могло їх
// викликати. Порядок HOOK_* - той самий, що HOOK_LIST у globe_core/hooks.py.

#ifndef STUDENT_HOOKS_H
#define STUDENT_HOOKS_H

#include <Arduino.h>

#include "country.h"

enum StudentHook {
  HOOK_ON_BUTTON,
  HOOK_HELLO_SCREEN,
  HOOK_NEXT_TARGET,
  HOOK_ON_HIT,
  HOOK_GAME_OVER,
  HOOK_QUESTION,
  HOOK_ON_ANSWER,
  HOOK_FINAL,
  HOOK_SHOW_FACT,
  HOOK_LOADING
};

void student_on_button(long number);
void student_hello_screen();
void student_next_target(long roundNumber);
void student_on_hit(bool correct, long ms);
void student_game_over(long score, long rounds);
void student_question(long number);
void student_on_answer(bool correct, long score);
void student_final(long score, long total);
void student_show_fact(const Country& country);
void student_loading();

// Країна кнопки за таблицею вчителя (BUTTON_COUNTRIES у settings.py): згенерована
// функція викликає show_country() для кнопки. Ядро кличе її в грі й вікторині перед
// on_button; порожня, якщо таблиці немає.
void student_button_answer(long number);

// Біт HOOK_* увімкнений, якщо учень цей хук написав.
uint16_t student_hooks_present();

#endif  // STUDENT_HOOKS_H
