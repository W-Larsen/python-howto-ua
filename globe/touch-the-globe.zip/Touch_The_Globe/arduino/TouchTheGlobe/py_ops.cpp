#include "py_ops.h"

long py_div(long a, long b) {
  if (b == 0) {
    globe_warn_division_by_zero();
    return 0;
  }
  long quotient = a / b;
  // C++ округлює до нуля. Якщо знаки різні й ділиться не націло -
  // Python узяв би на одиницю менше.
  if ((a % b != 0) && ((a < 0) != (b < 0))) {
    quotient -= 1;
  }
  return quotient;
}

long py_mod(long a, long b) {
  if (b == 0) {
    globe_warn_division_by_zero();
    return 0;
  }
  long remainder = a % b;
  // У Python знак остачі - як у дільника.
  if (remainder != 0 && ((remainder < 0) != (b < 0))) {
    remainder += b;
  }
  return remainder;
}

String py_str(long value) { return String(value); }

String py_str_bool(bool value) { return value ? String("True") : String("False"); }
