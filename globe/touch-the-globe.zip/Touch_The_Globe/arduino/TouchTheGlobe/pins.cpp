#include "pins.h"

static const uint8_t LAST_DIGITAL_PIN = 13;
static const uint8_t LAST_ANALOG_PIN = 5;

// Читає число після літери: "D12" -> 12. Повертає -1, якщо там не число.
static int8_t parseNumber(const char* text) {
  if (*text == '\0') {
    return -1;
  }

  int value = 0;
  for (const char* cursor = text; *cursor != '\0'; ++cursor) {
    if (*cursor < '0' || *cursor > '9') {
      return -1;
    }
    value = value * 10 + (*cursor - '0');
    if (value > 99) {
      return -1;
    }
  }
  return (int8_t)value;
}

int8_t pinFromLabel(const char* label) {
  if (label == NULL) {
    return PIN_UNKNOWN;
  }

  while (*label == ' ') {
    ++label;
  }
  if (*label == '\0') {
    return PIN_UNKNOWN;
  }

  char first = toupper(label[0]);

  if (first == 'D') {
    int8_t number = parseNumber(label + 1);
    if (number < 0 || number > (int8_t)LAST_DIGITAL_PIN) {
      return PIN_UNKNOWN;
    }
    return number;
  }

  if (first == 'A') {
    int8_t number = parseNumber(label + 1);
    if (number < 0 || number > (int8_t)LAST_ANALOG_PIN) {
      return PIN_UNKNOWN;
    }
    return (int8_t)(A0 + number);
  }

  // Учень міг написати просто число: "5".
  int8_t number = parseNumber(label);
  if (number >= 0 && number <= (int8_t)(A0 + LAST_ANALOG_PIN)) {
    return number;
  }

  return PIN_UNKNOWN;
}

uint8_t pinOrDefault(const char* label, uint8_t fallback) {
  int8_t number = pinFromLabel(label);
  return number == PIN_UNKNOWN ? fallback : (uint8_t)number;
}
