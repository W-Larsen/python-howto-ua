#include "wrap_words.h"

uint8_t wrapWords(const String& text, String* lines, uint8_t maxLines, uint8_t width) {
  uint8_t count = 0;
  String current;
  unsigned int length = text.length();
  unsigned int index = 0;

  while (index <= length && count < maxLines) {
    int space = text.indexOf(' ', index);
    unsigned int end = space < 0 ? length : (unsigned int)space;
    String word = text.substring(index, end);
    index = end + 1;

    while (word.length() > width && count < maxLines) {
      if (current.length() > 0) {
        lines[count++] = current;
        current = "";
        if (count >= maxLines) {
          break;
        }
      }
      lines[count++] = word.substring(0, width);
      word = word.substring(width);
    }
    if (word.length() == 0 || count >= maxLines) {
      continue;
    }
    if (current.length() == 0) {
      current = word;
    } else if (current.length() + 1 + word.length() <= width) {
      current += ' ';
      current += word;
    } else {
      lines[count++] = current;
      current = word;
    }
  }
  if (current.length() > 0 && count < maxLines) {
    lines[count++] = current;
  }
  return count;
}
