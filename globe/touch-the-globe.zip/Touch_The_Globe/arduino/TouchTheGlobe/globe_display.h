// Дисплей Nokia 5110 - той самий екран, що стояв у старих телефонах.
//
// Це графічний екран 84 на 48 точок. Для коду учнів він - 6 рядків по
// 14 символів (рівно як рамка в консолі на комп'ютері): рядок 0 угорі,
// рядок 5 унизу. Усю роботу з точками бере на себе бібліотека
// Adafruit_PCD8544, а тут лишається головне - що в якому рядку.
//
// Контраст задає число LCD_CONTRAST у hardware_pins.h.

#ifndef GLOBE_DISPLAY_H
#define GLOBE_DISPLAY_H

#include <Adafruit_GFX.h>
#include <Adafruit_PCD8544.h>
#include <Arduino.h>

// Скільки символів вміщає один рядок: 84 точки / 6 на літеру = 14.
// Те саме число, що LCD_WIDTH у globe_core/catalog.py на комп'ютері.
const uint8_t LCD_WIDTH = 14;

class GlobeDisplay {
 public:
  GlobeDisplay(Adafruit_PCD8544& lcd, uint8_t columns, uint8_t rows);

  void begin(uint8_t contrast);
  void useBacklight(const char* pinLabel, bool activeLow);
  void backlight(bool on);

  // Пише рядок 0-5: зайве обрізає, кирилицю замінює на '?'.
  // inverted - білим по чорному (так глобус малює назву країни).
  void writeRow(uint8_t row, const String& text, bool inverted = false);

  // Два рядки тексту - для запуску й повідомлень про помилки.
  void message(const String& lineOne, const String& lineTwo = String(""));

  void clear();

  // Мигає підсвіткою. Якщо підсвіткою не керуємо - перевертає екран,
  // щоб мигання все одно було видно.
  void blink(uint8_t times);

  uint8_t columns() const { return _columns; }
  uint8_t rows() const { return _rows; }

 private:
  void writeAt(int16_t x, int16_t y, const String& text, uint8_t limit);

  Adafruit_PCD8544& _lcd;
  uint8_t _columns;
  uint8_t _rows;
  int8_t _backlightPin;
  bool _backlightActiveLow;
};

#endif  // GLOBE_DISPLAY_H
