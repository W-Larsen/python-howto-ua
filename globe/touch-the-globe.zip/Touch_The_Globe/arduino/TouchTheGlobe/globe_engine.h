// Мозок програми: торкнулися сенсора -> код учнів -> екран і звук.
//
// Це той самий порядок дій, що й у версії для комп'ютера
// (globe_core/engine.py): звичайний режим, вікторина (task3) і гра
// «Блискавка» (task2). Код учнів (student_code.h, згенерований з
// students/task*.py) викликає функції з globe_api.h, а вони - методи
// цього класу.
//
// Одна чесна різниця з Python: там будь-яку помилку в коді учня можна
// перехопити. У C++ - ні, тому ядро перевіряє те, що прийшло (рядок,
// країна, довжина тексту), і пише підказки в Serial.

#ifndef GLOBE_ENGINE_H
#define GLOBE_ENGINE_H

#include <Arduino.h>

#include "countries.h"
#include "country.h"
#include "dfplayer.h"
#include "globe_display.h"

// Дістає країну з флеша. Повертає false, якщо такого номера немає.
bool loadCountry(uint8_t index, Country& country);

// Шукає країну за ID, не зважаючи на великі й малі літери. -1, якщо немає.
int8_t findCountryIndex(const char* countryId);

// Друкує в Serial усі наявні ID - щоб було видно, з чого вибирати.
void printCountryIds();

class GlobeEngine {
 public:
  GlobeEngine(GlobeDisplay& display, DFPlayerSpeaker& speaker);

  // Значення з settings.py і які хуки написали учні (student_hooks_present).
  void configure(uint8_t buttonCount, unsigned long quizPauseMs, uint8_t gameRounds,
                 unsigned long gameTimeoutMs, unsigned long gamePauseMs,
                 uint16_t hooksPresent);

  void boot();
  void touchButton(uint8_t number);
  void touchQuiz();
  void touchGame();
  // Чи не вийшов час раунду гри. Викликається щоразу в loop().
  void tick();
  void stop();

  // --- те, що викликає код учнів (через globe_api.cpp) ---
  void playSound(const String& countryId);
  void showCountry(const String& countryId);
  void showText(long row, const String& text);
  void clearScreen();
  void blink(long times);
  void wait(long ms);
  long randomNumber(long low, long high);
  void target(const String& countryId, const String& hint);
  void ask(const String& text, const String& countryId);
  void loopStuck(const __FlashStringHelper* file, int line);
  void divisionByZero();

 private:
  enum Mode { MODE_NORMAL, MODE_QUIZ, MODE_GAME, MODE_FINISHED };
  enum Phase { PHASE_NONE, PHASE_TARGET, PHASE_QUESTION };

  bool has(uint8_t hook) const;
  bool warnOnce(uint8_t code);
  void warnNoTask1();
  int8_t countryIndex(const String& countryId, const __FlashStringHelper* function);
  void clearRows(uint8_t first, uint8_t last);
  void reportExpected();

  void nextQuestion();
  void finishQuestion(int8_t answer);
  void quizFinal();
  void startRound();
  void finishRound(int8_t answer, unsigned long ms);
  void gameOver();

  GlobeDisplay& _display;
  DFPlayerSpeaker& _speaker;
  uint8_t _buttonCount;
  unsigned long _quizPauseMs;
  uint8_t _gameRounds;
  unsigned long _gameTimeoutMs;
  unsigned long _gamePauseMs;
  uint16_t _hooks;

  Mode _mode;
  Phase _phase;
  int8_t _answer;    // яку країну показав on_button у грі (-1 - жодної)
  int8_t _expected;  // загадана країна (-1 - жодної)
  // Читаємо відповідь у грі чи вікторині: show_text, clear_screen, blink і
  // wait тоді нічого не роблять (як _probing у globe_core/engine.py).
  bool _reading;
  // Уже всередині show_fact(): show_country() звідти не викликає її знову.
  bool _inFact;
  uint8_t _number;   // номер питання вікторини
  uint8_t _score;
  uint8_t _round;
  unsigned long _roundStarted;
  uint16_t _warned;
  uint16_t _pressCounts[COUNTRY_COUNT];
};

// Ядро, з яким працюють функції з globe_api.h.
extern GlobeEngine* activeEngine;

#endif  // GLOBE_ENGINE_H
