// Touch The Globe - глобус, який розповідає про країни.
//
// Плата: Arduino Uno. Схема - у docs/wiring.md.
//
// Порядок дій той самий, що й у версії для комп'ютера: торкнулися
// сенсора -> код учнів (students/task*.py, перекладений у C++) вирішує,
// що показати й програти. Кнопки вікторини й гри обробляє ядро.
//
// Файли скетча:
//     student_code.h    <- ЗГЕНЕРОВАНО з settings.py і students/ (make build)
//     hardware_pins.h   <- піни дисплея й аудіомодуля
//     countries.h       <- країни; складається автоматично, не редагувати
//     globe_engine.*    <- ядро: те саме, що globe_core/engine.py
//     globe_api.*       <- функції, які викликає код учнів
//     py_ops.*          <- ділення й остача "як у Python"
//     wrap_words.*      <- текст питання -> рядки екрана
//     student_hooks.h   <- оголошення функцій учнів
//     country.h         <- одна країна
//     globe_display.*   <- дисплей
//     dfplayer.*        <- аудіомодуль
//     buttons.*         <- сенсорні кнопки
//     pins.*            <- "A0" -> номер піна
//     check_hardware.*  <- покрокова перевірка заліза
//
// Serial Monitor (швидкість 9600): help, list, press 1, press q, press g,
// play UA, check, stop.

#include <Adafruit_GFX.h>
#include <Adafruit_PCD8544.h>
#include <SoftwareSerial.h>

#include "buttons.h"
#include "check_hardware.h"
#include "countries.h"
#include "dfplayer.h"
#include "globe_display.h"
#include "globe_engine.h"
#include "hardware_pins.h"
#include "pins.h"
#include "student_code.h"

// Дисплей: п'ять дротів, назви яких взяті з hardware_pins.h. Порядок
// у дужках бібліотечний: Clk, Din, DC, CE, RST.
Adafruit_PCD8544 lcd(pinOrDefault(LCD_CLK, 6), pinOrDefault(LCD_DIN, 5),
                     pinOrDefault(LCD_DC, 4), pinOrDefault(LCD_CE, 3),
                     pinOrDefault(LCD_RST, 2));
GlobeDisplay display(lcd, LCD_COLUMNS, LCD_ROWS);

// Аудіомодуль. Порядок пінів у SoftwareSerial - спочатку той, яким плата
// слухає, потім той, яким говорить.
SoftwareSerial dfSerial(pinOrDefault(DFPLAYER_RX, 9), pinOrDefault(DFPLAYER_TX, 8));
DFPlayer player(dfSerial);
DFPlayerSpeaker speaker;

TouchPanel panel;
GlobeEngine engine(display, speaker);

const uint8_t POLL_INTERVAL_MS = 20;
const uint8_t COMMAND_LENGTH = 24;

// Усі сенсори одним списком: спершу кнопки країн, потім вікторина і гра.
const char* panelPins[MAX_BUTTONS];
uint8_t panelCount = 0;

void collectPanelPins() {
  panelCount = 0;
  for (uint8_t index = 0; index < BUTTON_COUNT && panelCount < MAX_BUTTONS - 2; ++index) {
    panelPins[panelCount++] = BUTTON_PINS[index];
  }
  panelPins[panelCount++] = QUIZ_PIN;
  panelPins[panelCount++] = GAME_PIN;
}

// Шум з аналогових пінів, до яких не підключено сенсора. Пін сенсора
// брати не можна: TTP223 тримає лінію, і з неї завжди читається те саме.
unsigned long seedNoise = 0;

bool isSensorPin(uint8_t pin) {
  for (uint8_t index = 0; index < panelCount; ++index) {
    if (pinFromLabel(panelPins[index]) == (int8_t)pin) {
      return true;
    }
  }
  return false;
}

unsigned long readFreeAnalogNoise() {
  unsigned long noise = 0;
  for (uint8_t pin = A0; pin <= A5; ++pin) {
    if (!isSensorPin(pin)) {
      noise = (noise << 5) ^ (noise >> 27) ^ (unsigned long)analogRead(pin);
    }
  }
  return noise;
}

// Номер сенсора в списку -> що це за кнопка.
void touchSensor(uint8_t index) {
  if (index < BUTTON_COUNT) {
    engine.touchButton(index + 1);
  } else if (index == BUTTON_COUNT) {
    engine.touchQuiz();
  } else {
    engine.touchGame();
  }
}

void printBanner() {
  Serial.println(F("=== Touch The Globe ==="));
  Serial.print(F("Країн у пам'яті: "));
  Serial.println(COUNTRY_COUNT);
}

void printHelp() {
  Serial.println(F("Команди:"));
  Serial.println(F("  list       які країни є"));
  Serial.println(F("  press 1    ніби торкнулися кнопки 1 (q - вікторина, g - гра)"));
  Serial.println(F("  play UA    показати й розповісти про країну за її ID"));
  Serial.println(F("  check      покрокова перевірка заліза"));
  Serial.println(F("  stop       зупинити звук"));
}

void printCountryList() {
  for (uint8_t index = 0; index < COUNTRY_COUNT; ++index) {
    Country country;
    loadCountry(index, country);
    Serial.print(F("  трек "));
    Serial.print(country.track);
    Serial.print(F("  "));
    Serial.print(country.id);
    Serial.print(F("  "));
    Serial.print(country.lcdName);
    Serial.print(F(" / "));
    Serial.println(country.lcdCapital);
  }
}

void printSensors() {
  Serial.print(F("Сенсори: "));
  for (uint8_t index = 0; index < panel.count(); ++index) {
    if (index > 0) {
      Serial.print(F(", "));
    }
    if (index < BUTTON_COUNT) {
      Serial.print(index + 1);
    } else if (index == BUTTON_COUNT) {
      Serial.print(F("q"));
    } else {
      Serial.print(F("g"));
    }
    Serial.print(F("="));
    Serial.print(panel.label(index));
  }
  Serial.println();
}

void handleCommand(char* line) {
  char* argument = strchr(line, ' ');
  if (argument != NULL) {
    *argument = '\0';
    ++argument;
    while (*argument == ' ') {
      ++argument;
    }
  }

  if (strcasecmp(line, "help") == 0 || strcasecmp(line, "?") == 0) {
    printHelp();
  } else if (strcasecmp(line, "list") == 0) {
    printCountryList();
  } else if (strcasecmp(line, "press") == 0) {
    if (argument == NULL || *argument == '\0') {
      Serial.println(F("Після press напиши кнопку: press 1, press q або press g"));
    } else if (strcasecmp(argument, "q") == 0) {
      engine.touchQuiz();
    } else if (strcasecmp(argument, "g") == 0) {
      engine.touchGame();
    } else {
      int number = atoi(argument);
      if (number < 1) {
        Serial.println(F("Номер кнопки - це число від 1: press 1"));
      } else {
        engine.touchButton((uint8_t)number);
      }
    }
  } else if (strcasecmp(line, "play") == 0) {
    if (argument == NULL || *argument == '\0') {
      Serial.println(F("Після play напиши країну: play UA"));
    } else {
      engine.playSound(String(argument));
      engine.showCountry(String(argument));
    }
  } else if (strcasecmp(line, "check") == 0) {
#if ENABLE_HARDWARE_CHECK
    runHardwareCheck(display, panel, player, panelPins, panelCount);
#else
    Serial.println(F("Перевірку вимкнено (ENABLE_HARDWARE_CHECK 0): без неї влазить код учнів."));
    Serial.println(F("Див. docs/teacher_guide.md, розділ 5."));
#endif
  } else if (strcasecmp(line, "stop") == 0) {
    engine.stop();
    Serial.println(F("Звук зупинено."));
  } else {
    Serial.print(F("Незрозуміла команда: "));
    Serial.println(line);
    printHelp();
  }
}

// Збирає команду по літері, поки не прийде Enter.
void readSerialCommand() {
  static char buffer[COMMAND_LENGTH];
  static uint8_t length = 0;

  while (Serial.available() > 0) {
    char symbol = (char)Serial.read();
    if (symbol == '\n' || symbol == '\r') {
      if (length > 0) {
        buffer[length] = '\0';
        length = 0;
        handleCommand(buffer);
      }
      continue;
    }
    if (length < COMMAND_LENGTH - 1) {
      buffer[length++] = symbol;
    }
  }
}

void setup() {
  Serial.begin(9600);
  printBanner();

  display.begin(LCD_CONTRAST);
  display.useBacklight(LCD_BACKLIGHT, BACKLIGHT_ACTIVE_LOW);
  display.message(F("TouchTheGlobe"), F("starting..."));

  speaker.attach(&player);
  player.begin(DFPLAYER_VOLUME, DFPLAYER_FOLDER);

  engine.configure(BUTTON_COUNT, QUIZ_PAUSE_MS, GAME_ROUNDS, GAME_TIMEOUT_MS,
                   GAME_PAUSE_MS, student_hooks_present());

  collectPanelPins();
  if (!panel.begin(panelPins, panelCount, BUTTON_DEBOUNCE_MS, TOUCH_ACTIVE_HIGH)) {
    display.message(F("Pin error"), F("see Serial"));
    delay(2000);
  }

  // Шум на вільних аналогових пінах і час запуску - щоб random_number
  // щоразу давав інші числа. Якщо всі A0-A5 зайняті сенсорами, лишається
  // micros(), а справжню випадковість додасть перше торкання (див. loop).
  seedNoise = readFreeAnalogNoise();
  randomSeed(seedNoise ^ micros());
  printSensors();
  printHelp();

  engine.boot();
  Serial.println(F("Готово. Торкайся країн на глобусі."));
}

void loop() {
  int8_t index = panel.pressedNow();
  if (index >= 0) {
    // Мить, коли людина вперше торкнулася сенсора, справді випадкова -
    // від неї числа гри стають іншими після кожного ввімкнення.
    static bool seeded = false;
    if (!seeded) {
      randomSeed(micros() ^ seedNoise);
      seeded = true;
    }
    Serial.print(F("Торкання "));
    Serial.println(panel.label((uint8_t)index));
    touchSensor((uint8_t)index);
  }
  engine.tick();
  readSerialCommand();
  delay(POLL_INTERVAL_MS);
}
