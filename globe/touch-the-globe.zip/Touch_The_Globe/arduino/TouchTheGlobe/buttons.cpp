#include "buttons.h"

#include "pins.h"

TouchPanel::TouchPanel()
    : _labels(NULL), _count(0), _debounceMs(200), _activeHigh(true) {}

bool TouchPanel::begin(const char* const* labels, uint8_t count, uint16_t debounceMs,
                       bool activeHigh) {
  _labels = labels;
  _count = count < MAX_BUTTONS ? count : MAX_BUTTONS;
  _debounceMs = debounceMs;
  _activeHigh = activeHigh;

  bool everythingIsFine = true;

  if (count > MAX_BUTTONS) {
    Serial.print(F("[увага] Сенсорів "));
    Serial.print(count);
    Serial.print(F(", а програма бере лише "));
    Serial.println(MAX_BUTTONS);
    everythingIsFine = false;
  }

  for (uint8_t index = 0; index < _count; ++index) {
    int8_t number = pinFromLabel(_labels[index]);
    _pinNumbers[index] = number;
    _wasPressed[index] = false;
    _lastChange[index] = millis();

    if (number == PIN_UNKNOWN) {
      Serial.print(F("[увага] У settings.py вказано пін '"));
      Serial.print(_labels[index]);
      Serial.println(F("', якого немає на Arduino Uno."));
      Serial.println(F("         Доступні назви: A0-A5, D10-D13."));
      everythingIsFine = false;
      continue;
    }

    // Сенсор сам тримає лінію в нулі, тому підтяжка не потрібна.
    pinMode(number, INPUT);
  }

  return everythingIsFine;
}

const char* TouchPanel::label(uint8_t index) const {
  if (_labels == NULL || index >= _count) {
    return "?";
  }
  return _labels[index];
}

bool TouchPanel::isPressed(uint8_t index) const {
  if (index >= _count || _pinNumbers[index] == PIN_UNKNOWN) {
    return false;
  }
  int value = digitalRead(_pinNumbers[index]);
  return _activeHigh ? (value == HIGH) : (value == LOW);
}

int8_t TouchPanel::pressedNow() {
  unsigned long now = millis();

  for (uint8_t index = 0; index < _count; ++index) {
    if (_pinNumbers[index] == PIN_UNKNOWN) {
      continue;
    }

    bool pressed = isPressed(index);
    if (pressed == _wasPressed[index]) {
      continue;
    }
    if (now - _lastChange[index] < _debounceMs) {
      continue;
    }

    _wasPressed[index] = pressed;
    _lastChange[index] = now;
    if (pressed) {
      return (int8_t)index;
    }
  }

  return -1;
}

int8_t TouchPanel::waitForAny(uint16_t timeoutMs) {
  unsigned long started = millis();
  while (millis() - started < timeoutMs) {
    int8_t index = pressedNow();
    if (index >= 0) {
      return index;
    }
    delay(10);
  }
  return -1;
}
