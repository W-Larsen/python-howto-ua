// Одна країна так, як її бачить код учнів.
//
// Окремим файлом, бо ця структура потрібна і ядру глобуса, і коду учнів
// (show_fact(country)), і тестам на комп'ютері - а тягнути за нею
// дисплей та аудіомодуль їм ні до чого.

#ifndef COUNTRY_H
#define COUNTRY_H

#include <Arduino.h>

struct Country {
  String id;          // "UA"
  String lcdName;     // "Ukraine"    - латиниця, можна на дисплей
  String lcdCapital;  // "Kyiv"       - латиниця, можна на дисплей
  uint8_t track;      // 5            - номер аудіозапису на microSD
};

#endif  // COUNTRY_H
