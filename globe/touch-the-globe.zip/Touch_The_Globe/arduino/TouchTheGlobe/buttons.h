// Сенсорні кнопки TTP223 (ті самі "touch sensor" на три ніжки).
//
// У сенсора три дроти: VCC (5 В), GND і SIG. Ніяких резисторів не треба -
// уся електроніка вже на його платці. Коли до майданчика торкаються, на
// SIG з'являється одиниця, тобто логіка ПРЯМА.
//
// Деякі модулі можна перепаяти так, щоб вони працювали навпаки. Якщо
// трапився саме такий, поміняй TOUCH_ACTIVE_HIGH у hardware_pins.h.
//
// Палець торкається сенсора не миттєво, і плата встигає побачити одне
// торкання як кілька. Тому після кожного спрацювання ми на короткий час
// перестаємо дивитися на цю кнопку (дебаунс).
//
// Самі піни приходять із settings.py (BUTTON_PINS, QUIZ_PIN, GAME_PIN)
// через згенерований student_code.h.

#ifndef BUTTONS_H
#define BUTTONS_H

#include <Arduino.h>

// Кнопки країн (до 8, див. MAX_BUTTONS у globe_core/settings.py)
// плюс кнопки вікторини й гри.
const uint8_t MAX_BUTTONS = 10;

class TouchPanel {
 public:
  TouchPanel();

  // Готує піни. Повертає false, якщо хоч одна назва піна неправильна:
  // саме тоді в Serial з'являється підказка, що виправляти.
  bool begin(const char* const* labels, uint8_t count, uint16_t debounceMs,
             bool activeHigh);

  uint8_t count() const { return _count; }
  const char* label(uint8_t index) const;

  // Чи торкаються сенсора прямо зараз.
  bool isPressed(uint8_t index) const;

  // Якої кнопки щойно торкнулися. Повертає її номер у списку або -1.
  // Утримання пальця дає одне спрацювання, а не безкінечний потік.
  int8_t pressedNow();

  // Чекає торкання будь-якої кнопки. Для перевірки заліза.
  int8_t waitForAny(uint16_t timeoutMs);

 private:
  const char* const* _labels;
  uint8_t _count;
  uint16_t _debounceMs;
  bool _activeHigh;
  int8_t _pinNumbers[MAX_BUTTONS];
  bool _wasPressed[MAX_BUTTONS];
  unsigned long _lastChange[MAX_BUTTONS];
};

#endif  // BUTTONS_H
