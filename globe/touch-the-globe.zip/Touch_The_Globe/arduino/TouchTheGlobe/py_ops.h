// Арифметика "як у Python".
//
// У Python -7 // 2 дає -4 (округлення вниз), а в C++ -7 / 2 дає -3
// (округлення до нуля). Остача теж різна: у Python 7 % -2 == -1, у C++ 1.
// Код учнів написаний і перевірений як Python, тому перекладач замінює
// // і % на ці функції - і плата рахує рівно так само, як комп'ютер.

#ifndef PY_OPS_H
#define PY_OPS_H

#include <Arduino.h>

long py_div(long a, long b);
long py_mod(long a, long b);

// str(число) і str(True) так, як їх пише Python.
String py_str(long value);
String py_str_bool(bool value);

// Ділення на нуль: у Python це помилка, тут - нуль і попередження.
// Реалізацію дає плата (globe_api.cpp) або тест на комп'ютері.
void globe_warn_division_by_zero();

#endif  // PY_OPS_H
