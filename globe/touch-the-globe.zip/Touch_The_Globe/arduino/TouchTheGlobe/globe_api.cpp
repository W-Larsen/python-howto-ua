// Функції, які викликає код учнів. Кожна просто передає роботу ядру.

#include "globe_api.h"

#include "globe_engine.h"

void play_sound(const String& countryId) {
  if (activeEngine != NULL) activeEngine->playSound(countryId);
}

void show_country(const String& countryId) {
  if (activeEngine != NULL) activeEngine->showCountry(countryId);
}

void show_text(long row, const String& text) {
  if (activeEngine != NULL) activeEngine->showText(row, text);
}

void clear_screen() {
  if (activeEngine != NULL) activeEngine->clearScreen();
}

void blink(long times) {
  if (activeEngine != NULL) activeEngine->blink(times);
}

void wait(long ms) {
  if (activeEngine != NULL) activeEngine->wait(ms);
}

long random_number(long low, long high) {
  return activeEngine != NULL ? activeEngine->randomNumber(low, high) : low;
}

void target(const String& countryId, const String& hint) {
  if (activeEngine != NULL) activeEngine->target(countryId, hint);
}

void ask(const String& text, const String& countryId) {
  if (activeEngine != NULL) activeEngine->ask(text, countryId);
}

void globe_loop_stuck(const __FlashStringHelper* file, int line) {
  if (activeEngine != NULL) activeEngine->loopStuck(file, line);
}

void globe_warn_division_by_zero() {
  if (activeEngine != NULL) activeEngine->divisionByZero();
}
