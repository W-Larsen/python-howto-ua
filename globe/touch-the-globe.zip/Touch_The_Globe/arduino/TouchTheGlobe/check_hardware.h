// Перевірка заліза по кроках.
//
// Запускається не сама: відкрий Serial Monitor (швидкість 9600) і введи
// команду check. Скрипт перевіряє по черзі назви пінів, дисплей,
// аудіомодуль, країни й кожен сенсор окремо - тому не доводиться гадати,
// чому "глобус не вмикається".

#ifndef CHECK_HARDWARE_H
#define CHECK_HARDWARE_H

#include <Arduino.h>

#include "buttons.h"
#include "dfplayer.h"
#include "globe_display.h"

// pins - усі сенсори (кнопки країн, вікторина, гра) у тому самому порядку,
// що й на панелі.
void runHardwareCheck(GlobeDisplay& display, TouchPanel& panel, DFPlayer& player,
                      const char* const* pins, uint8_t pinCount);

#endif  // CHECK_HARDWARE_H
