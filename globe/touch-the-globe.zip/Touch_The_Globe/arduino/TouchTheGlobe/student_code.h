// ЗГЕНЕРОВАНО автоматично. Руками не редагувати!
//
// Цей файл складає tools/build_student_code.py (команда make build) з
// settings.py і students/task*.py. Щоб щось тут змінити, виправ ті файли
// й запусти make build ще раз.
//
// Задачі: task1.py, task2.py, task3.py, task4.py, task5.py

#ifndef STUDENT_CODE_H
#define STUDENT_CODE_H

#include <Arduino.h>

#include "globe_api.h"
#include "student_hooks.h"

// --- settings.py ---
const char* const BUTTON_PINS[] = {"A0", "A1", "A2", "A3", "A4"};
const uint8_t BUTTON_COUNT = 5;
const char* const QUIZ_PIN = "D10";
const unsigned long QUIZ_PAUSE_MS = 1500UL;
const char* const GAME_PIN = "D11";
const uint8_t GAME_ROUNDS = 5;
const unsigned long GAME_TIMEOUT_MS = 5000UL;
const unsigned long GAME_PAUSE_MS = 1500UL;

// Які хуки написані: біт i - HOOK_LIST[i] у globe_core/hooks.py.
uint16_t student_hooks_present() { return 0x03FF; }

// settings.py, BUTTON_COUNTRIES: країна кнопки в грі й вікторині
void student_button_answer(long number) {
}

// task1.py, рядок 30: on_button()
void student_on_button(long s_number) {
  ;
}

// task1.py, рядок 36: hello_screen()
void student_hello_screen() {
  ;
}

// task2.py, рядок 35: next_target()
void student_next_target(long s_round) {
  ;
}

// task2.py, рядок 40: on_hit()
void student_on_hit(bool s_correct, long s_ms) {
  ;
}

// task2.py, рядок 45: game_over()
void student_game_over(long s_score, long s_rounds) {
  ;
}

// task3.py, рядок 34: question()
void student_question(long s_number) {
  ;
}

// task3.py, рядок 39: on_answer()
void student_on_answer(bool s_correct, long s_score) {
  ;
}

// task3.py, рядок 44: final()
void student_final(long s_score, long s_total) {
  ;
}

// task4.py, рядок 26: show_fact()
void student_show_fact(const Country& s_country) {
  ;
}

// task5.py, рядок 25: loading()
void student_loading() {
  ;
}

#endif  // STUDENT_CODE_H
