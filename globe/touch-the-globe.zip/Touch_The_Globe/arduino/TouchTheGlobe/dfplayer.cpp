#include "dfplayer.h"

void buildFrame(uint8_t command, uint16_t parameter, uint8_t* frame,
                bool feedback) {
  uint8_t high = (uint8_t)((parameter >> 8) & 0xFF);
  uint8_t low = (uint8_t)(parameter & 0xFF);
  uint8_t acknowledge = feedback ? 0x01 : 0x00;

  uint16_t total = 0xFF + 0x06 + command + acknowledge + high + low;
  uint16_t checksum = (uint16_t)(-total);

  frame[0] = 0x7E;
  frame[1] = 0xFF;
  frame[2] = 0x06;
  frame[3] = command;
  frame[4] = acknowledge;
  frame[5] = high;
  frame[6] = low;
  frame[7] = (uint8_t)((checksum >> 8) & 0xFF);
  frame[8] = (uint8_t)(checksum & 0xFF);
  frame[9] = 0xEF;
}

DFPlayer::DFPlayer(SoftwareSerial& serial)
    : _serial(serial), _volume(22), _folder(1) {}

void DFPlayer::begin(uint8_t volume, uint8_t folder) {
  _folder = folder;
  _serial.begin(DFPLAYER_BAUDRATE);

  send(CMD_RESET);
  delay(2000);
  send(CMD_SELECT_DEVICE, DEVICE_SD);
  delay(300);
  setVolume(volume);
}

void DFPlayer::send(uint8_t command, uint16_t parameter) {
  uint8_t frame[FRAME_SIZE];
  buildFrame(command, parameter, frame);
  _serial.write(frame, FRAME_SIZE);
  // Модулю треба трохи часу, щоб перетравити команду.
  delay(30);
}

void DFPlayer::setVolume(uint8_t level) {
  if (level > MAX_VOLUME) {
    level = MAX_VOLUME;
  }
  _volume = level;
  send(CMD_SET_VOLUME, level);
}

bool DFPlayer::playFolder(uint8_t folder, uint8_t track) {
  if (folder < 1 || folder > 99) {
    Serial.print(F("[увага] Номер папки має бути від 1 до 99, а не "));
    Serial.println(folder);
    return false;
  }
  if (track < 1) {
    Serial.println(F("[увага] Номер треку має бути від 1 і більше."));
    return false;
  }
  send(CMD_PLAY_FOLDER, ((uint16_t)folder << 8) | track);
  return true;
}

void DFPlayer::stop() { send(CMD_STOP); }

DFPlayerSpeaker::DFPlayerSpeaker() : _player(NULL) {}

void DFPlayerSpeaker::attach(DFPlayer* player) { _player = player; }

void DFPlayerSpeaker::play(uint8_t track) {
  if (_player == NULL || track == 0) {
    return;
  }
  _player->playFolder(_player->folder(), track);
}

void DFPlayerSpeaker::stop() {
  if (_player != NULL) {
    _player->stop();
  }
}
