// ЗГЕНЕРОВАНО автоматично. Руками не редагувати!
//
// Цей файл складає скрипт tools/build_arduino_data.py з файлів
// content/countries/*.txt. Щоб щось тут змінити, виправ потрібний
// файл країни на комп'ютері й запусти:
//
//     python3 tools/build_arduino_data.py

#ifndef COUNTRIES_H
#define COUNTRIES_H

#include <Arduino.h>

// Рядки лежать у флеші (PROGMEM), бо оперативної пам'яті в Uno
// лише 2 кілобайти. Розпаковує їх у звичайний текст globe_engine.cpp.

// UA - Україна
const char COUNTRY_0_ID[] PROGMEM = "UA";
const char COUNTRY_0_LCD_NAME[] PROGMEM = "Ukraine";
const char COUNTRY_0_LCD_CAPITAL[] PROGMEM = "Kyiv";

// Одна країна так, як її бачить плата.
struct CountryData {
  const char* id;
  const char* lcdName;
  const char* lcdCapital;
  uint8_t track;  // який файл грати: 01/00X.mp3 на microSD
};

const uint8_t COUNTRY_COUNT = 1;

const CountryData COUNTRIES[COUNTRY_COUNT] PROGMEM = {
  {COUNTRY_0_ID, COUNTRY_0_LCD_NAME, COUNTRY_0_LCD_CAPITAL, 1},
};

#endif  // COUNTRIES_H
