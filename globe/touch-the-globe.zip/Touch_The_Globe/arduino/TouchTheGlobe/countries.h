// ЗГЕНЕРОВАНО автоматично. Руками не редагувати!
//
// Цей файл складає скрипт tools/build_arduino_data.py з файлів
// content/countries/*.txt. Щоб щось тут змінити, виправ потрібний
// файл країни на комп'ютері й запусти:
//
//     python3 tools/build_arduino_data.py

#ifndef COUNTRIES_H
#define COUNTRIES_H

#include <Arduino.h>

// Рядки лежать у флеші (PROGMEM), бо оперативної пам'яті в Uno
// лише 2 кілобайти. Розпаковує їх у звичайний текст globe_engine.cpp.

// AU - Австралія
const char COUNTRY_0_ID[] PROGMEM = "AU";
const char COUNTRY_0_LCD_NAME[] PROGMEM = "Australia";
const char COUNTRY_0_LCD_CAPITAL[] PROGMEM = "Canberra";

// BR - Бразилія
const char COUNTRY_1_ID[] PROGMEM = "BR";
const char COUNTRY_1_LCD_NAME[] PROGMEM = "Brazil";
const char COUNTRY_1_LCD_CAPITAL[] PROGMEM = "Brazil";

// EG - Єгипет
const char COUNTRY_2_ID[] PROGMEM = "EG";
const char COUNTRY_2_LCD_NAME[] PROGMEM = "Egypt";
const char COUNTRY_2_LCD_CAPITAL[] PROGMEM = "Cairo";

// JP - Японія
const char COUNTRY_3_ID[] PROGMEM = "JP";
const char COUNTRY_3_LCD_NAME[] PROGMEM = "Japan";
const char COUNTRY_3_LCD_CAPITAL[] PROGMEM = "Tokyo";

// UA - Україна
const char COUNTRY_4_ID[] PROGMEM = "UA";
const char COUNTRY_4_LCD_NAME[] PROGMEM = "Ukraine";
const char COUNTRY_4_LCD_CAPITAL[] PROGMEM = "Kyiv";

// US - Сполучені Штати Америки
const char COUNTRY_5_ID[] PROGMEM = "US";
const char COUNTRY_5_LCD_NAME[] PROGMEM = "USA";
const char COUNTRY_5_LCD_CAPITAL[] PROGMEM = "Washington";

// Одна країна так, як її бачить плата.
struct CountryData {
  const char* id;
  const char* lcdName;
  const char* lcdCapital;
  uint8_t track;  // який файл грати: 01/00X.mp3 на microSD
};

const uint8_t COUNTRY_COUNT = 6;

const CountryData COUNTRIES[COUNTRY_COUNT] PROGMEM = {
  {COUNTRY_0_ID, COUNTRY_0_LCD_NAME, COUNTRY_0_LCD_CAPITAL, 1},
  {COUNTRY_1_ID, COUNTRY_1_LCD_NAME, COUNTRY_1_LCD_CAPITAL, 2},
  {COUNTRY_2_ID, COUNTRY_2_LCD_NAME, COUNTRY_2_LCD_CAPITAL, 3},
  {COUNTRY_3_ID, COUNTRY_3_LCD_NAME, COUNTRY_3_LCD_CAPITAL, 4},
  {COUNTRY_4_ID, COUNTRY_4_LCD_NAME, COUNTRY_4_LCD_CAPITAL, 5},
  {COUNTRY_5_ID, COUNTRY_5_LCD_NAME, COUNTRY_5_LCD_CAPITAL, 6},
};

#endif  // COUNTRIES_H
