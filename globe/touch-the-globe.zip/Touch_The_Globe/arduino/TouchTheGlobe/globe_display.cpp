#include "globe_display.h"

#include "pins.h"

// Висота одного рядка тексту в точках.
static const uint8_t CHAR_HEIGHT = 8;

GlobeDisplay::GlobeDisplay(Adafruit_PCD8544& lcd, uint8_t columns, uint8_t rows)
    : _lcd(lcd),
      _columns(columns),
      _rows(rows),
      _backlightPin(PIN_UNKNOWN),
      _backlightActiveLow(true) {}

void GlobeDisplay::begin(uint8_t contrast) {
  _lcd.begin(contrast);
  _lcd.setTextSize(1);
  _lcd.setTextColor(BLACK, WHITE);
  _lcd.setTextWrap(false);
  _lcd.clearDisplay();
  _lcd.display();
}

void GlobeDisplay::useBacklight(const char* pinLabel, bool activeLow) {
  _backlightPin = pinFromLabel(pinLabel);
  _backlightActiveLow = activeLow;

  if (_backlightPin != PIN_UNKNOWN) {
    pinMode((uint8_t)_backlightPin, OUTPUT);
    backlight(true);
  }
}

void GlobeDisplay::backlight(bool on) {
  if (_backlightPin == PIN_UNKNOWN) {
    return;
  }
  bool high = _backlightActiveLow ? !on : on;
  digitalWrite((uint8_t)_backlightPin, high ? HIGH : LOW);
}

void GlobeDisplay::writeAt(int16_t x, int16_t y, const String& text, uint8_t limit) {
  _lcd.setCursor(x, y);
  for (uint8_t index = 0; index < limit && index < text.length(); ++index) {
    char symbol = text[index];
    // У шрифті дисплея є лише латиниця, цифри й розділові знаки.
    if (symbol < 32 || symbol > 126) {
      symbol = '?';
    }
    _lcd.write(symbol);
  }
}

void GlobeDisplay::writeRow(uint8_t row, const String& text, bool inverted) {
  if (row >= _rows) {
    return;
  }
  int16_t y = (int16_t)row * CHAR_HEIGHT;
  uint16_t background = inverted ? BLACK : WHITE;
  uint16_t foreground = inverted ? WHITE : BLACK;

  // Спершу стираємо старий текст цього рядка, потім пишемо новий.
  _lcd.fillRect(0, y, _lcd.width(), CHAR_HEIGHT, background);
  _lcd.setTextColor(foreground, background);
  writeAt(0, y, text, _columns);
  _lcd.setTextColor(BLACK, WHITE);
  _lcd.display();
}

void GlobeDisplay::message(const String& lineOne, const String& lineTwo) {
  _lcd.clearDisplay();
  writeAt(0, 0, lineOne, _columns);
  writeAt(0, CHAR_HEIGHT, lineTwo, _columns);
  _lcd.display();
}

void GlobeDisplay::clear() {
  _lcd.clearDisplay();
  _lcd.display();
}

void GlobeDisplay::blink(uint8_t times) {
  for (uint8_t index = 0; index < times; ++index) {
    if (_backlightPin != PIN_UNKNOWN) {
      backlight(false);
      delay(150);
      backlight(true);
      delay(150);
    } else {
      _lcd.invertDisplay(true);
      delay(150);
      _lcd.invertDisplay(false);
      delay(150);
    }
  }
}
