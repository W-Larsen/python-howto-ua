#include "check_hardware.h"

#include "countries.h"
#include "globe_engine.h"
#include "hardware_pins.h"
#include "pins.h"

#if ENABLE_HARDWARE_CHECK

static uint8_t stepNumber = 0;

static void title(const __FlashStringHelper* text) {
  ++stepNumber;
  Serial.println();
  Serial.print(F("--- Крок "));
  Serial.print(stepNumber);
  Serial.print(F(": "));
  Serial.print(text);
  Serial.println(F(" ---"));
}

static void ok(const __FlashStringHelper* text) {
  Serial.print(F("  [+] "));
  Serial.println(text);
}

static void bad(const __FlashStringHelper* text) {
  Serial.print(F("  [-] "));
  Serial.println(text);
}

// ---------------------------------------------------------------------------
static bool checkPins(const char* const* pins, uint8_t pinCount) {
  title(F("Назви пінів"));

  // П'ять дротів дисплея, підсвітка, два до аудіомодуля і всі сенсори.
  const uint8_t SLOTS = 8 + MAX_BUTTONS;
  const char* labels[SLOTS];
  uint8_t used = 0;

  labels[used++] = LCD_RST;
  labels[used++] = LCD_CE;
  labels[used++] = LCD_DC;
  labels[used++] = LCD_DIN;
  labels[used++] = LCD_CLK;
  labels[used++] = DFPLAYER_TX;
  labels[used++] = DFPLAYER_RX;
  // Підсвітку можна й не вмикати в пін - тоді назва порожня.
  if (LCD_BACKLIGHT != NULL && LCD_BACKLIGHT[0] != '\0') {
    labels[used++] = LCD_BACKLIGHT;
  }
  for (uint8_t index = 0; index < pinCount && used < SLOTS; ++index) {
    labels[used++] = pins[index];
  }

  bool everythingIsFine = true;

  for (uint8_t index = 0; index < used; ++index) {
    int8_t number = pinFromLabel(labels[index]);
    if (number == PIN_UNKNOWN) {
      Serial.print(F("  [-] Піна '"));
      Serial.print(labels[index]);
      Serial.println(F("' на Arduino Uno немає. Бери D0-D13 або A0-A5."));
      everythingIsFine = false;
      continue;
    }

    for (uint8_t other = 0; other < index; ++other) {
      if (pinFromLabel(labels[other]) == number) {
        Serial.print(F("  [-] Піни '"));
        Serial.print(labels[other]);
        Serial.print(F("' і '"));
        Serial.print(labels[index]);
        Serial.println(F("' - це те саме місце на платі."));
        Serial.println(F("      Один пін не може робити дві справи."));
        everythingIsFine = false;
      }
    }
  }

  if (everythingIsFine) {
    ok(F("Усі піни різні й існують на платі."));
  }
  return everythingIsFine;
}

static void checkDisplay(GlobeDisplay& display) {
  title(F("Дисплей Nokia 5110"));

  display.message(F("Display test"), F("12345678901234"));
  Serial.println(F("  Подивись на дисплей:"));
  Serial.println(F("     рядок 1: Display test"));
  Serial.println(F("     рядок 2: 12345678901234  <- рівно 14 символів"));
  Serial.println(F("  Якщо рядок 2 обрізаний - щось не так із бібліотекою."));
  Serial.println(F("  Якщо екран порожній або весь чорний - зміни число"));
  Serial.println(F("  LCD_CONTRAST у hardware_pins.h (спробуй 45 і 70)."));
  Serial.println(F("  Якщо на екрані сміття - перевір Din, Clk, DC, CE, RST."));

  Serial.println(F("  Тепер двічі блимаю підсвіткою..."));
  for (uint8_t blink = 0; blink < 2; ++blink) {
    display.backlight(false);
    delay(400);
    display.backlight(true);
    delay(400);
  }
  Serial.println(F("  Блимало? Якщо ні - перевір дріт BL, а якщо підсвітка"));
  Serial.println(F("  гасне навпаки - постав BACKLIGHT_ACTIVE_LOW = false."));
}

static void checkDfplayer(DFPlayer& player) {
  title(F("Аудіомодуль DFPlayer Mini"));

  Serial.println(F("  Перезапускаю модуль, це займає близько двох секунд..."));
  player.begin(DFPLAYER_VOLUME, DFPLAYER_FOLDER);
  ok(F("Команди надіслані."));

  Serial.println(F("  Граю перший трек із папки 01..."));
  player.playFolder(DFPLAYER_FOLDER, 1);
  delay(4000);
  player.stop();

  Serial.println(F("  Чути було звук?"));
  Serial.println(F("  Якщо ні, перевір по черзі:"));
  Serial.println(F("   1. Дроти RX/TX ідуть НАВХРЕСТ: D8 плати -> RX модуля."));
  Serial.println(F("   2. Модуль живиться від 5V."));
  Serial.println(F("   3. На microSD є папка 01, а в ній файл 001.mp3."));
  Serial.println(F("      Розкласти файли: python3 tools/build_sd_card.py"));
  Serial.println(F("   4. Динамік у клеми SPK_1 і SPK_2."));
}

static void checkCountries() {
  title(F("Країни у пам'яті плати"));

  Serial.print(F("  [+] Знайдено країн: "));
  Serial.println(COUNTRY_COUNT);

  for (uint8_t index = 0; index < COUNTRY_COUNT; ++index) {
    Country country;
    loadCountry(index, country);
    Serial.print(F("     трек "));
    Serial.print(country.track);
    Serial.print(F("  "));
    Serial.print(country.id);
    Serial.print(F("  "));
    Serial.print(country.lcdName);
    Serial.print(F("  "));
    Serial.println(country.lcdCapital);
  }

  Serial.println(F("  Список складається з content/countries/ командою"));
  Serial.println(F("  python3 tools/build_arduino_data.py"));
}

static void checkButtons(GlobeDisplay& display, TouchPanel& panel) {
  title(F("Сенсорні кнопки"));

  if (panel.count() == 0) {
    bad(F("Немає жодного сенсора: перевір BUTTON_PINS у settings.py."));
    return;
  }

  Serial.print(F("  [+] Описано кнопок: "));
  Serial.println(panel.count());

  bool stuck = false;
  for (uint8_t index = 0; index < panel.count(); ++index) {
    if (panel.isPressed(index)) {
      if (!stuck) {
        bad(F("Ці сенсори виглядають натиснутими, хоча їх ніхто не чіпає:"));
        stuck = true;
      }
      Serial.print(F("      "));
      Serial.println(panel.label(index));
    }
  }
  if (stuck) {
    Serial.println(F("  Найчастіша причина - SIG сенсора підключений у 5V"));
    Serial.println(F("  замість піна плати, або сенсор перепаяний на"));
    Serial.println(F("  перевернуту логіку: тоді постав TOUCH_ACTIVE_HIGH = false."));
  }

  Serial.println();
  Serial.println(F("  Тепер торкайся сенсорів по черзі."));
  Serial.println(F("  Якщо сенсор не працює - пропусти його, зачекавши 15 секунд."));

  for (uint8_t index = 0; index < panel.count(); ++index) {
    const char* label = panel.label(index);

    display.message(String("Touch ") + label, F(""));
    Serial.println();
    Serial.print(F("  Торкнись "));
    Serial.print(label);
    Serial.println(F("..."));

    int8_t pressed = panel.waitForAny(15000);
    if (pressed < 0) {
      bad(F("нічого не спрацювало за 15 секунд"));
    } else if (pressed == (int8_t)index) {
      ok(F("є контакт"));
    } else {
      Serial.print(F("  [-] спрацював сенсор "));
      Serial.print(panel.label((uint8_t)pressed));
      Serial.println(F(" - схоже, дроти двох сенсорів переплутані."));
    }
  }
}

void runHardwareCheck(GlobeDisplay& display, TouchPanel& panel, DFPlayer& player,
                      const char* const* pins, uint8_t pinCount) {
  stepNumber = 0;

  Serial.println();
  Serial.println(F("=== Touch The Globe: перевірка заліза ==="));
  Serial.println(F("Плата: Arduino Uno"));

  checkPins(pins, pinCount);
  checkDisplay(display);
  checkDfplayer(player);
  checkCountries();
  checkButtons(display, panel);

  Serial.println();
  Serial.println(F("=== Перевірку завершено ==="));
  display.message(F("Check"), F("finished"));
  Serial.println(F("Якщо всі кроки з [+] - перезапусти плату, і глобус запрацює."));
}

#endif  // ENABLE_HARDWARE_CHECK
