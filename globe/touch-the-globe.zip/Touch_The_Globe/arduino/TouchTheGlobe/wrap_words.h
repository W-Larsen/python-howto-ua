// Розбивка тексту питання на рядки екрана (для ask() у вікторині).
//
// Той самий алгоритм, що wrap_words() у globe_core/screen.py: слова
// переносяться цілими, а слово, довше за рядок, ріжеться на шматки.
// Окремим файлом, щоб тест на комп'ютері (tests/test_parity.py) міг
// зібрати його й порівняти з Python рядок у рядок.

#ifndef WRAP_WORDS_H
#define WRAP_WORDS_H

#include <Arduino.h>

// Пише в lines не більше maxLines рядків, кожен не довший за width.
// Повертає, скільки рядків вийшло.
uint8_t wrapWords(const String& text, String* lines, uint8_t maxLines, uint8_t width);

#endif  // WRAP_WORDS_H
