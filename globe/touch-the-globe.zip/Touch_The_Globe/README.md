# Touch The Globe

Глобус, який розповідає про країни. Натискаєш кнопку біля країни — на дисплеї
з'являється текст, а з динаміка звучить розповідь.

Проєкт живе у двох місцях. Версія для комп'ютера написана на **Python**, а
версія для плати **Arduino Uno** — на **C++**, як і належить Arduino. Логіка в
них однакова, тому спочатку все робиться й перевіряється на комп'ютері, а вже
потім переноситься на залізо.

```
                    ┌──────────────────────────┐
                    │   content/countries/     │
                    │   один файл = одна країна│
                    └────────────┬─────────────┘
                 ┌───────────────┴────────────────┐
                 ▼                                ▼
      ┌────────────────────┐          ┌──────────────────────────┐
      │ Комп'ютер (Python) │          │ Arduino Uno (C++)        │
      │ консоль + колонки  │          │ Nokia 5110 + DFPlayer    │
      └────────────────────┘          └──────────────────────────┘
```

## Швидкий старт (без жодного заліза)

Потрібен лише Python 3.9+. Ніяких `pip install` не потрібно.

```bash
git clone <адреса-репозиторію>
cd Touch_The_Globe
cp .env.example .env

make list          # які країни є           (Windows: globe list)
make press 1       # ніби торкнулися кнопки 1 (Windows: globe press 1)
make run           # глобус «наживо»          (Windows: globe run)
make test          # перевірити код учнів     (Windows: globe test)
```

Якщо аудіофайлів ще немає, текст усе одно виведеться — просто без звуку.

## Два режими звуку

Режим перемикається змінною `GLOBE_AUDIO_MODE` у файлі `.env`.

| Режим | Що робить | Коли потрібен |
|---|---|---|
| `prerecorded` | Грає готові mp3 з `content/audio/` | Учні записали озвучення самі |
| `elevenlabs` | Озвучує текст країни через ElevenLabs і кешує результат | Немає часу записувати вручну |

Для другого режиму потрібен безкоштовний ключ з
[elevenlabs.io](https://elevenlabs.io/app/settings/api-keys). Безкоштовний тариф
дає 10 000 символів на місяць, тому кожен згенерований файл зберігається в
`content/audio_tts/` і другий раз не генерується.

```bash
python3 tools/generate_audio.py --all      # озвучити всі країни
python3 tools/generate_audio.py UA FR      # тільки дві
python3 tools/generate_audio.py --all --dry-run   # спочатку порахувати витрати
```

## Як додати нову країну

Три кроки. Детально — у [docs/add_country.md](docs/add_country.md).

**1.** Створити файл `content/countries/CA.txt`:

```
name: Канада
capital: Оттава
continent: Північна Америка
lcd_name: Canada
lcd_capital: Ottawa
---
Канада — друга за площею країна світу.
Тут більше озер, ніж у всіх інших країнах разом.
```

**2.** Озвучити: `python3 tools/generate_audio.py CA`
(або покласти власний запис у `content/audio/CA.mp3`).

**3.** Прив'язати кнопку — гілка `elif number == ...` у `students/task1.py`
(детально — у [docs/add_country.md](docs/add_country.md)).

Ніякого центрального списку правити не треба — програма сама знаходить усі файли
в папці `content/countries/`.

## Що пишуть учні

Кожен учень - свій файл у `students/`: task1 «Монтажник» (кнопки), task2
«Блискавка» (гра на швидкість), task3 «Квізмейкер» (вікторина), task4
«Знавець» і task5 «Завантажувач» (запасні). Вчитель збирає файли, і
`make build` перекладає їх у C++ для плати.

- [Гайд для учня](docs/student_guide.md)
- [Гайд для вчителя](docs/teacher_guide.md)
- [Картки задач](docs/student_tasks.md)

## Версія на платі

Потрібно: Arduino Uno, дисплей Nokia 5110, DFPlayer Mini, microSD, динамік
8 Ом, сенсорні кнопки TTP223. Схема — у [docs/wiring.md](docs/wiring.md).

Перед першим завантаженням постав у Arduino IDE три бібліотеки
(**Tools → Manage Libraries**, шукати `Adafruit PCD8544`): саму
**Adafruit PCD8544 Nokia 5110 LCD library**, а до неї **Adafruit GFX
Library** і **Adafruit BusIO** — IDE запропонує їх сама, треба лише
погодитись.

```bash
# 1. Розкласти аудіо у структуру, яку розуміє DFPlayer (01/001.mp3, 01/002.mp3, ...)
python3 tools/build_sd_card.py
# 2. Скопіювати вміст sd_card/ на microSD і вставити її в DFPlayer

# 3. Перенести країни у скетч (створює countries.h)
python3 tools/build_arduino_data.py
# 4. Перенести код учнів у скетч (створює student_code.h)
make build
```

Далі — [Arduino IDE](https://www.arduino.cc/en/software): відкрити
`arduino/TouchTheGlobe/TouchTheGlobe.ino`, вибрати **Tools → Board → Arduino Uno**
і свій порт, натиснути **Upload**.

Перевірити залізо по кроках: **Tools → Serial Monitor**, швидкість 9600, і ввести
команду `check`. Там же працюють `help`, `list`, `press 1` (`press q`, `press g`),
`play UA` і `stop` — це майже той самий набір, що й `make press` на комп'ютері.

Флеш Uno заповнений майже повністю (з усіма п'ятьма задачами ≈99 %).
`make upload` у такому разі сам збирає скетч без команди `check` (див.
розділ 5 у [гайді для вчителя](docs/teacher_guide.md)); в Arduino IDE при
«Sketch too big» постав `#define ENABLE_HARDWARE_CHECK 0` у `hardware_pins.h`.

Хто любить термінал, може збирати скетч без IDE:

```bash
make compile                                 # make build + компіляція
make upload PORT=/dev/cu.usbmodem1101        # те саме + заливання на плату
```

## Структура проєкту

```
students/             ← ЗОНА УЧНІВ: task1.py ... task5.py
settings.py           ← піни сенсорів і параметри ігор (вчитель)
content/countries/    ← по одному файлу на країну
globe_core/           ← ядро версії для комп'ютера
pc/                   ← версія для комп'ютера
arduino/TouchTheGlobe/← скетч для Arduino Uno (C++)
tools/                ← допоміжні скрипти
docs/                 ← гайди, картки задач, схема підключення
tests/                ← тести
```

Файли країн читає лише комп'ютер: в Uno немає ні файлової системи, ні місця під
весь текст. Тому `tools/build_arduino_data.py` заздалегідь складає з них
`arduino/TouchTheGlobe/countries.h` — туди їде тільки те, що плата справді
використовує: ID, назва й столиця латиницею та номер треку.

## Тести

```bash
python3 -m unittest discover -s tests -v
make selftest     # разом зі справжньою компіляцією скетча
```
