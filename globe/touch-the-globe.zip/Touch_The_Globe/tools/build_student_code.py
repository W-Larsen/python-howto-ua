#!/usr/bin/env python3
"""Перекладає код учнів у C++ для плати (команда make build).

    python3 tools/build_student_code.py            перевірити й записати
    python3 tools/build_student_code.py --check    лише перевірити

Читає settings.py і students/task*.py, перевіряє їх тими самими
правилами, що й globe test, і складає arduino/TouchTheGlobe/student_code.h.
Якщо хоч в одному файлі є помилка - student_code.h не змінюється.
"""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from globe_core.catalog import ContentError, load_catalog  # noqa: E402
from globe_core.cpp_codegen import generate_header  # noqa: E402
from globe_core.language import Context, analyze_all, read_task_sources  # noqa: E402
from globe_core.problems import WARNING, has_errors  # noqa: E402
from globe_core.settings import load_settings  # noqa: E402

OUTPUT = Path("arduino") / "TouchTheGlobe" / "student_code.h"


def render(root, students_dir=None, countries_dir=None):
    """Повертає (текст заголовка або None, проблеми).

    countries_dir - інша тека з країнами (для тестів); за замовчуванням content/countries."""
    root = Path(root)
    students_dir = Path(students_dir) if students_dir else root / "students"
    settings, problems = load_settings(root / "settings.py")
    catalog = load_catalog(str(countries_dir or root / "content" / "countries"))
    sources, read_problems = read_task_sources(students_dir)
    problems = problems + read_problems
    infos, task_problems = analyze_all(sources, Context(catalog.ids(), settings.button_count))
    problems = problems + task_problems
    if has_errors(problems):
        return None, problems
    return generate_header(settings, infos), problems


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=str(ROOT), help="корінь проєкту")
    parser.add_argument("--check", action="store_true", help="лише перевірити, нічого не писати")
    args = parser.parse_args(argv)
    root = Path(args.root)

    try:
        header, problems = render(root)
    except ContentError as exc:
        print("Помилка у файлах країн: " + str(exc))
        return 1

    for problem in problems:
        label = "увага" if problem.level == WARNING else "помилка"
        print("[{}] {}".format(label, problem))

    if header is None:
        print()
        print("student_code.h НЕ змінено: спершу виправ помилки вище.")
        return 1

    output = root / OUTPUT
    existing = output.read_text(encoding="utf-8") if output.is_file() else None
    if args.check:
        if existing == header:
            print("student_code.h актуальний.")
            return 0
        print("student_code.h застарів: запусти make build.")
        return 1

    if existing == header:
        print("student_code.h уже актуальний - нічого не змінилося.")
    else:
        output.write_text(header, encoding="utf-8")
        print("Готово: {}".format(output))
    print("Далі: make upload PORT=...  (або Arduino IDE -> Upload)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
