#!/usr/bin/env python3
"""Розкладає аудіо у структуру, яку розуміє DFPlayer Mini.

    python3 tools/build_sd_card.py

DFPlayer не знає слова "Україна" - він шукає файли за номерами, у папках
із двоцифровими назвами:

    sd_card/
      01/
        001.mp3   <- трек 1
        002.mp3   <- трек 2
        ...

Скрипт бере аудіо кожної країни (записане вручну або озвучене через
ElevenLabs), перейменовує його за номером треку і складає все в папку
sd_card/. Далі цю папку копіюють на microSD.

Заодно зберігається content/.track_map.json - список, яка країна яким
треком стала. Його бере tools/sync_board.py, і саме тому номери треків
ніколи не пишуться руками.
"""

import argparse
import json
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from globe_core.catalog import ContentError, load_catalog  # noqa: E402
from pc.audio_local import find_audio_file  # noqa: E402
from pc.config import ConfigError, load_config  # noqa: E402

# Папка 01 - факти. Пізніше можна додати 02 (історії) і 03 (квіз).
FACTS_FOLDER = 1


def build_parser():
    parser = argparse.ArgumentParser(
        prog="python3 tools/build_sd_card.py",
        description="Скласти файли для microSD у форматі DFPlayer Mini.",
    )
    parser.add_argument(
        "--output",
        help="куди складати (за замовчуванням sd_card/ у корені проєкту)",
    )
    parser.add_argument(
        "--clean",
        action="store_true",
        help="спочатку прибрати попередній вміст папки",
    )
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)

    try:
        config = load_config(root=ROOT)
    except ConfigError as exc:
        print("Помилка: " + str(exc))
        return 1

    try:
        catalog = load_catalog(str(config.countries_dir))
    except ContentError as exc:
        print("Помилка: " + str(exc))
        return 1

    output = Path(args.output) if args.output else config.sd_card_dir
    folder = output / "{:02d}".format(FACTS_FOLDER)

    if args.clean and output.exists():
        shutil.rmtree(output)
        print("Прибрано попередній вміст {}".format(output))
    folder.mkdir(parents=True, exist_ok=True)

    copied = []
    missing = []
    track_map = {}

    for country in catalog:
        source = find_audio_file(config.audio_dir, country.id)
        origin = "запис"
        if source is None:
            source = find_audio_file(config.tts_cache_dir, country.id)
            origin = "голос ElevenLabs"

        track_map[country.id] = {
            "track": country.track,
            "name": country.name,
            "folder": FACTS_FOLDER,
        }

        if source is None:
            missing.append(country)
            continue

        # DFPlayer шукає рівно три цифри і розширення .mp3
        target = folder / "{:03d}.mp3".format(country.track)
        shutil.copyfile(source, target)
        copied.append((country, target, origin))

    for country, target, origin in copied:
        print(
            "  {:<4} {:<24} -> {}  ({})".format(
                country.id, country.name, target.relative_to(output), origin
            )
        )

    config.track_map_path.parent.mkdir(parents=True, exist_ok=True)
    config.track_map_path.write_text(
        json.dumps(track_map, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )

    print()
    print("Скопійовано файлів: {} з {}".format(len(copied), len(catalog)))
    print("Папка для microSD:  {}".format(output))
    print("Карта треків:       {}".format(config.track_map_path))

    if missing:
        print()
        print("=== Немає аудіо ({}) ===".format(len(missing)))
        for country in missing:
            print("  {} ({})".format(country.id, country.name))
        print()
        print("Ці країни на глобусі показуватимуться, але мовчки.")
        print("Озвучити:  python3 tools/generate_audio.py --all")
        print("Або поклади свої записи у {}".format(config.audio_dir))

    if copied:
        print()
        print("Далі:")
        print("  1. Вставте microSD у комп'ютер і відформатуйте її у FAT32.")
        print("  2. Скопіюйте ВМІСТ папки {} у корінь картки,".format(output.name))
        print("     щоб на картці вийшла папка 01 з файлами 001.mp3, 002.mp3...")
        print("  3. Вставте картку в DFPlayer і перезапустіть плату.")

    return 0


if __name__ == "__main__":
    sys.exit(main())
