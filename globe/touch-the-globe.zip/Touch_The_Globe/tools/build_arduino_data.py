#!/usr/bin/env python3
"""Переносить країни з content/countries/ у скетч для Arduino Uno.

    python3 tools/build_arduino_data.py
    python3 tools/build_arduino_data.py --check    нічого не пише, лише перевіряє

На комп'ютері країни лежать у текстових файлах, і програма читає їх під
час запуску. На Arduino Uno так не вийде: у неї немає ані файлової
системи, ані місця, щоб тримати весь текст. Тому цей скрипт заздалегідь
складає з файлів країн один заголовок arduino/TouchTheGlobe/countries.h.

На плату їде тільки те, що їй справді потрібно:

    ID країни, назва латиницею, столиця латиницею, номер треку

Український текст лишається на комп'ютері: на платі його ніде показати
(Nokia 5110 не має кирилиці) і нічим сказати (DFPlayer грає лише готові
записи з microSD).
"""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from globe_core.catalog import LCD_WIDTH, ContentError, load_catalog  # noqa: E402

SKETCH_DIR = ROOT / "arduino" / "TouchTheGlobe"
HEADER_NAME = "countries.h"

# Більше країн Uno витягне, але кожна з'їдає і флеш, і оперативну пам'ять.
# Це не жорстке обмеження, а межа, після якої варто попередити.
COMFORTABLE_LIMIT = 12


class BuildError(Exception):
    """Помилка, через яку заголовок не має сенсу створювати."""


def c_string(value):
    """Готує рядок так, щоб компілятор C++ прийняв його без сюрпризів."""
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return '"{}"'.format(escaped)


def check_country(country):
    """Помилки, через які країна не влізе в дисплей або в PROGMEM."""
    problems = []

    for field in ("lcd_name", "lcd_capital"):
        value = getattr(country, field)
        if not value:
            problems.append(
                "{}: поле {} порожнє - на дисплеї буде пусто".format(country.id, field)
            )
            continue
        if not value.isascii():
            problems.append(
                "{}: поле {} містить не латинські літери ('{}').\n"
                "     Екран Nokia 5110 кирилицю не покаже.".format(
                    country.id, field, value
                )
            )
        if len(value) > LCD_WIDTH:
            problems.append(
                "{}: поле {} має {} символів, а на дисплей вміщається {} ('{}')".format(
                    country.id, field, len(value), LCD_WIDTH, value
                )
            )

    if not country.id.isascii():
        problems.append(
            "{}: назва файлу має бути латиницею, наприклад UA.txt".format(country.id)
        )

    if not 1 <= country.track <= 255:
        problems.append(
            "{}: номер треку {} виходить за межі 1-255, які розуміє "
            "DFPlayer".format(country.id, country.track)
        )

    return problems


def render_header(catalog):
    """Збирає текст файлу countries.h."""
    countries = catalog.all()

    problems = []
    for country in countries:
        problems.extend(check_country(country))
    if problems:
        raise BuildError(
            "У файлах країн є помилки:\n  - " + "\n  - ".join(problems)
        )

    lines = [
        "// ЗГЕНЕРОВАНО автоматично. Руками не редагувати!",
        "//",
        "// Цей файл складає скрипт tools/build_arduino_data.py з файлів",
        "// content/countries/*.txt. Щоб щось тут змінити, виправ потрібний",
        "// файл країни на комп'ютері й запусти:",
        "//",
        "//     python3 tools/build_arduino_data.py",
        "",
        "#ifndef COUNTRIES_H",
        "#define COUNTRIES_H",
        "",
        "#include <Arduino.h>",
        "",
        "// Рядки лежать у флеші (PROGMEM), бо оперативної пам'яті в Uno",
        "// лише 2 кілобайти. Розпаковує їх у звичайний текст globe_engine.cpp.",
    ]

    for index, country in enumerate(countries):
        lines.append("")
        lines.append("// {} - {}".format(country.id, country.name))
        lines.append(
            "const char COUNTRY_{}_ID[] PROGMEM = {};".format(
                index, c_string(country.id)
            )
        )
        lines.append(
            "const char COUNTRY_{}_LCD_NAME[] PROGMEM = {};".format(
                index, c_string(country.lcd_name)
            )
        )
        lines.append(
            "const char COUNTRY_{}_LCD_CAPITAL[] PROGMEM = {};".format(
                index, c_string(country.lcd_capital)
            )
        )

    lines.extend(
        [
            "",
            "// Одна країна так, як її бачить плата.",
            "struct CountryData {",
            "  const char* id;",
            "  const char* lcdName;",
            "  const char* lcdCapital;",
            "  uint8_t track;  // який файл грати: 01/00X.mp3 на microSD",
            "};",
            "",
            "const uint8_t COUNTRY_COUNT = {};".format(len(countries)),
            "",
            "const CountryData COUNTRIES[COUNTRY_COUNT] PROGMEM = {",
        ]
    )

    for index, country in enumerate(countries):
        lines.append(
            "  {{COUNTRY_{0}_ID, COUNTRY_{0}_LCD_NAME, COUNTRY_{0}_LCD_CAPITAL, "
            "{1}}},".format(index, country.track)
        )

    lines.extend(["};", "", "#endif  // COUNTRIES_H", ""])

    return "\n".join(lines)


def build_parser():
    parser = argparse.ArgumentParser(
        prog="python3 tools/build_arduino_data.py",
        description="Скласти countries.h для скетча Arduino Uno.",
    )
    parser.add_argument(
        "--output",
        help="куди писати (за замовчуванням arduino/TouchTheGlobe/countries.h)",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="лише перевірити, чи файл не застарів (нічого не переписує)",
    )
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    output = Path(args.output) if args.output else SKETCH_DIR / HEADER_NAME

    try:
        catalog = load_catalog(str(ROOT / "content" / "countries"))
    except ContentError as exc:
        print("Помилка: " + str(exc))
        return 1

    try:
        header = render_header(catalog)
    except BuildError as exc:
        print("Помилка: " + str(exc))
        return 1

    existing = output.read_text(encoding="utf-8") if output.is_file() else None

    if args.check:
        if existing == header:
            print("countries.h відповідає файлам країн.")
            return 0
        print("countries.h застарів або його немає.")
        print("Онови його:  python3 tools/build_arduino_data.py")
        return 1

    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(header, encoding="utf-8")

    print("Записано: {}".format(output))
    print()
    for country in catalog:
        print(
            "  трек {:>3}  {:<4} {:<16} {}".format(
                country.track, country.id, country.lcd_name, country.lcd_capital
            )
        )
    print()
    print("Країн: {}".format(len(catalog)))

    if len(catalog) > COMFORTABLE_LIMIT:
        print()
        print(
            "Увага: країн уже {}. Для Arduino Uno це багато - стеж за тим,\n"
            "скільки пам'яті лишається після компіляції.".format(len(catalog))
        )

    print()
    print("Далі:")
    print("  1. Відкрий arduino/TouchTheGlobe/TouchTheGlobe.ino в Arduino IDE.")
    print("  2. Перевір піни кнопок у settings.py і піни у hardware_pins.h, потім make build.")
    print("  3. Залий скетч на плату (Sketch -> Upload).")

    return 0


if __name__ == "__main__":
    sys.exit(main())
