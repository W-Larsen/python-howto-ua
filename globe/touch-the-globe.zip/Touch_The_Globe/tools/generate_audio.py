#!/usr/bin/env python3
"""Озвучення текстів країн голосом ElevenLabs.

    python3 tools/generate_audio.py --all              озвучити всі країни
    python3 tools/generate_audio.py UA JP              озвучити дві країни
    python3 tools/generate_audio.py --all --dry-run    лише порахувати витрати
    python3 tools/generate_audio.py UA --force         перезаписати наявне

Безкоштовний тариф ElevenLabs дає 10 000 символів на місяць, тому скрипт
спочатку показує, скільки символів витратиться, і чекає підтвердження.
Уже озвучені країни пропускаються.
"""

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from globe_core.catalog import ContentError, load_catalog  # noqa: E402
from pc.audio_elevenlabs import ElevenLabsError, TextToSpeech  # noqa: E402
from pc.config import ConfigError, load_config  # noqa: E402

FREE_TIER_CREDITS = 10000


def build_parser():
    parser = argparse.ArgumentParser(
        prog="python3 tools/generate_audio.py",
        description="Озвучити тексти країн через ElevenLabs.",
    )
    parser.add_argument(
        "country", nargs="*", help="ID країн, наприклад UA JP. Або використай --all"
    )
    parser.add_argument("--all", action="store_true", help="усі країни з каталогу")
    parser.add_argument(
        "--force", action="store_true", help="перезаписати вже озвучене"
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="тільки показати, скільки символів витратиться",
    )
    parser.add_argument(
        "--yes", "-y", action="store_true", help="не питати підтвердження"
    )
    return parser


def choose_countries(catalog, args):
    if args.all:
        return catalog.all()
    if not args.country:
        raise ContentError(
            "Не вказано, що озвучувати.\n"
            "  Приклади:\n"
            "    python3 tools/generate_audio.py --all\n"
            "    python3 tools/generate_audio.py UA JP"
        )
    return [catalog.require(country_id) for country_id in args.country]


def main(argv=None):
    args = build_parser().parse_args(argv)

    try:
        config = load_config(root=ROOT)
    except ConfigError as exc:
        print("Помилка: " + str(exc))
        return 1

    try:
        catalog = load_catalog(str(config.countries_dir))
        countries = choose_countries(catalog, args)
    except ContentError as exc:
        print("Помилка: " + str(exc))
        return 1

    tts = TextToSpeech(config)

    todo = []
    skipped = []
    for country in countries:
        if not args.force and tts.cached_country(country) is not None:
            skipped.append(country)
        else:
            todo.append(country)

    if skipped:
        print("Вже озвучено, пропускаю: {}".format(", ".join(c.id for c in skipped)))
        print("(щоб перезаписати, додай --force)")
        print()

    if not todo:
        print("Нічого озвучувати - усе вже готово.")
        return 0

    total = 0
    print("Буде озвучено:")
    for country in todo:
        characters = len(country.text)
        total += characters
        print(
            "  {:<4} {:<26} {:>5} символів".format(
                country.id, country.name, characters
            )
        )
    print()
    print(
        "Разом: {} символів = {} кредитів ElevenLabs "
        "(безкоштовно на місяць дається {}).".format(
            total, total, FREE_TIER_CREDITS
        )
    )

    if args.dry_run:
        print("Це був --dry-run, нічого не витрачено.")
        return 0

    try:
        tts.client.check_ready()
    except ElevenLabsError as exc:
        print()
        print("Помилка: " + str(exc))
        return 1

    if not args.yes:
        print()
        answer = input("Озвучувати? [так/ні] ").strip().lower()
        if answer not in ("так", "т", "yes", "y", "да"):
            print("Скасовано.")
            return 0

    print()
    done = 0
    failed = False
    for country in todo:
        print("Озвучую {} ({})... ".format(country.id, country.name), end="", flush=True)
        try:
            path = tts.ensure_country(country, force=True)
        except ElevenLabsError as exc:
            print("не вдалося")
            print(str(exc))
            # Найчастіше причина одна на всіх (немає ключа, скінчилися
            # кредити), тому далі сервер не мучимо.
            failed = True
            break
        except KeyboardInterrupt:
            print("перервано")
            return 130
        done += 1
        print("готово -> {}".format(path.relative_to(ROOT)))

    print()
    print("Озвучено файлів: {} з {}".format(done, len(todo)))
    if failed:
        return 1

    print("Перевірити на слух:  python3 globe.py list, потім globe press з потрібною кнопкою")
    print("Оновити SD-картку:   python3 tools/build_sd_card.py")
    return 0


if __name__ == "__main__":
    sys.exit(main())
