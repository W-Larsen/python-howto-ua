#!/usr/bin/env python3
"""Перевірка файлів країн.

    python3 tools/validate_content.py

Читає всі файли з content/countries/ і перевіряє те, що інакше
виявиться лише під час уроку: чи вміщаються назви на дисплей, чи всі
поля заповнені, чи не забуто озвучення.
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from globe_core.catalog import LCD_WIDTH, ContentError, load_catalog  # noqa: E402
from pc.audio_local import find_audio_file  # noqa: E402
from pc.config import ConfigError, load_config  # noqa: E402

# Довший текст ElevenLabs озвучить, але це вже 1 кредит за символ,
# та й слухати хвилинну розповідь на уроці нікому.
LONG_TEXT = 700


def check(country):
    """Повертає (список помилок, список зауважень) для однієї країни."""
    errors = []
    warnings = []

    for field in ("lcd_name", "lcd_capital"):
        value = getattr(country, field)
        if not value:
            errors.append("{}: поле {} порожнє".format(country.id, field))
            continue
        if not value.isascii():
            errors.append(
                "{}: поле {} містить не латинські літери ('{}').\n"
                "     Екран Nokia 5110 кирилицю не покаже.".format(
                    country.id, field, value
                )
            )
        if len(value) > LCD_WIDTH:
            errors.append(
                "{}: поле {} має {} символів, а на дисплей вміщається {} ('{}')".format(
                    country.id, field, len(value), LCD_WIDTH, value
                )
            )

    if not country.capital:
        warnings.append("{}: не вказано capital".format(country.id))
    if not country.continent:
        warnings.append("{}: не вказано continent".format(country.id))

    if len(country.text) > LONG_TEXT:
        warnings.append(
            "{}: текст довгий ({} символів). Це {} кредитів ElevenLabs\n"
            "     і майже хвилина розповіді.".format(
                country.id, len(country.text), len(country.text)
            )
        )

    if not country.id.isascii() or not country.id.isupper():
        warnings.append(
            "{}: назву файлу прийнято писати великими латинськими "
            "літерами, наприклад UA.txt".format(country.id)
        )

    return errors, warnings


def main():
    try:
        config = load_config(root=ROOT)
    except ConfigError as exc:
        print("Помилка: " + str(exc))
        return 1

    print("Папка з країнами: {}".format(config.countries_dir))
    try:
        catalog = load_catalog(str(config.countries_dir))
    except ContentError as exc:
        print()
        print("Помилка: " + str(exc))
        return 1

    if not len(catalog):
        print("Жодної країни не знайдено.")
        print("Створи файл content/countries/UA.txt за зразком _TEMPLATE.txt")
        return 1

    all_errors = []
    all_warnings = []
    print()
    for country in catalog:
        errors, warnings = check(country)
        all_errors.extend(errors)
        all_warnings.extend(warnings)

        has_manual = find_audio_file(config.audio_dir, country.id) is not None
        has_tts = find_audio_file(config.tts_cache_dir, country.id) is not None
        if has_manual:
            audio = "запис"
        elif has_tts:
            audio = "голос ElevenLabs"
        else:
            audio = "немає"

        mark = "!" if errors else " "
        print(
            "{} трек {:>3}  {:<4} {:<24} {:<16} {:<16} аудіо: {}".format(
                mark,
                country.track,
                country.id,
                country.name,
                country.lcd_name,
                country.lcd_capital,
                audio,
            )
        )

    print()
    print("Країн: {}".format(len(catalog)))
    print("Символів тексту разом: {}".format(sum(len(c.text) for c in catalog)))

    if all_errors:
        print()
        print("=== Помилки ({}) ===".format(len(all_errors)))
        for item in all_errors:
            print("  - " + item)

    if all_warnings:
        print()
        print("=== Зауваження ({}) ===".format(len(all_warnings)))
        for item in all_warnings:
            print("  - " + item)

    print()
    if all_errors:
        print("Треба виправити помилки, інакше на дисплеї буде не те, що треба.")
        return 1

    print("Усе гаразд." if not all_warnings else "Помилок немає.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
