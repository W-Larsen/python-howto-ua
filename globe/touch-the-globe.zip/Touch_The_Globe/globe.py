#!/usr/bin/env python3
"""Команди глобуса: python3 globe.py run | press 1 2 | test | list | build.

На Windows те саме запускає globe.bat (globe run), на Mac - make (make run).
"""

import sys

from pc.cli import main

if __name__ == "__main__":
    sys.exit(main())
