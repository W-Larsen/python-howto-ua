"""Читання країн із папки content/countries/.

Кожна країна - це один текстовий файл, наприклад content/countries/UA.txt:

    name: Україна
    capital: Київ
    continent: Європа
    lcd_name: Ukraine
    lcd_capital: Kyiv
    ---
    Україна - найбільша країна, яка повністю розташована в Європі.

До розділювача "---" ідуть рядки "ключ: значення", після нього - текст,
який глобус розповідає. Центрального списку країн немає: програма сама
знаходить усі файли в папці, тому нова країна додається одним файлом.
"""

import os

# Назви режимів у тому порядку, в якому блоки тексту йдуть у файлі країни.
# Другий і третій блоки не обов'язкові: якщо їх немає, використовується перший.
MODES = ("facts", "story", "quiz")

SEPARATOR = "---"

# Скільки символів вміщає один рядок екрана Nokia 5110:
# 84 точки завширшки / 6 точок на літеру = 14.
LCD_WIDTH = 14


class ContentError(Exception):
    """Помилка у файлі країни. Повідомлення пишемо українською - для учнів."""


def join_path(directory, name):
    """Склеює шлях із назви папки й назви файлу."""
    if directory.endswith("/"):
        return directory + name
    return directory + "/" + name


class Country:
    """Одна країна: дані із заголовка файлу та текст для озвучення."""

    def __init__(self, country_id, fields, texts, track=0):
        self.id = country_id
        self.name = fields.get("name", country_id)
        self.capital = fields.get("capital", "")
        self.continent = fields.get("continent", "")
        # Латинські варіанти потрібні тому, що Nokia 5110 не вміє кирилиці.
        self.lcd_name = fields.get("lcd_name", country_id)
        self.lcd_capital = fields.get("lcd_capital", self.lcd_name)
        self.texts = texts
        self.track = track

    @property
    def text(self):
        """Основний текст (режим facts)."""
        return self.texts[0] if self.texts else ""

    def text_for_mode(self, mode):
        """Текст для вказаного режиму, з відкатом на основний."""
        if mode in MODES:
            index = MODES.index(mode)
            if index < len(self.texts) and self.texts[index]:
                return self.texts[index]
        return self.text

    def __repr__(self):
        return "<Country {} {}>".format(self.id, self.name)


def parse_country_file(country_id, raw):
    """Розбирає вміст файлу країни. Повертає (fields, texts)."""
    lines = raw.replace("\r\n", "\n").replace("\r", "\n").split("\n")

    # Спочатку шукаємо розділювач. Якщо його немає, немає сенсу розбирати
    # заголовок: учень майже напевно просто забув рядок "---", і сказати
    # про це прямо набагато корисніше, ніж скаржитись на текст розповіді.
    body_start = None
    for index in range(len(lines)):
        if lines[index].strip() == SEPARATOR:
            body_start = index + 1
            break

    if body_start is None:
        raise ContentError(
            "Файл країни {}: не знайдено розділювач '---'.\n"
            "  Файл має виглядати так:\n"
            "      name: Канада\n"
            "      capital: Оттава\n"
            "      ---\n"
            "      Канада - друга за площею країна світу.\n"
            "  Тобто спочатку рядки 'ключ: значення', потім окремий рядок '---',\n"
            "  а вже після нього - текст, який глобус розповідає.".format(country_id)
        )

    fields = {}
    for index in range(body_start - 1):
        line = lines[index].strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            raise ContentError(
                "Файл країни {}: рядок {} не схожий на 'ключ: значення'.\n"
                "  Отримано: {}\n"
                "  Приклад правильного рядка: name: Канада\n"
                "  Якщо це вже початок розповіді, перенеси рядок '---' вище.".format(
                    country_id, index + 1, line
                )
            )
        key, value = line.split(":", 1)
        fields[key.strip().lower()] = value.strip()

    if not fields.get("name"):
        raise ContentError(
            "Файл країни {}: немає обов'язкового рядка 'name'.\n"
            "  Додай на початку файлу, наприклад: name: Канада".format(country_id)
        )

    texts = _split_sections(lines[body_start:])
    if not texts or not texts[0]:
        raise ContentError(
            "Файл країни {}: після '---' немає тексту.\n"
            "  Напиши хоча б одне речення - саме його глобус і розповість.".format(
                country_id
            )
        )

    track = 0
    if "track" in fields:
        try:
            track = int(fields["track"])
        except ValueError:
            raise ContentError(
                "Файл країни {}: 'track' має бути числом, а не '{}'.".format(
                    country_id, fields["track"]
                )
            )
        if track < 1:
            raise ContentError(
                "Файл країни {}: 'track' має бути числом від 1 і більше.".format(
                    country_id
                )
            )
    fields["track"] = track

    return fields, texts


def _split_sections(body_lines):
    """Ділить текст на блоки по рядках '---' (для режимів facts/story/quiz)."""
    sections = []
    current = []
    for line in body_lines:
        if line.strip() == SEPARATOR:
            sections.append("\n".join(current).strip())
            current = []
        else:
            current.append(line)
    sections.append("\n".join(current).strip())
    return sections


def _is_country_file(name):
    if not name.endswith(".txt"):
        return False
    # Файли, що починаються з "_" або ".", - службові (наприклад _TEMPLATE.txt).
    return not (name.startswith("_") or name.startswith("."))


def _assign_tracks(countries):
    """Дає кожній країні номер треку для DFPlayer.

    Спочатку закріплюються номери, вказані вручну через 'track:' у файлі,
    решта отримує найменші вільні числа в алфавітному порядку ID.
    """
    taken = {}
    for country in countries:
        if country.track:
            if country.track in taken:
                raise ContentError(
                    "Дві країни ({} і {}) хочуть однаковий track: {}.\n"
                    "  Прибери рядок 'track:' з одного з файлів - номери\n"
                    "  розставляться автоматично.".format(
                        taken[country.track], country.id, country.track
                    )
                )
            taken[country.track] = country.id

    next_free = 1
    for country in countries:
        if country.track:
            continue
        while next_free in taken:
            next_free += 1
        country.track = next_free
        taken[next_free] = country.id


class Catalog:
    """Усі знайдені країни. Пошук за ID не залежить від регістру."""

    def __init__(self, countries):
        self._countries = countries
        self._by_id = {}
        for country in countries:
            self._by_id[country.id.upper()] = country

    def __len__(self):
        return len(self._countries)

    def __iter__(self):
        return iter(self._countries)

    def all(self):
        return list(self._countries)

    def ids(self):
        return [country.id for country in self._countries]

    def has(self, country_id):
        return country_id is not None and country_id.upper() in self._by_id

    def get(self, country_id):
        """Повертає країну або None, якщо такої немає."""
        if country_id is None:
            return None
        return self._by_id.get(country_id.upper())

    def require(self, country_id):
        """Повертає країну або кидає зрозумілу помилку зі списком наявних."""
        country = self.get(country_id)
        if country is None:
            raise ContentError(
                "Немає країни з ID '{}'.\n"
                "  Доступні: {}\n"
                "  Щоб додати нову, створи файл content/countries/{}.txt".format(
                    country_id,
                    ", ".join(self.ids()) if self._countries else "(жодної)",
                    str(country_id).upper(),
                )
            )
        return country

    def by_track(self, track):
        for country in self._countries:
            if country.track == track:
                return country
        return None


def load_country(path, country_id):
    """Читає й розбирає один файл країни."""
    try:
        handle = open(path, "r", encoding="utf-8-sig")
        try:
            raw = handle.read()
        finally:
            handle.close()
    except UnicodeDecodeError:
        raise ContentError(
            "Файл країни {}: збережено не в кодуванні UTF-8. "
            "У Блокноті: Файл -> Зберегти як -> Кодування: UTF-8.".format(country_id)
        )
    except OSError:
        raise ContentError("Не вдалося відкрити файл країни: {}".format(path))

    fields, texts = parse_country_file(country_id, raw)
    return Country(country_id, fields, texts, fields.get("track", 0))


def load_catalog(countries_dir):
    """Знаходить і читає всі країни в папці.

    Порядок завжди алфавітний за ID, щоб номери треків на SD-картці
    не залежали від того, у якому порядку операційна система віддала файли.
    """
    try:
        names = os.listdir(countries_dir)
    except OSError:
        raise ContentError(
            "Немає папки з країнами: {}\n"
            "  Перевір, що ти запускаєш команду з кореня проєкту "
            "Touch_The_Globe.".format(countries_dir)
        )

    names = [name for name in names if _is_country_file(name)]
    names.sort()

    countries = []
    for name in names:
        country_id = name[:-4]
        countries.append(load_country(join_path(countries_dir, name), country_id))

    _assign_tracks(countries)
    return Catalog(countries)
