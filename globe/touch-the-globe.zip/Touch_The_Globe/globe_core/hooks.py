"""Що пишуть учні і що ми їм даємо.

Одна таблиця на всіх: її читають перевірка коду (globe test), перекладач
у C++ і ядро глобуса. Тому назва хука чи функції змінюється тут - і
більше ніде.

Хук - функція, яку пише учень, а викликає глобус (on_button, question...).
Функція API - навпаки: її дали ми, а викликає учень (show_text, ask...).
"""

from globe_core.catalog import LCD_WIDTH

SCREEN_ROWS = 6
ASK_MAX_LENGTH = 42
# Скільки разів може повторитися while, перш ніж глобус вирішить, що цикл
# ніколи не закінчиться.
LOOP_LIMIT = 1000
# Захист від вікторини, яка ставить питання завжди.
QUIZ_MAX_QUESTIONS = 50

TASK_FILES = ("task1.py", "task2.py", "task3.py", "task4.py", "task5.py")

# Типи значень у мові учнів.
INT = "int"
STR = "str"
BOOL = "bool"
COUNTRY = "country"

ALL_ROWS = tuple(range(SCREEN_ROWS))


class Hook:
    """Функція, яку пише учень, а викликає глобус."""

    def __init__(self, name, file, params, rows):
        self.name = name
        self.file = file
        # (("number", INT),) - назви з картки задачі й типи значень.
        self.params = params
        # Рядки дисплея, які за домовленістю "належать" цьому хуку.
        self.rows = rows

    @property
    def task_number(self):
        return TASK_FILES.index(self.file) + 1


HOOK_LIST = (
    Hook("on_button", "task1.py", (("number", INT),), ALL_ROWS),
    Hook("hello_screen", "task1.py", (), ALL_ROWS),
    Hook("next_target", "task2.py", (("round", INT),), (2, 3, 4)),
    Hook("on_hit", "task2.py", (("correct", BOOL), ("ms", INT)), (2, 3, 4)),
    Hook("game_over", "task2.py", (("score", INT), ("rounds", INT)), (0, 1, 2, 3, 4)),
    Hook("question", "task3.py", (("number", INT),), (3, 4)),
    Hook("on_answer", "task3.py", (("correct", BOOL), ("score", INT)), (3, 4)),
    Hook("final", "task3.py", (("score", INT), ("total", INT)), (0, 1, 2, 3, 4)),
    Hook("show_fact", "task4.py", (("country", COUNTRY),), (2, 3, 4)),
    Hook("loading", "task5.py", (), ALL_ROWS),
)

HOOKS = {hook.name: hook for hook in HOOK_LIST}


def hooks_for_file(file):
    return [hook for hook in HOOK_LIST if hook.file == file]


class ApiFunction:
    """Функція, яку ми дали учням."""

    def __init__(
        self,
        name,
        params,
        returns=None,
        only_in=None,
        row_arg=None,
        text_args=None,
        id_args=(),
        not_in=None,
        not_in_hint="",
    ):
        self.name = name
        self.params = params
        self.returns = returns
        # Назва хука, у якому функцію можна викликати, або None - будь-де.
        self.only_in = only_in
        # Назва хука, у якому функцію викликати НЕ можна, і підказка, як інакше.
        self.not_in = not_in
        self.not_in_hint = not_in_hint
        # Номер значення, яке є рядком дисплея (для перевірки 0-5).
        self.row_arg = row_arg
        # {номер значення: найбільша довжина} - текст, що йде на екран.
        self.text_args = text_args or {}
        # Номери значень, які є ID країни.
        self.id_args = id_args


API_LIST = (
    ApiFunction("play_sound", (STR,), id_args=(0,)),
    # show_country() сама викликає show_fact(): усередині show_fact() це
    # був би нескінченний виклик, і плата перезавантажилася б.
    ApiFunction(
        "show_country",
        (STR,),
        id_args=(0,),
        not_in="show_fact",
        not_in_hint="країну вже показано - тут додай лише текст, наприклад show_text(2, ...)",
    ),
    ApiFunction("show_text", (INT, STR), row_arg=0, text_args={1: LCD_WIDTH}),
    ApiFunction("clear_screen", ()),
    ApiFunction("blink", (INT,)),
    ApiFunction("wait", (INT,)),
    ApiFunction("random_number", (INT, INT), returns=INT),
    ApiFunction(
        "target",
        (STR, STR),
        only_in="next_target",
        id_args=(0,),
        text_args={1: LCD_WIDTH},
    ),
    ApiFunction(
        "ask",
        (STR, STR),
        only_in="question",
        id_args=(1,),
        text_args={0: ASK_MAX_LENGTH},
    ),
)

API = {function.name: function for function in API_LIST}

# Поля країни: як їх пише учень -> як вони називаються в C++.
COUNTRY_FIELDS = {"id": "id", "lcd_name": "lcdName", "lcd_capital": "lcdCapital"}

# Вбудовані функції Python, які лишаються учням.
BUILTINS = ("str", "print", "range")
