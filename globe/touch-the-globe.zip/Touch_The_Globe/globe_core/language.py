"""Перевірка коду учня: чи це та "мова глобуса", яку розуміє перекладач.

Учні пишуть звичайний Python, але плата Python не розуміє: код
перекладає в C++ tools/build_student_code.py. Перекласти можна не все,
тому тут ми обходимо код рядок за рядком і для кожної конструкції
вирішуємо: можна, не можна (і як переписати) або можна, але з
попередженням.

Результат - TaskInfo: які хуки є у файлі, які в них змінні і якого вони
типу. Ним користуються перекладач у C++, завантажувач коду на комп'ютері
і команда globe test - тому правила скрізь однакові.
"""

import ast
import difflib
import re
from pathlib import Path

from globe_core.hooks import (
    API,
    BOOL,
    BUILTINS,
    COUNTRY,
    COUNTRY_FIELDS,
    HOOKS,
    INT,
    SCREEN_ROWS,
    STR,
    TASK_FILES,
    hooks_for_file,
)
from globe_core.problems import ERROR, WARNING, Problem

TYPE_NAMES = {INT: "число", STR: "рядок", BOOL: "True/False", COUNTRY: "країна"}

# Назви змінних - лише латиниця: компілятор Arduino іншого не прийме.
ASCII_NAME = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")

ARITHMETIC = (ast.Add, ast.Sub, ast.Mult, ast.FloorDiv, ast.Mod)
ORDERING = (ast.Lt, ast.LtE, ast.Gt, ast.GtE)

COLLECTIONS = (
    ast.List,
    ast.Tuple,
    ast.Dict,
    ast.Set,
    ast.ListComp,
    ast.DictComp,
    ast.SetComp,
    ast.GeneratorExp,
)


class Context:
    """Що треба знати про проєкт, щоб перевірити код учня."""

    def __init__(self, country_ids=(), button_count=5):
        self.country_ids = {str(country_id).upper() for country_id in country_ids}
        self.button_count = button_count


class FunctionInfo:
    """Один хук, написаний учнем."""

    def __init__(self, hook, node, file):
        self.hook = hook
        self.node = node
        self.file = file
        # Учень може назвати параметри по-своєму - тип береться з таблиці.
        self.params = [
            (arg.arg, param_type)
            for arg, (_, param_type) in zip(node.args.args, hook.params)
        ]
        # Змінні в порядку першого присвоєння: {назва: тип}.
        self.variables = {}

    @property
    def name(self):
        return self.hook.name

    @property
    def line(self):
        return self.node.lineno

    def scope(self):
        scope = dict(self.params)
        scope.update(self.variables)
        return scope


class TaskInfo:
    """Один файл taskN.py: які хуки в ньому написані."""

    def __init__(self, file):
        self.file = file
        self.functions = {}


def literal_int(node):
    """Число, написане прямо в коді (5 або -5), або None."""
    if isinstance(node, ast.Constant) and type(node.value) is int:
        return node.value
    if (
        isinstance(node, ast.UnaryOp)
        and isinstance(node.op, ast.USub)
        and isinstance(node.operand, ast.Constant)
        and type(node.operand.value) is int
    ):
        return -node.operand.value
    return None


def literal_str(node):
    """Текст у лапках, написаний прямо в коді, або None."""
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    return None


IMPORT_HINT = "import не потрібен: усі наші функції вже доступні"


def is_api_import(node):
    """Рядок  from globe_api import *  - лише для підказок у редакторі (globe_api.py у корені)."""
    return (
        isinstance(node, ast.ImportFrom)
        and node.module == "globe_api"
        and node.level == 0
        and [alias.name for alias in node.names] == ["*"]
    )


def _is_docstring(node):
    return isinstance(node, ast.Expr) and literal_str(node.value) is not None


class _Checker:
    """Обходить один файл і збирає проблеми."""

    def __init__(self, file, context):
        self.file = file
        self.context = context
        self.problems = []
        self.info = None
        self.defined = {}
        self.loop_depth = 0

    # -- повідомлення ----------------------------------------------------
    def error(self, node, message):
        self.problems.append(Problem(message, self.file, getattr(node, "lineno", None), ERROR))
        return None

    def warning(self, node, message):
        self.problems.append(Problem(message, self.file, getattr(node, "lineno", None), WARNING))

    # -- функція ---------------------------------------------------------
    def signature_ok(self, node, hook):
        args = node.args
        expected = "def {}({})".format(hook.name, ", ".join(name for name, _ in hook.params))
        if node.decorator_list:
            self.error(node, "декоратори (@...) не підтримуються. Пиши просто: " + expected)
            return False
        extra = (
            args.posonlyargs or args.vararg or args.kwonlyargs or args.kwarg or args.defaults
        )
        if extra or len(args.args) != len(hook.params):
            self.error(node, "{}() має приймати рівно такі значення: {}".format(hook.name, expected))
            return False
        names = [arg.arg for arg in args.args]
        if len(set(names)) != len(names):
            self.error(node, "параметри мають мати різні назви: {}".format(expected))
            return False
        for arg in args.args:
            if not self.valid_name(arg, arg.arg):
                return False
        return True

    def check_function(self, info):
        self.info = info
        self.defined = dict(info.params)
        self.loop_depth = 0
        self.statements(info.node.body)

    def valid_name(self, node, name):
        if name.startswith("_"):
            self.error(node, "назва {} не може починатися з _".format(name))
            return False
        if not ASCII_NAME.match(name):
            self.error(
                node,
                "назва {} має бути латиницею (літери, цифри, _): плата інших не розуміє".format(name),
            )
            return False
        if name in API or name in BUILTINS or name in HOOKS:
            self.error(node, "{} - це назва нашої функції. Назви змінну інакше".format(name))
            return False
        return True

    # -- інструкції ------------------------------------------------------
    def statements(self, body):
        for node in body:
            self.statement(node)

    def statement(self, node):
        if _is_docstring(node):
            return
        if isinstance(node, ast.Expr):
            if isinstance(node.value, ast.Call):
                self.call(node.value, as_statement=True)
            else:
                self.error(node, "цей рядок нічого не робить: результат обчислення ніде не використано")
        elif isinstance(node, ast.Assign):
            if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
                self.error(node, "присвоювати можна лише одній змінній: x = 5")
                return
            value_type = self.expr(node.value)
            if value_type is not None:
                self.assign(node.targets[0], value_type)
        elif isinstance(node, ast.AugAssign):
            self.aug_assign(node)
        elif isinstance(node, ast.AnnAssign):
            self.error(node, "типи змінних писати не треба: просто x = 5")
        elif isinstance(node, ast.If):
            self.condition(node.test)
            self.statements(node.body)
            self.statements(node.orelse)
        elif isinstance(node, ast.For):
            self.for_loop(node)
        elif isinstance(node, ast.While):
            if node.orelse:
                self.error(node, "while ... else не підтримується")
            self.condition(node.test)
            self.loop_depth += 1
            self.statements(node.body)
            self.loop_depth -= 1
        elif isinstance(node, ast.Return):
            if node.value is not None:
                self.error(node, "хук нічого не повертає: пиши просто return")
        elif isinstance(node, ast.Pass):
            pass
        elif isinstance(node, (ast.Break, ast.Continue)):
            if self.loop_depth == 0:
                self.error(node, "break і continue працюють лише всередині циклу")
        elif isinstance(node, (ast.Import, ast.ImportFrom)):
            self.error(node, IMPORT_HINT)
        elif isinstance(node, (ast.Global, ast.Nonlocal)):
            self.error(node, "глобальні змінні не підтримуються: зберігай усе в змінних усередині функції")
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            self.error(node, "функцію всередині функції писати не можна")
        elif isinstance(node, ast.Try):
            self.error(node, "try/except не потрібен: глобус сам ловить помилки")
        else:
            self.error(node, "така конструкція не підтримується: {}".format(type(node).__name__))

    def assign(self, target, value_type):
        name = target.id
        if not self.valid_name(target, name):
            return
        if value_type == COUNTRY:
            self.error(target, "країну не можна класти в іншу змінну: користуйся country напряму")
            return
        current = self.defined.get(name)
        if current is None:
            self.defined[name] = value_type
            self.info.variables[name] = value_type
            return
        if current == COUNTRY:
            self.error(target, "{} - це країна, її не можна змінювати".format(name))
        elif current != value_type:
            self.error(
                target,
                "змінна {} була {}, а тут їй дають {}. Візьми для цього іншу назву".format(
                    name, TYPE_NAMES[current], TYPE_NAMES[value_type]
                ),
            )

    def aug_assign(self, node):
        target = node.target
        if not isinstance(target, ast.Name):
            self.error(node, "змінювати можна лише звичайну змінну: x += 1")
            return
        current = self.defined.get(target.id)
        if current is None:
            self.error(
                node,
                "змінна {} ще не має значення: спочатку напиши {} = ...".format(target.id, target.id),
            )
            return
        value_type = self.expr(node.value)
        if value_type is None:
            return
        result = self.binop_type(node.op, current, value_type, node)
        if result is not None and result != current:
            self.error(
                node,
                "змінна {} була {}, а стала б {}".format(
                    target.id, TYPE_NAMES[current], TYPE_NAMES[result]
                ),
            )

    def for_loop(self, node):
        if node.orelse:
            self.error(node, "for ... else не підтримується")
        call = node.iter
        if not (
            isinstance(call, ast.Call)
            and isinstance(call.func, ast.Name)
            and call.func.id == "range"
        ):
            self.error(node, "for працює лише з range: for i in range(5)")
            return
        if not isinstance(node.target, ast.Name):
            self.error(node, "після for має бути одна змінна: for i in range(5)")
            return
        if call.keywords or not 1 <= len(call.args) <= 3:
            self.error(node, "range приймає від 1 до 3 чисел: range(5), range(1, 6), range(10, 0, -1)")
            return
        for arg in call.args:
            arg_type = self.expr(arg)
            if arg_type is not None and arg_type != INT:
                self.error(arg, "range працює лише з числами")
        if len(call.args) == 3:
            step = literal_int(call.args[2])
            if step is None:
                self.error(call.args[2], "крок у range має бути написаний числом, наприклад range(10, 0, -1)")
            elif step == 0:
                self.error(call.args[2], "крок у range не може бути 0")
        self.assign(node.target, INT)
        self.loop_depth += 1
        self.statements(node.body)
        self.loop_depth -= 1

    def condition(self, node):
        value_type = self.expr(node)
        if value_type == STR:
            self.error(node, 'умова не може бути просто рядком: порівняй його, наприклад x == "UA"')
        elif value_type == COUNTRY:
            self.error(node, 'умова не може бути країною: порівнюй country.id == "UA"')

    # -- вирази ----------------------------------------------------------
    def expr(self, node):
        if isinstance(node, ast.Constant):
            return self.constant(node)
        if isinstance(node, ast.Name):
            return self.name(node)
        if isinstance(node, ast.Attribute):
            return self.attribute(node)
        if isinstance(node, ast.BinOp):
            left = self.expr(node.left)
            right = self.expr(node.right)
            if left is None or right is None:
                return None
            return self.binop_type(node.op, left, right, node)
        if isinstance(node, ast.UnaryOp):
            return self.unary(node)
        if isinstance(node, ast.BoolOp):
            ok = True
            for value in node.values:
                value_type = self.expr(value)
                if value_type == INT:
                    self.error(
                        value,
                        "and/or працюють з умовами: порівняй число, наприклад x != 0 and y > 0",
                    )
                    ok = False
                elif value_type in (STR, COUNTRY):
                    self.error(value, 'and/or працюють з умовами: порівняй рядок, наприклад x == "UA"')
                    ok = False
                elif value_type is None:
                    ok = False
            return BOOL if ok else None
        if isinstance(node, ast.Compare):
            return self.compare(node)
        if isinstance(node, ast.Call):
            return self.call(node, as_statement=False)
        if isinstance(node, ast.JoinedStr):
            return self.error(node, 'f-рядки не підтримуються: склей через + і str(), наприклад "Score " + str(score)')
        if isinstance(node, COLLECTIONS):
            return self.error(node, "списки й словники не підтримуються: використовуй if/elif")
        if isinstance(node, ast.Subscript):
            return self.error(node, "квадратні дужки [] не підтримуються")
        if isinstance(node, ast.IfExp):
            return self.error(node, "x if ... else ... не підтримується: напиши звичайний if")
        return self.error(node, "такий вираз не підтримується: {}".format(type(node).__name__))

    def constant(self, node):
        value = node.value
        if isinstance(value, bool):
            return BOOL
        if isinstance(value, int):
            return INT
        if isinstance(value, str):
            return STR
        if isinstance(value, float):
            return self.error(node, "дробові числа не підтримуються: плата рахує цілими")
        if value is None:
            return self.error(node, "None тут не потрібне")
        return self.error(node, "таке значення не підтримується: {!r}".format(value))

    def name(self, node):
        if node.id in self.defined:
            return self.defined[node.id]
        if node.id in API or node.id in BUILTINS:
            return self.error(node, "{} - це функція: не забудь дужки, {}(...)".format(node.id, node.id))
        message = "змінна {} ще не має значення: спочатку присвой їй щось".format(node.id)
        hint = difflib.get_close_matches(node.id, list(self.defined), n=1)
        if hint:
            message += ". Можливо, тут має бути {}?".format(hint[0])
        return self.error(node, message)

    def attribute(self, node):
        if isinstance(node.value, ast.Name) and self.defined.get(node.value.id) == COUNTRY:
            if node.attr in COUNTRY_FIELDS:
                return STR
            return self.error(
                node,
                "у країни є лише {}".format(", ".join("country." + field for field in COUNTRY_FIELDS)),
            )
        return self.error(
            node, "крапка працює лише з країною: country.id. Методи на кшталт .upper() не підтримуються"
        )

    def unary(self, node):
        value_type = self.expr(node.operand)
        if value_type is None:
            return None
        if isinstance(node.op, ast.Not):
            if value_type in (STR, COUNTRY):
                return self.error(node, "not працює з умовами, а не з рядками")
            return BOOL
        if isinstance(node.op, (ast.USub, ast.UAdd)):
            if value_type != INT:
                return self.error(node, "мінус ставиться лише перед числом")
            return INT
        return self.error(node, "оператор ~ не підтримується")

    def binop_type(self, op, left, right, node):
        if isinstance(op, ast.Div):
            return self.error(node, "/ дає дробове число, а плата рахує цілими: використай // (ділення націло)")
        if isinstance(op, ast.Pow):
            return self.error(node, "** не підтримується: помнож число саме на себе")
        if not isinstance(op, ARITHMETIC):
            return self.error(node, "такий оператор не підтримується")
        if COUNTRY in (left, right):
            return self.error(node, "з країною не можна рахувати: бери country.id або country.lcd_name")
        if BOOL in (left, right):
            return self.error(node, "True/False не можна використовувати в арифметиці")
        if isinstance(op, ast.Add):
            if left == right:
                return left
            return self.error(node, 'не можна додати рядок і число: загорни число в str(), наприклад "x" + str(count)')
        if STR in (left, right):
            if isinstance(op, ast.Mult):
                return self.error(node, "рядок не можна множити: склей його в циклі for")
            return self.error(node, "з рядками працює лише +")
        if isinstance(op, (ast.FloorDiv, ast.Mod)):
            divisor = node.value if isinstance(node, ast.AugAssign) else node.right
            if literal_int(divisor) == 0:
                return self.error(
                    divisor,
                    "ділити на нуль не можна: на платі вийде 0, а на комп'ютері - помилка",
                )
        return INT

    def compare(self, node):
        if len(node.ops) != 1:
            return self.error(node, "подвійне порівняння не підтримується: напиши 0 < x and x < 5")
        op = node.ops[0]
        if isinstance(op, (ast.In, ast.NotIn)):
            return self.error(node, "in не підтримується: порівняй кожне значення через ==")
        if isinstance(op, (ast.Is, ast.IsNot)):
            return self.error(node, "замість is пиши ==, замість is not пиши !=")
        right_node = node.comparators[0]
        left = self.expr(node.left)
        right = self.expr(right_node)
        if left is None or right is None:
            return None
        if COUNTRY in (left, right):
            return self.error(node, 'країну не можна порівнювати цілком: порівнюй country.id == "UA"')
        if isinstance(op, ORDERING):
            if left != INT or right != INT:
                return self.error(node, "<, >, <=, >= працюють лише з числами")
        elif left != right:
            return self.error(
                node,
                "порівнюєш {} і {}: така умова ніколи не справдиться. Перевір лапки".format(
                    TYPE_NAMES[left], TYPE_NAMES[right]
                ),
            )
        if isinstance(op, ast.Eq):
            self.check_button_number(node.left, right_node)
            self.check_button_number(right_node, node.left)
        return BOOL

    def check_button_number(self, name_node, value_node):
        """У on_button: if number == 7, а кнопок 5 - попередження."""
        if self.info is None or self.info.name != "on_button" or not self.info.params:
            return
        if not (isinstance(name_node, ast.Name) and name_node.id == self.info.params[0][0]):
            return
        number = literal_int(value_node)
        if number is not None and not 1 <= number <= self.context.button_count:
            self.warning(
                value_node,
                "кнопки {} немає: у settings.py їх лише {}".format(number, self.context.button_count),
            )

    # -- виклики ---------------------------------------------------------
    def call(self, node, as_statement):
        func = node.func
        if isinstance(func, ast.Attribute):
            return self.error(node, "методи на кшталт .upper() не підтримуються: використовуй наші функції")
        if not isinstance(func, ast.Name):
            return self.error(node, "викликати можна лише наші функції, наприклад show_text(...)")
        name = func.id
        if node.keywords or any(isinstance(arg, ast.Starred) for arg in node.args):
            return self.error(node, "пиши значення без назв і зірочок: {}(...)".format(name))

        if name == "print":
            for arg in node.args:
                if self.expr(arg) == COUNTRY:
                    self.error(arg, "print(country) не підтримується: бери country.lcd_name")
            if not as_statement:
                return self.error(node, "print нічого не повертає")
            return None
        if name == "str":
            if len(node.args) != 1:
                return self.error(node, "str приймає одне значення: str(count)")
            value_type = self.expr(node.args[0])
            if value_type == COUNTRY:
                return self.error(node, "str(country) не підтримується: бери country.lcd_name")
            if as_statement:
                return self.error(node, "результат str(...) ніде не використано")
            return STR if value_type is not None else None
        if name == "range":
            return self.error(node, "range працює лише в for: for i in range(5)")
        if name == "input":
            return self.error(node, "input не підтримується: у глобуса немає клавіатури")
        if name in HOOKS:
            return self.error(node, "{}() викликає сам глобус - не викликай її вручну".format(name))

        api = API.get(name)
        if api is None:
            message = "немає функції {}".format(name)
            hint = difflib.get_close_matches(name, list(API) + ["print", "str"], n=1)
            if hint:
                message += ". Можливо, тут має бути {}?".format(hint[0])
            return self.error(node, message)
        return self.api_call(node, api, as_statement)

    def api_call(self, node, api, as_statement):
        if api.only_in and self.info is not None and self.info.name != api.only_in:
            self.error(node, "{}() можна викликати лише всередині {}()".format(api.name, api.only_in))
        if api.not_in and self.info is not None and self.info.name == api.not_in:
            self.error(
                node,
                "{}() не можна викликати всередині {}(): вона сама його викликає. {}".format(
                    api.name, api.not_in, api.not_in_hint[:1].upper() + api.not_in_hint[1:]
                ),
            )
        if len(node.args) != len(api.params):
            return self.error(
                node,
                "{}() приймає {} значення, а тут {}".format(api.name, len(api.params), len(node.args)),
            )
        for index, (arg, expected) in enumerate(zip(node.args, api.params)):
            actual = self.expr(arg)
            if actual is not None and actual != expected:
                if expected == STR and actual == INT:
                    self.error(arg, "{}(): тут потрібен текст. Загорни число в str()".format(api.name))
                else:
                    self.error(
                        arg,
                        "{}(): {}-е значення має бути {}, а тут {}".format(
                            api.name, index + 1, TYPE_NAMES[expected], TYPE_NAMES[actual]
                        ),
                    )
            self.check_literal(api, index, arg)
        if as_statement and api.returns is not None:
            self.error(node, "результат {}() ніде не використано: n = {}(...)".format(api.name, api.name))
        if not as_statement and api.returns is None:
            return self.error(node, "{}() нічого не повертає - її не можна використати у виразі".format(api.name))
        return api.returns

    def check_literal(self, api, index, arg):
        if index == api.row_arg:
            row = literal_int(arg)
            if row is not None:
                if not 0 <= row < SCREEN_ROWS:
                    self.error(arg, "на екрані 6 рядків, від 0 до 5, а тут {}".format(row))
                elif self.info is not None and row not in self.info.hook.rows:
                    self.warning(
                        arg,
                        "рядок {} зазвичай займає інша частина глобуса. Для {}() вільні рядки: {}".format(
                            row, self.info.name, ", ".join(str(free) for free in self.info.hook.rows)
                        ),
                    )
        if index in api.text_args:
            text = literal_str(arg)
            if text is not None:
                limit = api.text_args[index]
                if not text.isascii():
                    self.error(arg, 'екран не показує українські літери: пиши англійськими словами (латиницею), наприклад "Hello"')
                elif len(text) > limit:
                    self.error(
                        arg,
                        "текст довший за {} символів ({}): на екрані він обріжеться".format(limit, len(text)),
                    )
        if index in api.id_args:
            country_id = literal_str(arg)
            known = self.context.country_ids
            if country_id is not None and known and country_id.upper() not in known:
                self.error(
                    arg, 'немає країни "{}". Є: {}'.format(country_id, ", ".join(sorted(known)))
                )


def syntax_problem(file, exc):
    """Зрозуміле повідомлення про SyntaxError."""
    text = (exc.text or "").strip()
    if isinstance(exc, TabError):
        message = "змішано табуляцію й пробіли: роби відступи лише пробілами"
    elif isinstance(exc, IndentationError):
        message = "відступи не збігаються: перевір пробіли на початку рядка"
    else:
        message = (
            "помилка в тексті програми ({}). Найчастіше це забута дужка, лапка "
            "або двокрапка".format(exc.msg)
        )
    if text:
        message += "\n    " + text
    return Problem(message, file, exc.lineno)


def analyze_task(file, source, context):
    """Перевіряє один файл. Повертає (TaskInfo або None, проблеми)."""
    checker = _Checker(file, context)
    if "\0" in source:
        return None, [corrupted_problem(file)]
    try:
        tree = ast.parse(source, filename=file)
    except SyntaxError as exc:
        return None, [syntax_problem(file, exc)]
    except ValueError:
        return None, [corrupted_problem(file)]
    except (RecursionError, MemoryError):
        return None, [too_complex_problem(file)]

    try:
        info = _collect(file, tree, checker)
    except (RecursionError, MemoryError):
        return None, [too_complex_problem(file)]
    return info, checker.problems


def corrupted_problem(file):
    return Problem(
        "файл пошкоджено: у ньому є службові символи, збережи його ще раз як UTF-8",
        file,
    )


def too_complex_problem(file):
    return Problem(
        "код задовгий або занадто складний для перевірки - спрости вираз", file
    )


def _collect(file, tree, checker):
    """Обходить файл; повертає TaskInfo, а проблеми складає в checker."""
    info = TaskInfo(file)
    own = ", ".join(hook.name for hook in hooks_for_file(file)) or "(нічого)"
    for node in tree.body:
        if _is_docstring(node):
            continue
        if isinstance(node, ast.FunctionDef):
            hook = HOOKS.get(node.name)
            if hook is None:
                checker.error(
                    node,
                    "функція {} - не з цієї задачі. У {} пишуться лише: {}. Допоміжні "
                    "функції не підтримуються - пиши код прямо в них".format(node.name, file, own),
                )
            elif hook.file != file:
                checker.error(node, "{}() належить {}, а не {}".format(node.name, hook.file, file))
            elif node.name in info.functions:
                checker.error(node, "функція {}() написана двічі - залиш одну".format(node.name))
            elif checker.signature_ok(node, hook):
                function = FunctionInfo(hook, node, file)
                info.functions[node.name] = function
                checker.check_function(function)
            continue
        if is_api_import(node):
            continue
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            checker.error(node, IMPORT_HINT)
        else:
            checker.error(
                node,
                "код поза функцією не підтримується (і глобальні змінні теж): "
                "перенеси його всередину функції",
            )
    return info


def analyze_all(sources, context):
    """Перевіряє всі файли. Повертає ({файл: TaskInfo}, проблеми)."""
    infos = {}
    problems = []
    for file in TASK_FILES:
        if file not in sources:
            continue
        info, file_problems = analyze_task(file, sources[file], context)
        problems.extend(file_problems)
        if info is not None:
            infos[file] = info
    return infos, problems


def decode_source(raw, file):
    """Байти файлу -> текст. Блокнот Windows любить BOM і CRLF - обидва годяться."""
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return None, Problem(
            "файл збережено не в кодуванні UTF-8. У Блокноті: Файл -> Зберегти як "
            "-> Кодування: UTF-8",
            file,
        )
    return text.replace("\r\n", "\n"), None


# "task2 (1).py", "task2.py.txt", "Task 2.py" - яку задачу, мабуть, мали на увазі.
RENAMED_TASK = re.compile(r"^task[\s_-]*([1-9])(?!\d)")


def guess_task_file(name):
    """Назва перейменованого файлу -> "task2.py" або None."""
    match = RENAMED_TASK.match(name.lower())
    if match is None:
        return None
    guess = "task{}.py".format(match.group(1))
    return guess if guess in TASK_FILES else None


def read_task_sources(students_dir):
    """Читає students/task*.py. Повертає ({task1.py: текст}, проблеми).

    У кожної проблеми з файлом є file - задача, до якої вона стосується
    (для task2 (1).py це task2.py): так globe test task2 покаже саме її.
    """
    folder = Path(students_dir)
    sources = {}
    problems = []
    if not folder.is_dir():
        problems.append(Problem("немає папки {} - звідки брати задачі?".format(folder)))
        return sources, problems

    for path in sorted(folder.iterdir()):
        if not path.is_file():
            continue
        name = path.name.lower()
        guess = guess_task_file(name)
        rename = "перейменуй його на {}".format(guess) if guess else "перейменуй файл"
        if path.suffix.lower() != ".py":
            if name.startswith("task"):
                problems.append(
                    Problem(
                        "файл {} пропущено: задача має бути файлом .py, наприклад "
                        "task2.py. Якщо це твоя задача - {}".format(path.name, rename),
                        file=guess or path.name,
                        level=WARNING,
                    )
                )
            continue
        if name not in TASK_FILES:
            problems.append(
                Problem(
                    "файл {} пропущено: задачі мають називатися task1.py ... task5.py. "
                    "Якщо це чиясь задача - {}".format(path.name, rename),
                    file=guess or path.name,
                    level=WARNING,
                )
            )
            continue
        if name in sources:
            problems.append(
                Problem("є два файли {} - залиш один".format(name), file=name, level=WARNING)
            )
            continue
        try:
            raw = path.read_bytes()
        except OSError:
            problems.append(
                Problem(
                    "не вдалося прочитати файл {}: перевір, чи він не відкритий і чи є доступ".format(path.name),
                    file=name,
                )
            )
            continue
        text, problem = decode_source(raw, name)
        if problem is not None:
            problems.append(problem)
            continue
        sources[name] = text
    return sources, problems


def expression_type(node, scope):
    """Тип виразу за відомими змінними. Для перекладача - код уже перевірено."""
    checker = _Checker("", Context())
    checker.defined = dict(scope)
    return checker.expr(node)
