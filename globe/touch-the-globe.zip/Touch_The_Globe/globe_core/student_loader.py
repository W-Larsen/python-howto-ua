"""Завантаження коду учнів (students/task*.py) на комп'ютері.

Перед запуском кожен файл проходить ту саму перевірку, що й перед
перекладом у C++. Файл із помилками не запускається: краще одразу
сказати "ось що виправити", ніж дати коду попрацювати на комп'ютері й
зламатися вже на платі.

Ще одна річ, яка тут відбувається, - захист від нескінченного while.
У кожен цикл while вставляється лічильник: на LOOP_LIMIT-му повторі цикл
переривається, а глобус пише, у якому рядку це сталося. Рівно те саме
робить перекладач у C++, тому поведінка на комп'ютері й на платі
однакова.

І ще одна: у C++ усі змінні хука оголошуються на його початку зі
значенням 0, "" або False. Тому тут на початок кожного хука теж
дописуються такі присвоєння - змінна, якій значення дали лише в одній
гілці if (або змінна циклу після порожнього range), і на комп'ютері, і на
платі однаково порожня.
"""

import ast

from globe_core.hooks import BOOL, HOOKS, INT, LOOP_LIMIT, STR, TASK_FILES
from globe_core.language import analyze_task, is_api_import, read_task_sources
from globe_core.problems import has_errors

GUARD_FUNCTION = "__globe_loop_stuck__"

# Код учня бачить лише ці вбудовані функції, а все інше - наші з API.
SAFE_BUILTINS = {"str": str, "print": print, "range": range}

# Ті самі початкові значення, що й CPP_DEFAULTS у globe_core/cpp_codegen.py.
DEFAULTS = {INT: 0, STR: "", BOOL: False}


class StudentCode:
    def __init__(self):
        self.hooks = {}
        self.problems = []
        self.files = []


def _located(statements, line):
    for statement in statements:
        for node in ast.walk(statement):
            node.lineno = line
            node.col_offset = 0
            node.end_lineno = line
            node.end_col_offset = 0
    return statements


class _LoopGuard(ast.NodeTransformer):
    """Вставляє лічильник у кожен while."""

    def __init__(self, file):
        self.file = file
        self.count = 0

    def visit_While(self, node):
        self.generic_visit(node)
        self.count += 1
        counter = "__globe_loop_{}".format(self.count)
        guard = ast.parse(
            "{c} += 1\n"
            "if {c} > {limit}:\n"
            "    {function}({file!r}, {line})\n"
            "    break\n".format(
                c=counter,
                limit=LOOP_LIMIT,
                function=GUARD_FUNCTION,
                file=self.file,
                line=node.lineno,
            )
        ).body
        node.body = _located(guard, node.lineno) + node.body
        start = _located(ast.parse("{} = 0".format(counter)).body, node.lineno)
        return start + [node]


def hook_defaults(info):
    """TaskInfo -> {хук: {змінна: тип}} - які змінні оголосити на початку."""
    return {name: dict(function.variables) for name, function in info.functions.items()}


def _add_defaults(tree, defaults):
    """Дописує на початок кожного хука name = 0 / "" / False."""
    for node in tree.body:
        if not isinstance(node, ast.FunctionDef):
            continue
        variables = defaults.get(node.name)
        if not variables:
            continue
        start = [
            ast.Assign(
                targets=[ast.Name(id=name, ctx=ast.Store())],
                value=ast.Constant(value=DEFAULTS[value_type]),
            )
            for name, value_type in variables.items()
        ]
        node.body = _located(start, node.lineno) + node.body


def compile_task(file, source, api, on_loop_stuck, defaults=None):
    """Виконує файл учня і повертає його хуки. Код має бути вже перевірений.

    defaults - {хук: {змінна: тип}} (див. hook_defaults): змінні, які
    отримають початкове значення, як на платі.
    """
    tree = ast.parse(source, filename=file)
    tree.body = [node for node in tree.body if not is_api_import(node)]
    if defaults:
        _add_defaults(tree, defaults)
    tree = _LoopGuard(file).visit(tree)
    ast.fix_missing_locations(tree)

    namespace = {"__builtins__": SAFE_BUILTINS, "__name__": file[:-3]}
    namespace.update(api)
    namespace[GUARD_FUNCTION] = on_loop_stuck
    exec(compile(tree, file, "exec"), namespace)

    return {
        name: value
        for name, value in namespace.items()
        if name in HOOKS and callable(value)
    }


def load_students(students_dir, api, context, on_loop_stuck):
    """Перевіряє й завантажує всі задачі. Повертає StudentCode."""
    code = StudentCode()
    sources, problems = read_task_sources(students_dir)
    code.problems.extend(problems)

    for file in TASK_FILES:
        if file not in sources:
            continue
        info, file_problems = analyze_task(file, sources[file], context)
        code.problems.extend(file_problems)
        if info is None or has_errors(file_problems):
            continue
        functions = compile_task(
            file, sources[file], api, on_loop_stuck, defaults=hook_defaults(info)
        )
        for name in info.functions:
            code.hooks[name] = functions[name]
        code.files.append(file)
    return code
