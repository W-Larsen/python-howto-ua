"""Заглушки замість заліза.

Потрібні у двох випадках:
  * у тестах - щоб перевірити логіку без колонок і дисплея;
  * коли глобус ще не зібраний, а покликати код уже хочеться.
"""


class NullDisplay:
    """Дисплей, який нічого не робить."""

    def refresh(self, screen):
        pass

    def blink(self, times):
        pass

    def note(self, text):
        pass


class NullSpeaker:
    """Колонка, яка нічого не грає."""

    def play(self, audio_ref):
        pass

    def stop(self):
        pass


class RecordingDisplay:
    """Запам'ятовує кожен кадр екрана, мигання й підказки."""

    def __init__(self):
        self.frames = []
        self.blinks = []
        self.notes = []

    def refresh(self, screen):
        self.frames.append(screen.snapshot())

    def blink(self, times):
        self.blinks.append(times)

    def note(self, text):
        self.notes.append(text)

    @property
    def last(self):
        return self.frames[-1] if self.frames else None


class RecordingSpeaker:
    """Запам'ятовує, що просили програти. Говорити текст не вміє."""

    def __init__(self):
        self.played = []
        self.stopped = 0

    def play(self, audio_ref):
        self.played.append(audio_ref)

    def stop(self):
        self.stopped += 1


class DictAudioSource:
    """Аудіо за словником {ID країни: посилання}."""

    def __init__(self, mapping=None):
        self.mapping = mapping or {}

    def resolve(self, country):
        return self.mapping.get(country.id.upper())


class TrackAudioSource:
    """Аудіо як номер треку - так працює DFPlayer на платі."""

    def resolve(self, country):
        return country.track


class FakeClock:
    """Годинник, який іде лише тоді, коли його попросили."""

    def __init__(self, now=0.0):
        self.now = now

    def __call__(self):
        return self.now

    def advance(self, seconds):
        self.now += seconds


class FakeSleep:
    """Замість справжньої паузи - запис, скільки просили почекати."""

    def __init__(self, clock=None):
        self.calls = []
        self.clock = clock

    def __call__(self, seconds):
        self.calls.append(seconds)
        if self.clock is not None:
            self.clock.advance(seconds)
