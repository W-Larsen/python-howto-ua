"""Екран глобуса так, як його бачить код: 6 рядків по 14 символів.

І комп'ютер, і плата малюють ту саму сітку. Тут же правила, за якими
текст потрапляє на екран Nokia 5110: у його шрифті є лише латиниця,
цифри й розділові знаки, а плата бачить текст як байти UTF-8. Тому
кожна українська літера (два байти) стає двома знаками "?" - рівно так,
як це буде на справжньому екрані.
"""

from globe_core.catalog import LCD_WIDTH
from globe_core.hooks import SCREEN_ROWS

WIDTH = LCD_WIDTH


def sanitize(text):
    """Те, що справді з'явиться в рядку екрана."""
    result = []
    for symbol in str(text):
        if 32 <= ord(symbol) <= 126:
            result.append(symbol)
        else:
            result.append("?" * len(symbol.encode("utf-8")))
    return "".join(result)[:WIDTH]


def wrap_words(text, width=WIDTH, max_lines=3):
    """Розбиває текст на рядки по словах (для питань вікторини).

    Той самий алгоритм повторено на платі у wrapWords() у wrap_words.cpp
    (тест паритету - tests/test_parity.py).
    """
    lines = []
    current = ""
    for word in str(text).split(" "):
        if not word:
            continue
        while len(word) > width:
            if current:
                lines.append(current)
                current = ""
            lines.append(word[:width])
            word = word[width:]
        if not word:
            continue
        if not current:
            current = word
        elif len(current) + 1 + len(word) <= width:
            current = current + " " + word
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines[:max_lines]


class Screen:
    """Шість рядків тексту. Рядок можна зробити білим по чорному."""

    def __init__(self):
        self.rows = [""] * SCREEN_ROWS
        self.inverted = [False] * SCREEN_ROWS

    def clear(self):
        self.rows = [""] * SCREEN_ROWS
        self.inverted = [False] * SCREEN_ROWS

    def write(self, row, text, inverted=False):
        if not 0 <= row < SCREEN_ROWS:
            return False
        self.rows[row] = sanitize(text)
        self.inverted[row] = inverted
        return True

    def snapshot(self):
        return tuple(self.rows)
