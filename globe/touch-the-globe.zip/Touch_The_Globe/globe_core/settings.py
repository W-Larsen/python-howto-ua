"""Налаштування глобуса з settings.py у корені проєкту.

Там проводка (до яких пінів підключені кнопки) і параметри ігор. Файл
належить вчителю: перепаяв сенсор - змінив один рядок, а код учнів
лишається тим самим.

Файл НЕ виконується: ми лише читаємо з нього значення через ast. Тому
навіть зіпсований settings.py не може нічого зламати - у найгіршому
разі глобус візьме значення за замовчуванням і скаже про це.
"""

import ast
import re
from pathlib import Path

from globe_core.pins import PinError, to_pin
from globe_core.problems import ERROR, WARNING, Problem

FILE_NAME = "settings.py"

DEFAULTS = {
    "BUTTON_PINS": ["A0", "A1", "A2", "A3", "A4"],
    "BUTTON_COUNTRIES": [],
    "QUIZ_PIN": "D10",
    "QUIZ_PAUSE_MS": 1500,
    "GAME_PIN": "D11",
    "GAME_ROUNDS": 5,
    "GAME_TIMEOUT_MS": 5000,
    "GAME_PAUSE_MS": 1500,
}

# D0-D1 - USB, D2-D7 - дисплей, D8-D9 - DFPlayer (див. hardware_pins.h).
BUSY_PINS = ("D0", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9")
# За номерами, бо "5" і "D5" - це той самий пін.
BUSY_NUMBERS = {to_pin(pin) for pin in BUSY_PINS}

# Налаштування, яких може й не бути у файлі: тоді все працює як раніше.
OPTIONAL = {"BUTTON_COUNTRIES"}
COUNTRY_ID = re.compile(r"^[A-Z]{2,3}$")

# Скільки кнопок країн витягне панель сенсорів на платі: ще два місця
# займають кнопки вікторини й гри (MAX_BUTTONS = 10 у buttons.h).
MAX_BUTTONS = 8

NUMBER_LIMITS = {
    "QUIZ_PAUSE_MS": (0, 10000),
    "GAME_PAUSE_MS": (0, 10000),
    # Не більше 30000, щоб ms вміщалося в число на Arduino Uno.
    "GAME_TIMEOUT_MS": (1000, 30000),
    "GAME_ROUNDS": (1, 20),
}


class Settings:
    def __init__(self, values):
        self.button_pins = [str(pin).strip().upper() for pin in values["BUTTON_PINS"]]
        # Яку країну вчитель закріпив за кнопкою (кнопка 1 - перший елемент);
        # "" - за цією кнопкою нічого не закріплено.
        self.button_countries = [
            str(country).strip().upper() for country in values["BUTTON_COUNTRIES"]
        ]
        self.quiz_pin = str(values["QUIZ_PIN"]).strip().upper()
        self.quiz_pause_ms = values["QUIZ_PAUSE_MS"]
        self.game_pin = str(values["GAME_PIN"]).strip().upper()
        self.game_rounds = values["GAME_ROUNDS"]
        self.game_timeout_ms = values["GAME_TIMEOUT_MS"]
        self.game_pause_ms = values["GAME_PAUSE_MS"]

    @property
    def button_count(self):
        return len(self.button_pins)


def default_settings():
    return Settings(dict(DEFAULTS))


def _type_error(name, value):
    """Текст помилки, якщо значення не того типу, або None."""
    if name == "BUTTON_PINS":
        if (
            not isinstance(value, list)
            or not value
            or not all(isinstance(pin, str) for pin in value)
        ):
            return 'BUTTON_PINS має бути списком пінів у лапках: ["A0", "A1"]'
        return None
    if name == "BUTTON_COUNTRIES":
        if not isinstance(value, list) or not all(isinstance(item, str) for item in value):
            return 'BUTTON_COUNTRIES має бути списком ID країн у лапках: ["UA", "AU"]'
        for item in value:
            if item.strip() and not COUNTRY_ID.match(item.strip().upper()):
                return "BUTTON_COUNTRIES: {!r} - це не ID країни (2-3 латинські літери)".format(item)
        return None
    if name.endswith("_PIN"):
        if not isinstance(value, str):
            return '{} має бути назвою піна в лапках, наприклад "D10"'.format(name)
        return None
    if isinstance(value, bool) or not isinstance(value, int):
        return "{} має бути цілим числом".format(name)
    return None


def parse_settings(source, file=FILE_NAME):
    """Повертає (Settings, проблеми). Код не виконується."""
    problems = []
    values = dict(DEFAULTS)

    try:
        tree = ast.parse(source, filename=file)
    except (SyntaxError, ValueError) as exc:
        problems.append(
            Problem(
                "помилка в тексті файлу ({}). Беру налаштування за "
                "замовчуванням.".format(getattr(exc, "msg", str(exc))),
                file,
                getattr(exc, "lineno", None),
            )
        )
        return Settings(values), problems

    mentioned = set()
    for node in tree.body:
        # Рядок-опис на початку файлу - це нормально.
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Constant):
            continue
        if not (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
        ):
            problems.append(
                Problem("тут можуть бути лише рядки виду НАЗВА = значення", file, node.lineno)
            )
            continue

        name = node.targets[0].id
        if name not in DEFAULTS:
            problems.append(
                Problem(
                    "невідоме налаштування {}. Відомі: {}".format(name, ", ".join(DEFAULTS)),
                    file,
                    node.lineno,
                    WARNING,
                )
            )
            continue

        mentioned.add(name)
        try:
            value = ast.literal_eval(node.value)
        except (ValueError, TypeError, RecursionError, MemoryError):
            problems.append(
                Problem(
                    "{}: значення має бути числом, текстом у лапках або списком".format(name),
                    file,
                    node.lineno,
                )
            )
            continue

        error = _type_error(name, value)
        if error is not None:
            problems.append(Problem(error, file, node.lineno))
            continue
        values[name] = value

    for name, default in DEFAULTS.items():
        if name not in mentioned and name not in OPTIONAL:
            problems.append(
                Problem("немає {}, беру {!r}".format(name, default), file, None, WARNING)
            )

    settings = Settings(values)
    problems.extend(check_settings(settings, file))
    return settings, problems


def check_settings(settings, file=FILE_NAME):
    """Перевіряє піни й числа. Повертає список проблем."""
    problems = []

    count = settings.button_count
    if count > MAX_BUTTONS:
        problems.append(
            Problem(
                "кнопок країн {}, а плата витягне не більше {}".format(count, MAX_BUTTONS),
                file,
            )
        )

    countries = settings.button_countries
    if len(countries) > count:
        problems.append(
            Problem(
                "BUTTON_COUNTRIES: країн {}, а кнопок лише {} - зайві не діють".format(
                    len(countries), count
                ),
                file,
                None,
                WARNING,
            )
        )
    chosen = [country for country in countries[:count] if country]
    for country in sorted(set(chosen)):
        if chosen.count(country) > 1:
            problems.append(
                Problem(
                    "BUTTON_COUNTRIES: країна {} закріплена за кількома кнопками".format(country),
                    file,
                    None,
                    WARNING,
                )
            )

    named = [("кнопка {}".format(index + 1), pin) for index, pin in enumerate(settings.button_pins)]
    named.append(("QUIZ_PIN", settings.quiz_pin))
    named.append(("GAME_PIN", settings.game_pin))

    taken = {}
    for role, pin in named:
        try:
            number = to_pin(pin)
        except PinError:
            problems.append(
                Problem(
                    "{}: на Arduino Uno немає піна {}. Бери A0-A5 або D10-D13".format(role, pin),
                    file,
                )
            )
            continue
        if number in BUSY_NUMBERS:
            problems.append(
                Problem(
                    "{}: пін {} зайнятий (D0-D1 - USB, D2-D9 - дисплей і DFPlayer). "
                    "Вільні: A0-A5, D10-D13".format(role, pin),
                    file,
                )
            )
            continue
        if number in taken:
            problems.append(
                Problem(
                    "пін {} вказано двічі: {} і {}. Один пін - одна кнопка".format(
                        pin, taken[number], role
                    ),
                    file,
                )
            )
            continue
        taken[number] = role

    for name, (low, high) in NUMBER_LIMITS.items():
        value = getattr(settings, name.lower())
        if not low <= value <= high:
            problems.append(
                Problem("{} = {}: має бути від {} до {}".format(name, value, low, high), file)
            )

    return problems


def load_settings(path):
    """Читає settings.py. Якщо файлу немає - значення за замовчуванням."""
    path = Path(path)
    if not path.is_file():
        return default_settings(), [
            Problem(
                "немає файлу settings.py - беру налаштування за замовчуванням",
                FILE_NAME,
                level=WARNING,
            )
        ]
    try:
        source = path.read_bytes().decode("utf-8-sig")
    except UnicodeDecodeError:
        return default_settings(), [
            Problem("settings.py збережено не в UTF-8 - беру значення за замовчуванням", FILE_NAME)
        ]
    return parse_settings(source, FILE_NAME)
