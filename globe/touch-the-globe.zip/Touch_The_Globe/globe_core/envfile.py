"""Найпростіший читач файлів .env.

Свій, а не готова бібліотека, щоб проєкт запускався одразу після
клонування, без жодного pip install.

Розуміє:

    GLOBE_AUDIO_MODE=prerecorded
    ELEVENLABS_VOICE_ID="21m00Tcm4TlvDq8ikWAM"   # можна в лапках
    # рядки-комментарі та порожні рядки пропускаються
"""


def parse_env(raw):
    """Розбирає текст .env у звичайний словник."""
    values = {}
    lines = raw.replace("\r\n", "\n").replace("\r", "\n").split("\n")

    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].strip()
        if "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if not key:
            continue

        quoted = False
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
            quoted = True

        # Коментар у кінці рядка прибираємо тільки для значень без лапок.
        if not quoted and " #" in value:
            value = value.split(" #", 1)[0].strip()

        values[key] = value

    return values


def load_env_file(path):
    """Читає .env. Якщо файлу немає - повертає порожній словник, без помилки."""
    try:
        handle = open(path, "r", encoding="utf-8-sig")
    except OSError:
        return {}
    try:
        return parse_env(handle.read())
    finally:
        handle.close()
