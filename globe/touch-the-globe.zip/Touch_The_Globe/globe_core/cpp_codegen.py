"""Перекладач коду учнів з Python у C++ для Arduino Uno.

Учні пишуть Python, а плата розуміє лише C++. Перекладати можна не будь-
який Python, а лише "мову глобуса" (див. globe_core/language.py) - код
сюди потрапляє вже перевіреним. Тому тут немає жодних помилок для учнів:
лише правила, як кожну конструкцію записати в C++ так, щоб вона
поводилася рівно як у Python.

Головні тонкощі:
  * у Python -7 // 2 == -4, а в C++ -7 / 2 == -3. Тому // і % стають
    py_div() і py_mod() - вони рахують "як у Python";
  * у Python for i in range(n) рахує n один раз, а зміна i всередині
    циклу ні на що не впливає. Тут так само: межа й лічильник - окремі;
  * у C++ змінна, оголошена всередині if, після нього не видна. Тому всі
    змінні оголошуються на початку функції;
  * частина звичайних слів у Arduino вже зайнята (round, min, max...),
    тому всі імена учня отримують префікс s_.
"""

import ast

from globe_core.hooks import BOOL, COUNTRY, COUNTRY_FIELDS, HOOK_LIST, INT, LOOP_LIMIT, STR
from globe_core.language import expression_type, literal_int, literal_str

PREFIX = "s_"
CPP_TYPES = {INT: "long", BOOL: "bool", STR: "String"}
CPP_PARAM_TYPES = {INT: "long", BOOL: "bool", COUNTRY: "const Country&"}
CPP_DEFAULTS = {INT: "0", BOOL: "false", STR: '""'}

BINARY = {ast.Add: "+", ast.Sub: "-", ast.Mult: "*"}
COMPARE = {
    ast.Eq: "==",
    ast.NotEq: "!=",
    ast.Lt: "<",
    ast.LtE: "<=",
    ast.Gt: ">",
    ast.GtE: ">=",
}

HEADER_TOP = """\
// ЗГЕНЕРОВАНО автоматично. Руками не редагувати!
//
// Цей файл складає tools/build_student_code.py (команда make build) з
// settings.py і students/task*.py. Щоб щось тут змінити, виправ ті файли
// й запусти make build ще раз.
//
// {tasks}

#ifndef STUDENT_CODE_H
#define STUDENT_CODE_H

#include <Arduino.h>

#include "globe_api.h"
#include "student_hooks.h"
"""


def cpp_string(text):
    """Python-рядок -> C++-літерал у лапках."""
    escaped = (
        text.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
        .replace("?", "\\?")
    )
    return '"' + escaped + '"'


def flash(text):
    return "F({})".format(cpp_string(text))


def function_signature(hook, names):
    params = ", ".join(
        "{} {}{}".format(CPP_PARAM_TYPES[param_type], PREFIX, name)
        for name, (_, param_type) in zip(names, hook.params)
    )
    return "void student_{}({})".format(hook.name, params)


class _FunctionWriter:
    def __init__(self, info):
        self.info = info
        self.scope = info.scope()
        self.lines = []
        self.counter = 0

    def emit(self, depth, text):
        self.lines.append("  " * depth + text)

    def next_id(self):
        self.counter += 1
        return self.counter

    def write(self):
        info = self.info
        names = [name for name, _ in info.params]
        self.emit(0, "// {}, рядок {}: {}()".format(info.file, info.line, info.name))
        self.emit(0, function_signature(info.hook, names) + " {")
        for name, value_type in info.variables.items():
            self.emit(1, "{} {}{} = {};".format(CPP_TYPES[value_type], PREFIX, name, CPP_DEFAULTS[value_type]))
        self.block(info.node.body, 1)
        self.emit(0, "}")
        return self.lines

    # -- інструкції ------------------------------------------------------
    def block(self, body, depth):
        for node in body:
            self.statement(node, depth)

    def statement(self, node, depth):
        if isinstance(node, ast.Expr):
            if literal_str(node.value) is not None:
                return  # рядок-коментар
            self.call_statement(node.value, depth)
        elif isinstance(node, ast.Assign):
            target = node.targets[0].id
            self.emit(depth, "{}{} = {};".format(PREFIX, target, self.expr(node.value)))
        elif isinstance(node, ast.AugAssign):
            name = node.target.id
            combined = ast.BinOp(left=ast.Name(id=name, ctx=ast.Load()), op=node.op, right=node.value)
            self.emit(depth, "{}{} = {};".format(PREFIX, name, self.expr(combined)))
        elif isinstance(node, ast.If):
            self.if_chain(node, depth)
        elif isinstance(node, ast.For):
            self.for_range(node, depth)
        elif isinstance(node, ast.While):
            self.while_loop(node, depth)
        elif isinstance(node, ast.Return):
            self.emit(depth, "return;")
        elif isinstance(node, ast.Pass):
            self.emit(depth, ";")
        elif isinstance(node, ast.Break):
            self.emit(depth, "break;")
        elif isinstance(node, ast.Continue):
            self.emit(depth, "continue;")
        else:
            raise ValueError("неперевірена конструкція: {}".format(type(node).__name__))

    def if_chain(self, node, depth):
        keyword = "if"
        while True:
            self.emit(depth, "{} ({}) {{".format(keyword, self.condition(node.test)))
            self.block(node.body, depth + 1)
            orelse = node.orelse
            if len(orelse) == 1 and isinstance(orelse[0], ast.If):
                node = orelse[0]
                keyword = "} else if"
                continue
            if orelse:
                self.emit(depth, "} else {")
                self.block(orelse, depth + 1)
            self.emit(depth, "}")
            return

    def for_range(self, node, depth):
        args = node.iter.args
        if len(args) == 1:
            start, end, step = "0L", self.expr(args[0]), 1
        else:
            start, end = self.expr(args[0]), self.expr(args[1])
            step = literal_int(args[2]) if len(args) == 3 else 1
        number = self.next_id()
        compare = "<" if step > 0 else ">"
        self.emit(depth, "{")
        self.emit(depth + 1, "long _start{} = {};".format(number, start))
        self.emit(depth + 1, "long _end{} = {};".format(number, end))
        self.emit(
            depth + 1,
            "for (long _k{n} = _start{n}; _k{n} {cmp} _end{n}; _k{n} += {step}L) {{".format(
                n=number, cmp=compare, step=step
            ),
        )
        self.emit(depth + 2, "{}{} = _k{};".format(PREFIX, node.target.id, number))
        self.block(node.body, depth + 2)
        self.emit(depth + 1, "}")
        self.emit(depth, "}")

    def while_loop(self, node, depth):
        number = self.next_id()
        self.emit(depth, "{")
        self.emit(depth + 1, "long _guard{} = 0;".format(number))
        self.emit(depth + 1, "while ({}) {{".format(self.condition(node.test)))
        self.emit(depth + 2, "if (++_guard{} > {}L) {{".format(number, LOOP_LIMIT))
        self.emit(depth + 3, "globe_loop_stuck({}, {});".format(flash(self.info.file), node.lineno))
        self.emit(depth + 3, "break;")
        self.emit(depth + 2, "}")
        self.block(node.body, depth + 2)
        self.emit(depth + 1, "}")
        self.emit(depth, "}")

    def call_statement(self, call, depth):
        name = call.func.id
        if name == "print":
            for index, arg in enumerate(call.args):
                if index:
                    self.emit(depth, "Serial.print(' ');")
                self.emit(depth, "Serial.print({});".format(self.print_value(arg)))
            self.emit(depth, "Serial.println();")
            return
        args = ", ".join(self.api_arg(arg) for arg in call.args)
        self.emit(depth, "{}({});".format(name, args))

    def print_value(self, node):
        text = literal_str(node)
        if text is not None:
            return flash(text)
        if self.type_of(node) == BOOL:
            return '({} ? F("True") : F("False"))'.format(self.expr(node))
        return self.expr(node)

    def api_arg(self, node):
        text = literal_str(node)
        if text is not None:
            return flash(text)
        return self.expr(node)

    # -- вирази ----------------------------------------------------------
    def type_of(self, node):
        return expression_type(node, self.scope)

    def condition(self, node):
        if self.type_of(node) == INT:
            return "({} != 0)".format(self.expr(node))
        return self.expr(node)

    def expr(self, node):
        if isinstance(node, ast.Constant):
            value = node.value
            if isinstance(value, bool):
                return "true" if value else "false"
            if isinstance(value, int):
                return "{}L".format(value)
            return "String({})".format(flash(value))
        if isinstance(node, ast.Name):
            return PREFIX + node.id
        if isinstance(node, ast.Attribute):
            return "{}{}.{}".format(PREFIX, node.value.id, COUNTRY_FIELDS[node.attr])
        if isinstance(node, ast.BinOp):
            left = self.expr(node.left)
            right = self.expr(node.right)
            if isinstance(node.op, ast.FloorDiv):
                return "py_div({}, {})".format(left, right)
            if isinstance(node.op, ast.Mod):
                return "py_mod({}, {})".format(left, right)
            return "({} {} {})".format(left, BINARY[type(node.op)], right)
        if isinstance(node, ast.UnaryOp):
            operand = self.expr(node.operand)
            if isinstance(node.op, ast.Not):
                return "(!{})".format(operand)
            if isinstance(node.op, ast.USub):
                return "(-{})".format(operand)
            return "(+{})".format(operand)
        if isinstance(node, ast.BoolOp):
            joiner = " && " if isinstance(node.op, ast.And) else " || "
            return "(" + joiner.join(self.expr(value) for value in node.values) + ")"
        if isinstance(node, ast.Compare):
            return "({} {} {})".format(
                self.expr(node.left), COMPARE[type(node.ops[0])], self.expr(node.comparators[0])
            )
        if isinstance(node, ast.Call):
            name = node.func.id
            if name == "str":
                arg = node.args[0]
                arg_type = self.type_of(arg)
                if arg_type == INT:
                    return "py_str({})".format(self.expr(arg))
                if arg_type == BOOL:
                    return "py_str_bool({})".format(self.expr(arg))
                return "String({})".format(self.expr(arg))
            return "{}({})".format(name, ", ".join(self.expr(arg) for arg in node.args))
        raise ValueError("неперевірений вираз: {}".format(type(node).__name__))


def _empty_function(hook):
    names = [name for name, _ in hook.params]
    return [
        "// немає в {}: {}()".format(hook.file, hook.name),
        function_signature(hook, names) + " {}",
    ]


def _settings_block(settings):
    pins = ", ".join('"{}"'.format(pin) for pin in settings.button_pins)
    return [
        "// --- settings.py ---",
        "const char* const BUTTON_PINS[] = {{{}}};".format(pins),
        "const uint8_t BUTTON_COUNT = {};".format(settings.button_count),
        'const char* const QUIZ_PIN = "{}";'.format(settings.quiz_pin),
        "const unsigned long QUIZ_PAUSE_MS = {}UL;".format(settings.quiz_pause_ms),
        'const char* const GAME_PIN = "{}";'.format(settings.game_pin),
        "const uint8_t GAME_ROUNDS = {};".format(settings.game_rounds),
        "const unsigned long GAME_TIMEOUT_MS = {}UL;".format(settings.game_timeout_ms),
        "const unsigned long GAME_PAUSE_MS = {}UL;".format(settings.game_pause_ms),
    ]


def _button_answer_function(settings):
    """student_button_answer(): країни кнопок із settings.py як C++-код.

    Це таблиця вчителя (BUTTON_COUNTRIES), перекладена в звичайні виклики
    show_country(). Ядро кличе функцію в грі й вікторині перед on_button, тож
    плата не читає жодної таблиці: усе вже в коді, як і решта student_code.h.
    """
    lines = [
        "// settings.py, BUTTON_COUNTRIES: країна кнопки в грі й вікторині",
        "void student_button_answer(long number) {",
    ]
    mapped = [
        (number, country)
        for number, country in enumerate(settings.button_countries[: settings.button_count], 1)
        if country
    ]
    for index, (number, country) in enumerate(mapped):
        keyword = "if" if index == 0 else "} else if"
        lines.append("  {} (number == {}) {{".format(keyword, number))
        lines.append('    show_country("{}");'.format(country))
    if mapped:
        lines.append("  }")
    lines.append("}")
    return lines


def generate_header(settings, infos):
    """Текст student_code.h. infos - {task1.py: TaskInfo} без помилок."""
    functions = {}
    for info in infos.values():
        functions.update(info.functions)

    present = [file for file in sorted(infos)]
    tasks_line = "Задачі: " + (", ".join(present) if present else "(жодної)")

    mask = 0
    for index, hook in enumerate(HOOK_LIST):
        if hook.name in functions:
            mask |= 1 << index

    lines = [HEADER_TOP.format(tasks=tasks_line)]
    lines.extend(_settings_block(settings))
    lines.append("")
    lines.append("// Які хуки написані: біт i - HOOK_LIST[i] у globe_core/hooks.py.")
    lines.append("uint16_t student_hooks_present() {{ return 0x{:04X}; }}".format(mask))
    lines.append("")
    lines.extend(_button_answer_function(settings))

    for hook in HOOK_LIST:
        lines.append("")
        if hook.name in functions:
            lines.extend(_FunctionWriter(functions[hook.name]).write())
        else:
            lines.extend(_empty_function(hook))

    lines.append("")
    lines.append("#endif  // STUDENT_CODE_H")
    return "\n".join(lines) + "\n"
