"""Повідомлення про проблеми в коді учня та в налаштуваннях.

Одна проблема - це текст, файл і рядок. Друкується так, як учень звик
бачити помилки:

    task2.py, рядок 7: while тут не працює ...

Помилка (ERROR) означає, що код на плату не потрапить. Попередження
(WARNING) - що все працює, але, найімовірніше, не так, як задумано.
"""

ERROR = "error"
WARNING = "warning"


class Problem:
    def __init__(self, message, file=None, line=None, level=ERROR):
        self.message = message
        self.file = file
        self.line = line
        self.level = level

    @property
    def is_error(self):
        return self.level == ERROR

    def location(self):
        if self.file and self.line:
            return "{}, рядок {}".format(self.file, self.line)
        return self.file or ""

    def __str__(self):
        where = self.location()
        if where:
            return "{}: {}".format(where, self.message)
        return self.message

    def __repr__(self):
        return "<Problem {} {!r}>".format(self.level, str(self))


def has_errors(problems):
    return any(problem.is_error for problem in problems)
