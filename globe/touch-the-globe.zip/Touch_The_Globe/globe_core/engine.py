"""Мозок глобуса: торкнулися кнопки -> код учнів -> екран і звук.

Той самий порядок дій повторено на платі в globe_engine.cpp. Ядро нічого
не знає ні про колонки, ні про дисплей, ні про операційну систему: усе
"залізо" передається знадвору.

    display      .refresh(screen), .blink(times), .note(text)
    speaker      .play(audio_ref)
    audio_source .resolve(country) -> посилання на аудіо
    clock, sleep годинник і пауза (у тестах - підробні)

Код учнів - це хуки (on_button, question, ...), які ядро викликає в
потрібний момент. Учні, своєю чергою, викликають функції з api():
show_text, play_sound і т. д. Будь-яка помилка в коді учня
перехоплюється: глобус каже, що сталося, і працює далі.

Режими:
    NORMAL    торкання кнопки -> on_button
    QUIZ      вікторина чекає відповіді (task3)
    GAME      «Блискавка» чекає відповіді (task2)
    FINISHED  гра скінчилася; наступне торкання - знову NORMAL
"""

import random
import time

from globe_core.hooks import HOOKS, LOOP_LIMIT, QUIZ_MAX_QUESTIONS, SCREEN_ROWS
from globe_core.screen import WIDTH, Screen, wrap_words

NORMAL = "normal"
QUIZ = "quiz"
GAME = "game"
FINISHED = "finished"

NO_TASK1 = "немає task1.py (функції on_button) - кнопки ні до чого не підключені."

# Слова, за якими globe test упізнає, що хук учня впав (це помилка, а не
# просто попередження).
CRASHED = "зупинилася з помилкою"

# Помилки Python, які трапляються в коді учнів, - зрозумілою мовою.
# Перевіряються по черзі, тож підкласи (UnboundLocalError) - раніше за батьків.
CRASH_REASONS = (
    (ZeroDivisionError, "ділення на нуль. Перевір, чи дільник не 0, перш ніж ділити"),
    (RecursionError, "занадто глибокий виклик: функції викликають одна одну без кінця"),
    (UnboundLocalError, "не вистачає значення: змінна використана раніше, ніж їй щось присвоїли"),
    (NameError, "не вистачає значення: такої змінної чи функції немає"),
    (TypeError, "значення не того типу (число замість тексту чи навпаки)"),
    (MemoryError, "забракло пам'яті: занадто великий текст чи число"),
    (OverflowError, "число вийшло занадто великим"),
)


def crash_reason(exc):
    """Що сталося, українською. Невідомі помилки - як їх пише Python."""
    for kind, reason in CRASH_REASONS:
        if isinstance(exc, kind):
            return reason
    return "{}: {}".format(type(exc).__name__, exc)


def student_line(exc, file):
    """Рядок у файлі учня, де сталася помилка (останній у трасуванні), або None."""
    line = None
    trace = exc.__traceback__
    while trace is not None:
        if trace.tb_frame.f_code.co_filename == file:
            line = trace.tb_lineno
        trace = trace.tb_next
    return line


class GlobeEngine:
    def __init__(
        self,
        catalog,
        settings,
        display=None,
        speaker=None,
        audio_source=None,
        clock=None,
        sleep=None,
        rng=None,
        on_warning=None,
        on_note=None,
    ):
        self.catalog = catalog
        self.settings = settings
        self.display = display
        self.speaker = speaker
        self.audio_source = audio_source
        self._clock = clock or time.monotonic
        self._sleep = sleep or time.sleep
        self._rng = rng or random.Random()
        self._on_warning = on_warning
        self._on_note = on_note

        self.hooks = {}
        self.screen = Screen()
        self.mode = NORMAL
        self._press_counts = {}
        self._warned = set()

        # Під час ігор show_country() не малює, а записує відповідь гравця.
        self._answer = None
        # "target" або "question": коли можна викликати target() / ask().
        self._phase = None
        # Загадана країна (ID великими літерами).
        self._expected = None
        # Пробний запуск on_button, щоб дізнатися, яка кнопка яку країну
        # показує, або читання відповіді в грі: тоді нічого не малюється,
        # не грає й не чекає.
        self._probing = False
        # Уже всередині show_fact(): show_country() звідти не викликає її знову.
        self._in_fact = False

        self._number = 0
        self._round = 0
        self._score = 0
        self._round_started = None

    # ------------------------------------------------------------------
    # Підключення коду учнів
    # ------------------------------------------------------------------
    def set_hooks(self, hooks):
        self.hooks = dict(hooks)

    def api(self):
        """Функції, які бачить код учнів. Назви - з globe_core/hooks.py."""
        return {
            "play_sound": self.play_sound,
            "show_country": self.show_country,
            "show_text": self.show_text,
            "clear_screen": self.clear_screen,
            "blink": self.blink,
            "wait": self.wait,
            "random_number": self.random_number,
            "target": self.target,
            "ask": self.ask,
        }

    # ------------------------------------------------------------------
    # Повідомлення: кожне попередження - лише один раз
    # ------------------------------------------------------------------
    def warn(self, message):
        if message in self._warned:
            return
        self._warned.add(message)
        if self._on_warning is not None:
            try:
                self._on_warning(message)
            except Exception:
                # Збій у виведенні попереджень не має зупиняти код учня.
                pass
        else:
            print("[увага] " + message)

    def note(self, message):
        if self._on_note is not None:
            self._on_note(message)

    def loop_stuck(self, file, line):
        self.warn(
            "{}, рядок {}: схоже, while ніколи не закінчиться - перевір умову. "
            "Цикл зупинено після {} повторів.".format(file, line, LOOP_LIMIT)
        )

    def _call(self, name, *args):
        """Викликає хук учня. False, якщо такого хука немає."""
        function = self.hooks.get(name)
        if function is None:
            return False
        try:
            function(*args)
        except Exception as exc:
            file = HOOKS[name].file
            line = student_line(exc, file)
            where = " в рядку {}".format(line) if line is not None else ""
            self.warn(
                "функція {}() з {} {}{}: {}".format(name, file, CRASHED, where, crash_reason(exc))
            )
        return True

    def _refresh(self):
        if self.display is None:
            return
        try:
            self.display.refresh(self.screen)
        except Exception as exc:
            self.warn("не вдалося вивести на дисплей: {}".format(exc))

    # ------------------------------------------------------------------
    # Запуск
    # ------------------------------------------------------------------
    def boot(self):
        self.screen.clear()
        self._call("loading")
        if not self._call("hello_screen"):
            self.screen.clear()
            self.screen.write(0, "TouchTheGlobe")
            self.screen.write(2, "Touch country!")
        if "on_button" not in self.hooks:
            self.warn(NO_TASK1)
        self._refresh()

    # ------------------------------------------------------------------
    # Торкання
    # ------------------------------------------------------------------
    def touch_button(self, number, ms=None):
        """Торкнулися кнопки країни number (з 1). ms - час для тестів гри."""
        if self.mode == FINISHED:
            self.mode = NORMAL
        if not 1 <= number <= self.settings.button_count:
            self.warn(
                "кнопки {} немає: у settings.py їх {}.".format(
                    number, self.settings.button_count
                )
            )
            return

        if self.mode == NORMAL:
            if not self._call("on_button", number):
                self.warn(NO_TASK1)
            self._refresh()
            return

        answer = self._read_answer(number)
        if answer is None:
            # Ця кнопка не показує жодної країни - відповіддю не вважається.
            return
        if self.mode == QUIZ:
            self._finish_question(answer)
        else:
            self._finish_round(answer, ms)

    def press_count(self, country_id):
        return self._press_counts.get(str(country_id).upper(), 0)

    def mapped_country(self, number):
        """Країна, яку вчитель закріпив за кнопкою number (settings.py), або None."""
        countries = self.settings.button_countries
        if not 1 <= number <= min(len(countries), self.settings.button_count):
            return None
        wanted = countries[number - 1]
        if not wanted:
            return None
        country = self.catalog.get(wanted)
        if country is None:
            self.warn(
                "settings.py: кнопці {} призначено країну {}, якої немає. Є: {}".format(
                    number, wanted, ", ".join(self.catalog.ids())
                )
            )
            return None
        return country.id.upper()

    def _probe_button(self, number):
        """Яку країну показав би on_button(number): нічого не малює й не грає."""
        self._answer = None
        saved = self._probing
        self._probing = True
        try:
            self._call("on_button", number)
        finally:
            self._probing = saved
        return self._answer

    def _read_answer(self, number):
        """Яку країну обрано кнопкою number у грі чи вікторині.

        Береться з таблиці вчителя (BUTTON_COUNTRIES у settings.py): тоді ігри
        не залежать від task1. Для кнопки без запису - як раніше: on_button
        у режимі гри. Поки читаємо, show_text, clear_screen, blink і wait
        нічого не роблять - «секретна» кнопка не зітре питання й не з'їсть час.
        """
        mapped = self.mapped_country(number)
        if mapped is not None:
            return mapped
        return self._probe_button(number)

    def button_for(self, country_id):
        """Яка кнопка показує цю країну - для підказки в консолі."""
        wanted = str(country_id).upper()
        saved = self._answer
        try:
            for number in range(1, self.settings.button_count + 1):
                mapped = self.mapped_country(number)
                answer = mapped if mapped is not None else self._probe_button(number)
                if answer == wanted:
                    return number
            return None
        finally:
            self._answer = saved

    def check_buttons(self):
        """Звіряє on_button із таблицею вчителя: розбіжність - лише попередження."""
        if "on_button" not in self.hooks:
            return
        saved = self._answer
        try:
            for number in range(1, self.settings.button_count + 1):
                expected = self.mapped_country(number)
                if expected is None:
                    continue
                shown = self._probe_button(number)
                if shown == expected:
                    continue
                if shown is None:
                    self.warn(
                        "кнопка {} за таблицею вчителя - {}, а on_button({}) нічого "
                        "не показує. Гра однаково чекатиме {}.".format(
                            number, expected, number, expected
                        )
                    )
                else:
                    self.warn(
                        "кнопка {} за таблицею вчителя - {}, а on_button({}) показує {}. "
                        "Гра однаково чекатиме {}.".format(
                            number, expected, number, shown, expected
                        )
                    )
        finally:
            self._answer = saved

    def _note_expected(self):
        number = self.button_for(self._expected)
        self.note(
            "(загадано: {} — кнопка {})".format(
                self._expected, number if number is not None else "?"
            )
        )

    def _pause(self, ms):
        if ms > 0:
            self._sleep(ms / 1000.0)

    # ------------------------------------------------------------------
    # Вікторина (task3)
    # ------------------------------------------------------------------
    def touch_quiz(self):
        if self.mode in (QUIZ, GAME):
            return
        self._number = 1
        self._score = 0
        self._next_question()

    def _next_question(self):
        self.screen.clear()
        self._expected = None
        self._phase = "question"
        try:
            if self._number <= QUIZ_MAX_QUESTIONS:
                self._call("question", self._number)
        finally:
            self._phase = None

        if self._expected is None:
            if self._number == 1:
                self.screen.clear()
                self.screen.write(2, "No questions")
                self.mode = NORMAL
                if "question" not in self.hooks:
                    self.warn("немає task3.py - вікторині нема що питати.")
                self._refresh()
                return
            self._quiz_final()
            return

        self.mode = QUIZ
        self._refresh()
        self._note_expected()

    def _finish_question(self, answer):
        correct = answer == self._expected
        if correct:
            self._score += 1
        for row in (3, 4, 5):
            self.screen.write(row, "")
        self.screen.write(5, "Score: {}/{}".format(self._score, self._number))
        self._call("on_answer", correct, self._score)
        self._refresh()
        self._pause(self.settings.quiz_pause_ms)
        self._number += 1
        self._next_question()

    def _quiz_final(self):
        total = self._number - 1
        self.screen.clear()
        self._call("final", self._score, total)
        self.screen.write(5, "Score: {}/{}".format(self._score, total))
        self.mode = FINISHED
        self._refresh()

    # ------------------------------------------------------------------
    # «Блискавка» (task2)
    # ------------------------------------------------------------------
    def touch_game(self):
        if self.mode in (QUIZ, GAME):
            return
        self.screen.clear()
        self.screen.write(1, "Ready?")
        for number in (3, 2, 1):
            self.screen.write(2, str(number))
            self._refresh()
            self._sleep(0.5)
        self._round = 1
        self._score = 0
        self._start_round()

    def _start_round(self):
        rounds = self.settings.game_rounds
        self.screen.clear()
        self.screen.write(0, "Round {}/{}".format(self._round, rounds))
        self.screen.write(5, "Score: {}".format(self._score))
        self._expected = None
        self._phase = "target"
        try:
            self._call("next_target", self._round)
        finally:
            self._phase = None

        if self._expected is None:
            if self._round == 1:
                self.screen.clear()
                self.screen.write(2, "No game")
                self.mode = NORMAL
                if "next_target" not in self.hooks:
                    self.warn("немає task2.py - грі «Блискавка» нема що загадувати.")
                self._refresh()
                return
            self._game_over()
            return

        self.mode = GAME
        self._refresh()
        self._note_expected()
        self._round_started = self._clock()

    def _finish_round(self, answer, ms=None):
        timeout = self.settings.game_timeout_ms
        if ms is None:
            ms = int(round((self._clock() - self._round_started) * 1000))
        correct = answer is not None and answer == self._expected
        if ms > timeout:
            correct = False
            ms = timeout
        if correct:
            self._score += 1
        self.screen.write(3, "")
        self.screen.write(4, "")
        self.screen.write(5, "Score: {}".format(self._score))
        self._call("on_hit", correct, ms)
        self._refresh()
        self._pause(self.settings.game_pause_ms)
        if self._round < self.settings.game_rounds:
            self._round += 1
            self._start_round()
        else:
            self._game_over()

    def tick(self):
        """Чи не вийшов час раунду. Плата робить те саме щоразу в loop()."""
        if self.mode != GAME or self._round_started is None:
            return
        elapsed = (self._clock() - self._round_started) * 1000
        if elapsed > self.settings.game_timeout_ms:
            self.timeout_round()

    def timeout_round(self):
        """Завершує раунд так, ніби час вийшов (для tick і перевірок)."""
        if self.mode == GAME:
            self._finish_round(None, self.settings.game_timeout_ms)

    def _game_over(self):
        rounds = self.settings.game_rounds
        self.screen.clear()
        self._call("game_over", self._score, rounds)
        self.screen.write(5, "Score: {}/{}".format(self._score, rounds))
        self.mode = FINISHED
        self._refresh()

    # ------------------------------------------------------------------
    # API для учнів
    # ------------------------------------------------------------------
    def _country(self, country_id, function):
        country = self.catalog.get(str(country_id))
        if country is None:
            self.warn(
                '{}("{}"): немає такої країни. Є: {}'.format(
                    function, country_id, ", ".join(self.catalog.ids())
                )
            )
        return country

    def _answering(self):
        return self.mode in (QUIZ, GAME) or self._probing

    def play_sound(self, country_id):
        if self._answering():
            return
        country = self._country(country_id, "play_sound")
        if country is None or self.speaker is None or self.audio_source is None:
            return
        try:
            audio_ref = self.audio_source.resolve(country)
            if audio_ref is not None:
                self.speaker.play(audio_ref)
        except Exception as exc:
            self.warn("не вдалося програти звук для {}: {}".format(country.id, exc))

    def show_country(self, country_id):
        country = self._country(country_id, "show_country")
        if country is None:
            return
        if self._answering():
            if self._answer is None:
                self._answer = country.id.upper()
            return

        key = country.id.upper()
        count = self._press_counts.get(key, 0) + 1
        self._press_counts[key] = count

        self.screen.clear()
        self.screen.write(0, country.lcd_name, inverted=True)
        self.screen.write(1, country.lcd_capital)
        self.screen.write(5, "x{}".format(count))
        # show_country() усередині show_fact() лише малює країну, а факт
        # удруге не викликає - інакше вони викликали б одна одну без кінця.
        if self._in_fact:
            return
        self._in_fact = True
        try:
            self._call("show_fact", country)
        finally:
            self._in_fact = False

    def show_text(self, row, text):
        if self._probing:
            return
        if type(row) is not int or not 0 <= row < SCREEN_ROWS:
            self.warn("show_text({}, ...): на екрані 6 рядків, від 0 до 5.".format(row))
            return
        text = str(text)
        if len(text) > WIDTH:
            self.warn(
                "show_text: текст '{}' довший за {} символів - зайве обріжеться.".format(text, WIDTH)
            )
        if not text.isascii():
            self.warn(
                "show_text: '{}' - екран не показує українські літери, буде '?'.".format(text)
            )
        self.screen.write(row, text)

    def clear_screen(self):
        if self._probing:
            return
        self.screen.clear()

    def blink(self, times):
        if self._probing or times <= 0:
            return
        self._refresh()
        if self.display is not None:
            try:
                self.display.blink(times)
            except Exception as exc:
                self.warn("не вдалося помигати підсвіткою: {}".format(exc))
        # На платі одне мигання - 150 мс без світла і 150 мс зі світлом.
        self._sleep(times * 0.3)

    def wait(self, ms):
        if self._probing or ms <= 0:
            return
        self._refresh()
        self._sleep(ms / 1000.0)

    def random_number(self, low, high):
        if high < low:
            return low
        return self._rng.randint(low, high)

    def target(self, country_id, hint):
        if self._phase != "target":
            self.warn("target() працює лише всередині next_target().")
            return
        country = self._country(country_id, "target")
        if country is None:
            return
        self._expected = country.id.upper()
        self.screen.write(1, str(hint))

    def ask(self, text, country_id):
        if self._phase != "question":
            self.warn("ask() працює лише всередині question().")
            return
        country = self._country(country_id, "ask")
        if country is None:
            return
        self._expected = country.id.upper()
        for index, line in enumerate(wrap_words(str(text), WIDTH, 3)):
            self.screen.write(index, line)
