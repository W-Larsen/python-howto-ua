"""Назви пінів Arduino Uno -> номери, які розуміє програма на платі.

На платі піни підписані "D2", "A0" і так далі. У коді для Arduino цифрові
піни - це просто числа (D2 - це 2), а аналогові йдуть далі за цифровими:
A0 - це 14, A1 - 15 і так до A5 = 19. Саме тому аналоговий пін спокійно
працює і як звичайний цифровий вхід для сенсорної кнопки.

Ця таблиця потрібна і комп'ютеру (команда doctor перевіряє, чи існує пін,
який учень вписав у BUTTONS), і платі - там та сама таблиця повторена
у файлі arduino/TouchTheGlobe/pins.h.
"""

UNO_PINS = {
    # Цифрові піни
    "D0": 0,  # також RX: зайнятий USB-портом
    "D1": 1,  # також TX: зайнятий USB-портом
    "D2": 2,
    "D3": 3,
    "D4": 4,
    "D5": 5,
    "D6": 6,
    "D7": 7,
    "D8": 8,
    "D9": 9,
    "D10": 10,
    "D11": 11,
    "D12": 12,
    "D13": 13,  # на цьому піні висить вбудований світлодіод
    # Аналогові піни. Як цифрові вони мають номери 14-19.
    "A0": 14,
    "A1": 15,
    "A2": 16,
    "A3": 17,
    "A4": 18,
    "A5": 19,
}

# Піни, які краще не займати: через них плата спілкується з комп'ютером.
RESERVED_PINS = ("D0", "D1")


class PinError(Exception):
    pass


def to_pin(label):
    """Перетворює "D2" у 2, а "A0" - у 14. Число повертає без змін."""
    if isinstance(label, int):
        return label

    if not isinstance(label, str):
        raise PinError(
            "Назва піна має бути текстом у лапках, наприклад \"A0\", "
            "а не {}".format(type(label).__name__)
        )

    key = label.strip().upper()
    if key in UNO_PINS:
        return UNO_PINS[key]

    # Учень міг написати просто число рядком: "5"
    if key.isdigit() and int(key) in UNO_PINS.values():
        return int(key)

    raise PinError(
        "На платі Arduino Uno немає піна '{}'.\n"
        "  Доступні назви: D0-D13, A0-A5.".format(label)
    )


def is_known(label):
    try:
        to_pin(label)
        return True
    except PinError:
        return False
