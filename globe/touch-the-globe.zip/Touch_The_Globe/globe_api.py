"""Підказки для редактора: які функції дає глобус.

Цей файл НЕ редагуй. Він потрібен лише для того, щоб VS Code
показував підказки (наведи курсор на назву або натисни Ctrl+Пробіл).
Саму роботу виконує глобус, а не цей файл.

У кожній задачі вгорі стоїть рядок  from globe_api import *
"""

__all__ = [
    "play_sound",
    "show_country",
    "show_text",
    "clear_screen",
    "blink",
    "wait",
    "random_number",
    "target",
    "ask",
]


def play_sound(country_id: str) -> None:
    """Увімкнути розповідь про країну.

    country_id - ID країни, наприклад "UA". Усі ID: globe list
    """


def show_country(country_id: str) -> None:
    """Показати екран країни: назва, столиця і скільки разів її торкнулися.

    country_id - ID країни, наприклад "UA". Усі ID: globe list
    Усередині show_fact() цю функцію викликати не можна.
    """


def show_text(row: int, text: str) -> None:
    """Написати свій текст на екрані.

    row - рядок екрана від 0 до 5.
    text - до 14 латинських літер (українських екран не показує).
    """


def clear_screen() -> None:
    """Стерти все з екрана."""


def blink(times: int) -> None:
    """Помигати підсвіткою екрана times разів."""


def wait(ms: int) -> None:
    """Зачекати ms мілісекунд (1000 мс = 1 секунда)."""


def random_number(low: int, high: int) -> int:
    """Випадкове ціле число від low до high (обидва входять)."""
    return low


def target(country_id: str, hint: str) -> None:
    """Загадати країну в грі. Працює лише всередині next_target().

    country_id - ID загаданої країни, hint - підказка на екрані (до 14 літер).
    """


def ask(text: str, country_id: str) -> None:
    """Поставити питання у вікторині. Працює лише всередині question().

    text - питання (до 42 літер), country_id - ID країни з правильною відповіддю.
    """
