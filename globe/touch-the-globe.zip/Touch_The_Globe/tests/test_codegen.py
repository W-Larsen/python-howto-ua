"""Перекладач у C++: що саме він пише для типових конструкцій."""

import re
import tempfile
import textwrap
import unittest
from pathlib import Path

from globe_core.cpp_codegen import generate_header
from globe_core.hooks import HOOK_LIST
from globe_core.language import Context, analyze_all
from globe_core.settings import DEFAULTS, Settings, default_settings
from tests import DEMO_COUNTRIES, ROOT
from tools.build_student_code import main, render

CONTEXT = Context(["UA", "JP", "EG", "BR", "AU", "US"], 5)


def header_for(**files):
    sources = {name.replace("_", "") + ".py": textwrap.dedent(code) for name, code in files.items()}
    infos, problems = analyze_all(sources, CONTEXT)
    assert not [p for p in problems if p.is_error], [str(p) for p in problems]
    return generate_header(default_settings(), infos)


class SettingsAndSkeletonTests(unittest.TestCase):
    def setUp(self):
        self.header = header_for()

    def test_generated_mark_and_guard(self):
        self.assertIn("ЗГЕНЕРОВАНО автоматично", self.header)
        self.assertIn("#ifndef STUDENT_CODE_H", self.header)
        self.assertIn('#include "globe_api.h"', self.header)
        self.assertIn('#include "student_hooks.h"', self.header)

    def test_settings_constants(self):
        self.assertIn('const char* const BUTTON_PINS[] = {"A0", "A1", "A2", "A3", "A4"};', self.header)
        self.assertIn("const uint8_t BUTTON_COUNT = 5;", self.header)
        self.assertIn('const char* const QUIZ_PIN = "D10";', self.header)
        self.assertIn("const unsigned long GAME_TIMEOUT_MS = 5000UL;", self.header)

    def test_no_table_means_an_empty_button_answer(self):
        self.assertIn("void student_button_answer(long number) {\n}", self.header)
        self.assertNotIn("BUTTON_COUNTRIES[]", self.header)

    def test_table_becomes_cpp_code_not_a_table(self):
        settings = Settings(dict(DEFAULTS, BUTTON_COUNTRIES=["UA", "", "AU"]))
        header = generate_header(settings, {})
        self.assertIn(
            "void student_button_answer(long number) {\n"
            "  if (number == 1) {\n"
            '    show_country("UA");\n'
            "  } else if (number == 3) {\n"
            '    show_country("AU");\n'
            "  }\n"
            "}",
            header,
        )
        self.assertNotIn("BUTTON_COUNTRIES[]", header)

    def test_countries_beyond_buttons_are_dropped(self):
        settings = Settings(dict(DEFAULTS, BUTTON_COUNTRIES=["UA", "UA", "UA", "UA", "UA", "JP"]))
        header = generate_header(settings, {})
        self.assertNotIn("number == 6", header)
        self.assertNotIn('"JP"', header)

    def test_every_hook_has_a_function(self):
        for hook in HOOK_LIST:
            self.assertIn("void student_{}(".format(hook.name), self.header)

    def test_no_hooks_present(self):
        self.assertIn("uint16_t student_hooks_present() { return 0x0000; }", self.header)


class TranslationTests(unittest.TestCase):
    def test_task1_card(self):
        header = header_for(
            task_1='''
            def on_button(number):
                if number == 1:
                    play_sound("UA")
                    show_country("UA")
                elif number == 2:
                    pass
                else:
                    show_text(3, "?")
            '''
        )
        self.assertIn("void student_on_button(long s_number) {", header)
        self.assertIn("if ((s_number == 1L)) {", header)
        self.assertIn('play_sound(F("UA"));', header)
        self.assertIn("} else if ((s_number == 2L)) {", header)
        self.assertIn('show_text(3L, F("\\?"));', header)
        self.assertIn("return 0x0001;", header)

    def test_string_concat_and_str(self):
        header = header_for(
            task_2='''
            def on_hit(correct, ms):
                label = "ms " + str(ms)
                show_text(4, label)
                show_text(3, str(correct))
            '''
        )
        self.assertIn("String s_label = \"\";", header)
        self.assertIn('s_label = (String(F("ms ")) + py_str(s_ms));', header)
        self.assertIn("show_text(3L, py_str_bool(s_correct));", header)

    def test_floor_division_and_modulo(self):
        header = header_for(task_3="def final(score, total):\n    x = score // 2 + total % 3\n")
        self.assertIn("s_x = (py_div(s_score, 2L) + py_mod(s_total, 3L));", header)

    def test_for_range_counts_end_once(self):
        header = header_for(task_5="def loading():\n    for i in range(10, 0, -3):\n        wait(i)\n")
        self.assertIn("long s_i = 0;", header)
        self.assertIn("long _end1 = 0L;", header)
        self.assertIn("for (long _k1 = _start1; _k1 > _end1; _k1 += -3L) {", header)
        self.assertIn("s_i = _k1;", header)

    def test_while_has_a_guard(self):
        header = header_for(task_5="def loading():\n    n = 0\n    while n < 5:\n        n += 1\n")
        self.assertIn("long _guard1 = 0;", header)
        self.assertIn("if (++_guard1 > 1000L) {", header)
        self.assertIn('globe_loop_stuck(F("task5.py"), 3);', header)
        self.assertIn("s_n = (s_n + 1L);", header)

    def test_print(self):
        header = header_for(task_5='def loading():\n    print("a", 5, True)\n')
        self.assertIn('Serial.print(F("a"));', header)
        self.assertIn("Serial.print(' ');", header)
        self.assertIn("Serial.print(5L);", header)
        self.assertIn('Serial.print((true ? F("True") : F("False")));', header)
        self.assertIn("Serial.println();", header)

    def test_country_fields_and_prefix(self):
        header = header_for(
            task_4='''
            def show_fact(country):
                if country.id == "UA":
                    show_text(2, country.lcd_capital)
            '''
        )
        self.assertIn("void student_show_fact(const Country& s_country) {", header)
        self.assertIn('if ((s_country.id == String(F("UA")))) {', header)
        self.assertIn("show_text(2L, s_country.lcdCapital);", header)

    def test_round_parameter_is_safe(self):
        header = header_for(task_2='def next_target(round):\n    target("JP", "T" + str(round))\n')
        self.assertIn("void student_next_target(long s_round) {", header)
        self.assertIn('target(F("JP"), (String(F("T")) + py_str(s_round)));', header)

    def test_quotes_and_backslash(self):
        header = header_for(task_5='def loading():\n    print("say \\"hi\\" \\\\")\n')
        self.assertIn('Serial.print(F("say \\"hi\\" \\\\"));', header)

    def test_bool_and_not(self):
        header = header_for(
            task_2="def on_hit(correct, ms):\n    if not correct and ms > 0 or ms == 1:\n        return\n"
        )
        self.assertIn("if ((((!s_correct) && (s_ms > 0L)) || (s_ms == 1L))) {", header)
        self.assertIn("return;", header)

    def test_int_condition(self):
        header = header_for(task_2="def on_hit(correct, ms):\n    if ms % 2:\n        pass\n")
        self.assertIn("if ((py_mod(s_ms, 2L) != 0)) {", header)

    def test_signatures_match_student_hooks_header(self):
        """Прототипи в student_hooks.h мають збігатися з тим, що генерується."""
        hooks_header = (ROOT / "arduino" / "TouchTheGlobe" / "student_hooks.h").read_text(encoding="utf-8")
        generated = header_for()
        for hook in HOOK_LIST:
            pattern = r"void student_{}\(([^)]*)\)".format(hook.name)
            declared = re.search(pattern, hooks_header).group(1)
            defined = re.search(pattern, generated).group(1)
            strip = lambda text: [part.rsplit(" ", 1)[0].strip() for part in text.split(",") if part.strip()]
            self.assertEqual(strip(declared), strip(defined), hook.name)


class EdgeCaseTests(unittest.TestCase):
    """Крайні випадки: усі дужки закриті, а лічильники поводяться як у Python."""

    def test_elif_chain_without_else_closes(self):
        header = header_for(
            task_1="def on_button(number):\n    if number == 1:\n        pass\n    elif number == 2:\n        pass\n"
        )
        body = header.split("void student_on_button(long s_number) {")[1].split("// ")[0]
        self.assertEqual(body.count("{") + 1, body.count("}"))  # відкриваюча "{" функції лишилась поза body
        self.assertIn("} else if ((s_number == 2L)) {", body)
        self.assertNotIn("} else {", body)

    def test_nested_if_in_else_stays_equivalent(self):
        header = header_for(
            task_1=(
                "def on_button(number):\n"
                "    if number == 1:\n        pass\n"
                "    else:\n        if number == 2:\n            pass\n        else:\n            pass\n"
            )
        )
        self.assertIn("} else if ((s_number == 2L)) {", header)
        self.assertIn("} else {", header)

    def test_if_with_only_a_comment_is_empty_block(self):
        header = header_for(task_1='def on_button(number):\n    if number == 1:\n        "тут пусто"\n')
        self.assertIn("if ((s_number == 1L)) {\n  }", header)

    def test_range_bound_taken_before_loop_variable_changes(self):
        header = header_for(task_2="def on_hit(correct, ms):\n    for ms in range(ms):\n        ms = 99\n")
        self.assertIn("long _end1 = s_ms;", header)
        self.assertIn("s_ms = _k1;", header)
        self.assertIn("s_ms = 99L;", header)

    def test_while_guard_runs_before_continue(self):
        header = header_for(
            task_5="def loading():\n    n = 0\n    while n < 5:\n        n += 1\n        continue\n"
        )
        guard = header.index("if (++_guard1 > 1000L) {")
        self.assertLess(guard, header.index("continue;"))
        self.assertLess(guard, header.index("s_n = (s_n + 1L);"))

    def test_unary_minus_and_string_append(self):
        header = header_for(
            task_5='def loading():\n    n = -5\n    m = -n\n    s = "a"\n    s += "b"\n'
        )
        self.assertIn("s_n = (-5L);", header)
        self.assertIn("s_m = (-s_n);", header)
        self.assertIn('s_s = (s_s + String(F("b")));', header)

    def test_only_for_target_variable_is_declared(self):
        header = header_for(task_5="def loading():\n    for i in range(3):\n        wait(1)\n")
        self.assertIn("  long s_i = 0;", header)


class PrintCountryFieldTests(unittest.TestCase):
    def test_print_country_field(self):
        header = header_for(task_4="def show_fact(country):\n    print(country.lcd_name)\n")
        self.assertIn("Serial.print(s_country.lcdName);", header)


class BuildToolTests(unittest.TestCase):
    def test_render_reference_solutions(self):
        header, problems = render(ROOT, ROOT / "tests" / "fixtures" / "solutions", DEMO_COUNTRIES)
        self.assertIsNotNone(header, [str(p) for p in problems])
        self.assertIn("return 0x03FF;", header)

    def test_errors_stop_the_build(self):
        with tempfile.TemporaryDirectory() as folder:
            students = Path(folder)
            (students / "task1.py").write_text("def on_button(number):\n    x = [1]\n", encoding="utf-8")
            header, problems = render(ROOT, students)
        self.assertIsNone(header)
        self.assertTrue(any("task1.py" in str(p) for p in problems))
