"""Шаблони для учнів і еталонні розв'язки мають бути без помилок."""

import unittest

from globe_core.catalog import load_catalog
from globe_core.hooks import TASK_FILES
from globe_core.language import Context, analyze_task, read_task_sources
from globe_core.settings import load_settings
from pc.cli import smoke_run
from tests import DEMO_COUNTRIES, ROOT

TEMPLATES = ROOT / "students"
SOLUTIONS = ROOT / "tests" / "fixtures" / "solutions"


class FolderChecks:
    folder = None

    def setUp(self):
        self.catalog = load_catalog(str(DEMO_COUNTRIES))
        self.settings, _ = load_settings(ROOT / "settings.py")
        self.context = Context(self.catalog.ids(), self.settings.button_count)
        self.sources, self.read_problems = read_task_sources(self.folder)

    def test_all_five_files_exist(self):
        self.assertEqual(self.read_problems, [])
        self.assertEqual(sorted(self.sources), list(TASK_FILES))

    def test_no_problems(self):
        for file, source in self.sources.items():
            info, problems = analyze_task(file, source, self.context)
            self.assertEqual(problems, [], "{}: {}".format(file, [str(p) for p in problems]))

    def test_smoke_run_is_clean(self):
        warnings = smoke_run(self.catalog, self.settings, self.folder)
        self.assertEqual(warnings, [])


class TemplateTests(FolderChecks, unittest.TestCase):
    folder = TEMPLATES

    def test_templates_explain_how_to_check(self):
        for file, source in self.sources.items():
            self.assertIn("globe test", source, file)
            self.assertIn("Тобі допоможуть", source, file)


class SolutionTests(FolderChecks, unittest.TestCase):
    folder = SOLUTIONS


if __name__ == "__main__":
    unittest.main()


class EditorStubTests(unittest.TestCase):
    """globe_api.py дає редактору підказки: має збігатися з hooks.API."""

    def test_stub_matches_api_table(self):
        import importlib.util
        import inspect

        from globe_core.hooks import API

        spec = importlib.util.spec_from_file_location("globe_api", ROOT / "globe_api.py")
        stub = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(stub)
        self.assertEqual(set(stub.__all__), set(API))
        for name, function in API.items():
            params = inspect.signature(getattr(stub, name)).parameters
            self.assertEqual(len(params), len(function.params), name)
            self.assertTrue(getattr(stub, name).__doc__, name)

    def test_every_template_imports_the_stub(self):
        for number in range(1, 6):
            text = (ROOT / "students" / "task{}.py".format(number)).read_text(encoding="utf-8")
            self.assertIn("from globe_api import *", text)
