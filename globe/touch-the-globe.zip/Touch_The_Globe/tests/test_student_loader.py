"""Код учнів на комп'ютері: завантаження, захист while, обмежені builtins."""

import tempfile
import textwrap
import unittest
from pathlib import Path

from globe_core.language import Context
from globe_core.student_loader import compile_task, load_students

CONTEXT = Context(country_ids=["UA", "JP"], button_count=5)


class RecordingApi:
    def __init__(self):
        self.log = []
        self.stuck = []

    def functions(self):
        def make(name):
            return lambda *args: self.log.append((name,) + args)

        names = ("play_sound", "show_country", "show_text", "clear_screen",
                 "blink", "wait", "target", "ask")
        api = {name: make(name) for name in names}
        api["random_number"] = lambda low, high: low
        return api

    def loop_stuck(self, file, line):
        self.stuck.append((file, line))


class LoaderCase(unittest.TestCase):
    def setUp(self):
        self._folder = tempfile.TemporaryDirectory()
        self.folder = Path(self._folder.name)
        self.api = RecordingApi()

    def tearDown(self):
        self._folder.cleanup()

    def write(self, name, source):
        (self.folder / name).write_text(textwrap.dedent(source), encoding="utf-8")

    def load(self):
        return load_students(self.folder, self.api.functions(), CONTEXT, self.api.loop_stuck)


class LoadStudentsTests(LoaderCase):
    def test_hooks_are_loaded_and_call_the_api(self):
        self.write(
            "task1.py",
            """
            def on_button(number):
                if number == 1:
                    play_sound("UA")
                    show_country("UA")
            """,
        )
        code = self.load()
        self.assertEqual(code.problems, [])
        self.assertEqual(code.files, ["task1.py"])
        code.hooks["on_button"](1)
        self.assertEqual(self.api.log, [("play_sound", "UA"), ("show_country", "UA")])

    def test_file_with_errors_is_not_loaded(self):
        self.write("task1.py", "def on_button(number):\n    x = [1]\n")
        self.write("task5.py", "def loading():\n    wait(1)\n")
        code = self.load()
        self.assertNotIn("on_button", code.hooks)
        self.assertIn("loading", code.hooks)
        self.assertTrue(any("task1.py" in str(problem) for problem in code.problems))

    def test_warnings_do_not_block(self):
        self.write("task1.py", "def on_button(number):\n    if number == 9:\n        pass\n")
        code = self.load()
        self.assertIn("on_button", code.hooks)
        self.assertTrue(code.problems)

    def test_missing_folder(self):
        code = load_students(self.folder / "nope", {}, CONTEXT, self.api.loop_stuck)
        self.assertEqual(code.hooks, {})
        self.assertTrue(code.problems)


class LoopGuardTests(LoaderCase):
    def test_endless_while_stops_after_the_limit(self):
        self.write(
            "task5.py",
            """
            def loading():
                n = 0
                while True:
                    n += 1
                show_text(2, str(n))
            """,
        )
        code = self.load()
        code.hooks["loading"]()
        self.assertEqual(self.api.log, [("show_text", 2, "1000")])
        self.assertEqual(self.api.stuck, [("task5.py", 4)])

    def test_each_loop_has_its_own_counter(self):
        self.write(
            "task5.py",
            """
            def loading():
                a = 0
                while a < 600:
                    a += 1
                b = 0
                while b < 600:
                    b += 1
                show_text(2, str(a + b))
            """,
        )
        code = self.load()
        code.hooks["loading"]()
        self.assertEqual(self.api.log, [("show_text", 2, "1200")])
        self.assertEqual(self.api.stuck, [])

    def test_counter_restarts_on_every_call(self):
        self.write(
            "task5.py",
            """
            def loading():
                n = 0
                while n < 800:
                    n += 1
            """,
        )
        code = self.load()
        code.hooks["loading"]()
        code.hooks["loading"]()
        self.assertEqual(self.api.stuck, [])


class LocalDefaultsTests(LoaderCase):
    """Як на платі: кожна змінна хука вже має значення 0, "" або False.

    У C++ усі змінні оголошуються на початку функції, тож змінна, якій
    значення дали лише в одній гілці if, там просто порожня. На комп'ютері
    має бути так само, а не англійський UnboundLocalError.
    """

    def test_branch_assigned_string_is_empty(self):
        self.write(
            "task2.py",
            """
            def on_hit(correct, ms):
                if correct:
                    text = "Bravo"
                elif ms < 5:
                    text = "Slow"
                show_text(3, text)
            """,
        )
        code = self.load()
        self.assertEqual(code.problems, [])
        code.hooks["on_hit"](False, 100)
        code.hooks["on_hit"](True, 100)
        self.assertEqual(self.api.log, [("show_text", 3, ""), ("show_text", 3, "Bravo")])

    def test_int_bool_and_empty_range_loop_variable(self):
        self.write(
            "task5.py",
            """
            def loading():
                for i in range(0):
                    count = 5
                    done = True
                show_text(2, str(i) + str(count) + str(done))
            """,
        )
        code = self.load()
        code.hooks["loading"]()
        self.assertEqual(self.api.log, [("show_text", 2, "00False")])

    def test_parameters_are_not_reset(self):
        self.write(
            "task2.py",
            """
            def on_hit(correct, ms):
                ms = ms + 1
                show_text(3, str(ms))
            """,
        )
        code = self.load()
        code.hooks["on_hit"](True, 41)
        self.assertEqual(self.api.log, [("show_text", 3, "42")])

    def test_compile_task_takes_defaults_per_hook(self):
        from globe_core.hooks import BOOL, INT, STR

        functions = compile_task(
            "task2.py",
            "def on_hit(correct, ms):\n    if ms > 9:\n        word = 'x'\n        n = 1\n        ok = True\n"
            "    show_text(3, word + str(n) + str(ok))\n",
            self.api.functions(),
            self.api.loop_stuck,
            defaults={"on_hit": {"word": STR, "n": INT, "ok": BOOL}},
        )
        functions["on_hit"](True, 1)
        self.assertEqual(self.api.log, [("show_text", 3, "0False")])


class CompileTaskTests(unittest.TestCase):
    def test_only_safe_builtins(self):
        functions = compile_task(
            "task5.py", "def loading():\n    x = len('a')\n", {}, lambda file, line: None
        )
        with self.assertRaises(NameError):
            functions["loading"]()

    def test_print_can_be_replaced(self):
        printed = []
        functions = compile_task(
            "task5.py",
            "def loading():\n    print('a', 1)\n",
            {"print": lambda *args: printed.append(args)},
            lambda file, line: None,
        )
        functions["loading"]()
        self.assertEqual(printed, [("a", 1)])


if __name__ == "__main__":
    unittest.main()
