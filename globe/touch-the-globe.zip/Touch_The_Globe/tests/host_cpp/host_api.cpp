// Функції API, які лише записують, що їх викликали.
// Формат рядків - той самий, що в PythonRecorder у tests/test_parity.py.

#include <cstdio>
#include <vector>

#include "globe_api.h"

HostSerial Serial;

static std::vector<long> randoms;
static size_t nextRandom = 0;

void host_set_randoms(const std::vector<long>& values) {
  randoms = values;
  nextRandom = 0;
}

void play_sound(const String& countryId) { std::printf("play_sound|%s\n", countryId.c_str()); }

void show_country(const String& countryId) { std::printf("show_country|%s\n", countryId.c_str()); }

void show_text(long row, const String& text) { std::printf("show_text|%ld|%s\n", row, text.c_str()); }

void clear_screen() { std::printf("clear_screen\n"); }

void blink(long times) { std::printf("blink|%ld\n", times); }

void wait(long ms) { std::printf("wait|%ld\n", ms); }

long random_number(long low, long high) {
  long value = nextRandom < randoms.size() ? randoms[nextRandom++] : low;
  if (high < low) {
    value = low;
  } else {
    if (value < low) value = low;
    if (value > high) value = high;
  }
  std::printf("random_number|%ld|%ld|%ld\n", low, high, value);
  return value;
}

void target(const String& countryId, const String& hint) {
  std::printf("target|%s|%s\n", countryId.c_str(), hint.c_str());
}

void ask(const String& text, const String& countryId) {
  std::printf("ask|%s|%s\n", text.c_str(), countryId.c_str());
}

void globe_loop_stuck(const __FlashStringHelper* file, int line) {
  std::printf("loop_stuck|%s|%d\n", reinterpret_cast<const char*>(file), line);
}

void globe_warn_division_by_zero() { std::printf("division_by_zero\n"); }
