// Маленька заміна Arduino.h для тестів на комп'ютері.
//
// Лише те, чим користуються згенерований student_code.h і wrap_words.cpp: String, F(),
// Serial. Справжня плата для цих тестів не потрібна.

#ifndef HOST_ARDUINO_H
#define HOST_ARDUINO_H

#include <stdint.h>

#include <cstdio>
#include <string>

class __FlashStringHelper;
#define F(literal) (reinterpret_cast<const __FlashStringHelper*>(literal))

class String {
 public:
  String() {}
  String(const char* text) : value_(text) {}
  String(const __FlashStringHelper* text) : value_(reinterpret_cast<const char*>(text)) {}
  explicit String(long number) : value_(std::to_string(number)) {}
  explicit String(int number) : value_(std::to_string(number)) {}

  String& operator+=(const String& other) {
    value_ += other.value_;
    return *this;
  }
  friend String operator+(const String& left, const String& right) {
    String result(left);
    result += right;
    return result;
  }
  bool operator==(const String& other) const { return value_ == other.value_; }
  bool operator!=(const String& other) const { return value_ != other.value_; }
  unsigned int length() const { return static_cast<unsigned int>(value_.size()); }
  const char* c_str() const { return value_.c_str(); }

  // Для wrap_words.cpp - так само, як у WString.cpp з ядра Arduino AVR.
  String& operator+=(char symbol) {
    value_ += symbol;
    return *this;
  }
  char operator[](unsigned int index) const { return index < value_.size() ? value_[index] : 0; }
  int indexOf(char symbol, unsigned int fromIndex) const {
    if (fromIndex >= value_.size()) return -1;
    std::string::size_type found = value_.find(symbol, fromIndex);
    return found == std::string::npos ? -1 : static_cast<int>(found);
  }
  String substring(unsigned int left) const { return substring(left, length()); }
  String substring(unsigned int left, unsigned int right) const {
    if (left > right) {
      unsigned int swap = left;
      left = right;
      right = swap;
    }
    String out;
    if (left >= value_.size()) return out;
    if (right > value_.size()) right = static_cast<unsigned int>(value_.size());
    out.value_ = value_.substr(left, right - left);
    return out;
  }

 private:
  std::string value_;
};

// Serial збирає рядок, а println() друкує його як "print|...".
class HostSerial {
 public:
  void print(const String& value) { line_ += value.c_str(); }
  void print(const char* value) { line_ += value; }
  void print(const __FlashStringHelper* value) { line_ += reinterpret_cast<const char*>(value); }
  void print(long value) { line_ += std::to_string(value); }
  void print(int value) { line_ += std::to_string(value); }
  void print(char value) { line_ += value; }
  void println() {
    std::printf("print|%s\n", line_.c_str());
    line_.clear();
  }

 private:
  std::string line_;
};

extern HostSerial Serial;

#endif  // HOST_ARDUINO_H
