"""Паритет: перекладений C++ поводиться рівно як Python.

Кожен сценарій запускаємо двічі: у Python (через той самий завантажувач,
що й globe run) і як C++ на цьому комп'ютері (замість Arduino - маленька
заміна з tests/host_cpp/). Обидва пишуть журнал викликів, і журнали мають
збігтися рядок у рядок.
"""

import contextlib
import shutil
import subprocess
import tempfile
import textwrap
import unittest
from pathlib import Path

from globe_core.catalog import load_catalog
from globe_core.cpp_codegen import generate_header
from globe_core.language import Context, analyze_all, read_task_sources
from globe_core.settings import default_settings
from globe_core.student_loader import compile_task, hook_defaults
from tests import ROOT

SKETCH = ROOT / "arduino" / "TouchTheGlobe"
HOST = ROOT / "tests" / "host_cpp"
COMPILER = shutil.which("c++")
RANDOMS = [3, 1, 5, 2, 4, 6, 1]

CALLS = {
    "task1.py": [("on_button", (n,)) for n in range(1, 12)] + [("hello_screen", ())],
    "task2.py": [("next_target", (r,)) for r in (1, 2, 3)]
    + [("on_hit", (True, 500)), ("on_hit", (True, 1500)), ("on_hit", (False, 5000))]
    + [("on_hit", (True, 1000)), ("on_hit", (True, 999)), ("on_hit", (True, 2000)),
       ("on_hit", (True, 0)), ("on_hit", (True, -5)), ("on_hit", (False, 0))]
    + [("game_over", (5, 5)), ("game_over", (2, 5)), ("game_over", (0, 5)), ("game_over", (0, 0))],
    "task3.py": [("question", (n,)) for n in range(1, 8)]
    + [("on_answer", (True, 3)), ("on_answer", (True, 1)), ("on_answer", (False, 1))]
    + [("final", (5, 5)), ("final", (3, 5)), ("final", (1, 5))]
    + [("final", (0, 0)), ("final", (-3, -5)), ("final", (2, 5)), ("final", (4, 5))],
    "task4.py": [("show_fact", (cid,)) for cid in ("UA", "JP", "BR", "EG", "AU", "US")],
    "task5.py": [("loading", ())],
}


class PythonRecorder:
    def __init__(self):
        self.log = []
        self.randoms = list(RANDOMS)

    def functions(self):
        def logger(name):
            return lambda *args: self.log.append("|".join([name] + [str(a) for a in args]))

        api = {name: logger(name) for name in (
            "play_sound", "show_country", "show_text", "clear_screen",
            "blink", "wait", "target", "ask")}
        api["random_number"] = self.random_number
        api["print"] = lambda *args: self.log.append("print|" + " ".join(str(a) for a in args))
        return api

    def random_number(self, low, high):
        value = self.randoms.pop(0) if self.randoms else low
        if high < low:
            value = low
        else:
            value = min(max(value, low), high)
        self.log.append("random_number|{}|{}|{}".format(low, high, value))
        return value

    def loop_stuck(self, file, line):
        self.log.append("loop_stuck|{}|{}".format(file, line))


def cpp_literal(value):
    if isinstance(value, bool):
        return "true" if value else "false"
    return "{}L".format(value)


def driver_source(calls, catalog):
    lines = ["#include <cstdio>", "#include <vector>", '#include "student_code.h"',
             "void host_set_randoms(const std::vector<long>& values);", "int main() {",
             "  host_set_randoms({" + ", ".join(str(v) for v in RANDOMS) + "});"]
    for name, args in calls:
        lines.append('  std::printf("call|{}\\n");'.format(name))
        if name == "show_fact":
            country = catalog.get(args[0])
            lines.append("  {{ Country c; c.id = \"{}\"; c.lcdName = \"{}\"; c.lcdCapital = \"{}\"; c.track = {};".format(
                country.id, country.lcd_name, country.lcd_capital, country.track))
            lines.append("    student_show_fact(c); }")
        else:
            lines.append("  student_{}({});".format(name, ", ".join(cpp_literal(a) for a in args)))
    lines += ["  return 0;", "}"]
    return "\n".join(lines) + "\n"


@unittest.skipUnless(COMPILER, "немає компілятора c++")
class ParityTests(unittest.TestCase):
    def setUp(self):
        self.catalog = load_catalog(str(ROOT / "content" / "countries"))

    def python_log(self, sources, calls):
        recorder = PythonRecorder()
        infos, _ = analyze_all(sources, Context(self.catalog.ids(), 5))
        hooks = {}
        for file, source in sources.items():
            # Ті самі початкові значення змінних, що дає load_students.
            hooks.update(compile_task(file, source, recorder.functions(), recorder.loop_stuck,
                                      defaults=hook_defaults(infos[file])))
        for name, args in calls:
            recorder.log.append("call|" + name)
            if name == "show_fact":
                args = (self.catalog.get(args[0]),)
            if name in hooks:
                hooks[name](*args)
        return recorder.log

    def cpp_log(self, sources, calls):
        infos, problems = analyze_all(sources, Context(self.catalog.ids(), 5))
        self.assertFalse([p for p in problems if p.is_error], [str(p) for p in problems])
        header = generate_header(default_settings(), infos)
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / "student_code.h").write_text(header, encoding="utf-8")
            (folder / "driver.cpp").write_text(driver_source(calls, self.catalog), encoding="utf-8")
            binary = folder / "run"
            build = subprocess.run(
                [COMPILER, "-std=c++11", "-Wall", "-Wno-parentheses-equality", "-I", str(HOST), "-I", str(folder), "-I", str(SKETCH),
                 str(folder / "driver.cpp"), str(HOST / "host_api.cpp"), str(SKETCH / "py_ops.cpp"),
                 "-o", str(binary)],
                capture_output=True, text=True,
            )
            self.assertEqual(build.returncode, 0, build.stderr + "\n" + header)
            result = subprocess.run([str(binary)], capture_output=True, timeout=30)
            return result.stdout.decode("utf-8").splitlines()

    def check(self, folder):
        sources, _ = read_task_sources(folder)
        calls = []
        for file in sorted(sources):
            calls.extend(CALLS[file])
        self.assertEqual(self.cpp_log(sources, calls), self.python_log(sources, calls))

    def test_language_corner_cases(self):
        self.check(ROOT / "tests" / "fixtures" / "parity")

    def test_reference_solutions(self):
        self.check(ROOT / "tests" / "fixtures" / "solutions")

    def test_templates(self):
        self.check(ROOT / "students")


WRAP_DRIVER = """#include <iostream>
#include <string>

#include "wrap_words.h"

// Кожен рядок stdin - окремий текст; відповідь - рядки екрана через "|".
int main() {
  std::string text;
  while (std::getline(std::cin, text)) {
    String lines[3];
    uint8_t count = wrapWords(String(text.c_str()), lines, 3, 14);
    std::string out;
    for (uint8_t index = 0; index < count; ++index) {
      if (index > 0) out += "|";
      out += lines[index].c_str();
    }
    std::cout << out << "\\n";
  }
  return 0;
}
"""


def wrap_cases():
    """Тексти для ask(): звичайні, на межі 14 символів і випадкові."""
    import random

    cases = [
        "", " ", "   ", "Where is Tokyo?", "Pyramids?", "a", "abcdefghijklmn",
        "abcdefghijklmno", "abcdefghijklmn abcdefghijklmn abcdefghijklmn",
        "Which country has the most kangaroos?", "  two  spaces  here  ",
        "short abcdefghijklmnopqrstuvwxyz", "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopq",
        "one two three four five six seven eight nine ten", "x" * 60,
        "Where is the Great Pyramid of Giza, Egypt?", "abc " + "y" * 30 + " end",
        "thirteen char fourteen chars", "fourteen chars fourteen chars z",
    ]
    rng = random.Random(12)
    for _ in range(400):
        length = rng.randint(0, 60)
        cases.append("".join(rng.choice("ab  cdefghij") for _ in range(length)))
    for _ in range(100):
        words = [rng.choice(["a", "bb", "ccc", "dddddddddddd", "e" * 14, "f" * 15, "g" * 29])
                 for _ in range(rng.randint(1, 6))]
        cases.append(" ".join(words))
    return cases


@unittest.skipUnless(COMPILER, "немає компілятора c++")
class WrapWordsParityTests(unittest.TestCase):
    def test_board_wraps_questions_like_python(self):
        from globe_core.screen import wrap_words

        cases = wrap_cases()
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / "driver.cpp").write_text(WRAP_DRIVER, encoding="utf-8")
            binary = folder / "wrap"
            build = subprocess.run(
                [COMPILER, "-std=c++11", "-Wall", "-I", str(HOST), "-I", str(SKETCH),
                 str(folder / "driver.cpp"), str(SKETCH / "wrap_words.cpp"), "-o", str(binary)],
                capture_output=True, text=True,
            )
            self.assertEqual(build.returncode, 0, build.stderr)
            result = subprocess.run(
                [str(binary)], input="\n".join(cases) + "\n", capture_output=True, text=True, timeout=30,
            )
        got = result.stdout.split("\n")[: len(cases)]
        for text, line in zip(cases, got):
            self.assertEqual(line, "|".join(wrap_words(text, 14, 3)), repr(text))
        self.assertEqual(len(got), len(cases))


class StudentHooksEnumTests(unittest.TestCase):
    def test_enum_order_matches_hook_list(self):
        import re

        from globe_core.hooks import HOOK_LIST

        text = (SKETCH / "student_hooks.h").read_text(encoding="utf-8")
        body = re.search(r"enum StudentHook[^{]*\{([^}]*)\}", text).group(1)
        names = [part.strip() for part in body.split(",") if part.strip()]
        self.assertEqual(names, ["HOOK_" + hook.name.upper() for hook in HOOK_LIST])


if __name__ == "__main__":
    unittest.main()
