"""Makefile для Mac і globe.bat для Windows передають усе в globe.py."""

import shlex
import shutil
import subprocess
import tempfile
import unittest
import zipfile
from pathlib import Path

from tests import ROOT

ZIP_NAME = "touch-the-globe-students.zip"


def in_git_checkout():
    if not shutil.which("git"):
        return False
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"], cwd=str(ROOT), capture_output=True, text=True
    )
    return result.returncode == 0 and result.stdout.strip() == "true"


@unittest.skipUnless(shutil.which("make"), "немає make")
class MakefileTests(unittest.TestCase):
    def dry_run(self, *goals):
        result = subprocess.run(
            ["make", "-n"] + list(goals), cwd=str(ROOT), capture_output=True, text=True
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        return result.stdout

    def test_press_passes_all_keys(self):
        self.assertIn("globe.py press 1 1 3", self.dry_run("press", "1", "1", "3"))

    def test_press_with_time(self):
        self.assertIn("globe.py press g 3:600 2@100", self.dry_run("press", "g", "3:600", "2@100"))

    def test_test_with_task(self):
        self.assertIn("globe.py test task2", self.dry_run("test", "task2"))

    def test_upload_retries_without_hardware_check(self):
        # Скетч не вліз - make upload сам збирає ще раз без команди check.
        output = self.dry_run("upload", "PORT=/dev/x")
        steps = [
            'if [ -z "/dev/x" ]',
            "globe.py build",
            "arduino-cli compile --profile uno arduino/TouchTheGlobe",
            '--build-property "build.extra_flags=-DENABLE_HARDWARE_CHECK=0"',
            "Скетч завеликий - зібрано БЕЗ команди check",
            "arduino-cli upload --profile uno -p /dev/x arduino/TouchTheGlobe",
        ]
        positions = []
        for step in steps:
            self.assertIn(step, output)
            positions.append(output.index(step))
        self.assertEqual(positions, sorted(positions), output)

    def test_compile_target(self):
        output = self.dry_run("compile")
        self.assertIn("globe.py build", output)
        self.assertIn("arduino-cli compile --profile uno arduino/TouchTheGlobe", output)
        self.assertIn("-DENABLE_HARDWARE_CHECK=0", output)
        self.assertNotIn("arduino-cli upload", output)

    def test_upload_needs_port(self):
        result = subprocess.run(
            ["make", "-s", "upload", "PORT="], cwd=str(ROOT), capture_output=True, text=True
        )
        self.assertNotEqual(result.returncode, 0)


@unittest.skipUnless(shutil.which("make"), "немає make")
class StudentZipMakeTests(unittest.TestCase):
    def test_student_zip_dry_run(self):
        result = subprocess.run(
            ["make", "-n", "student-zip"], cwd=str(ROOT), capture_output=True, text=True
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("git status --porcelain", result.stdout)
        self.assertIn("у zip потрапить лише закомічене", result.stdout)
        self.assertIn(
            "git archive --format=zip --prefix=Touch_The_Globe/ -o {} HEAD".format(ZIP_NAME), result.stdout
        )

    def test_zip_is_not_committed(self):
        self.assertIn(ZIP_NAME, (ROOT / ".gitignore").read_text(encoding="utf-8").splitlines())


@unittest.skipUnless(shutil.which("make") and in_git_checkout(), "немає git або make")
class StudentZipContentTests(unittest.TestCase):
    """Zip для учнів: увесь проєкт, але без розв'язків, ключа й робочих файлів."""

    @classmethod
    def setUpClass(cls):
        # Та сама команда, що в make student-zip, лише zip - у тимчасову папку.
        dry = subprocess.run(["make", "-n", "student-zip"], cwd=str(ROOT), capture_output=True, text=True)
        line = [row for row in dry.stdout.splitlines() if row.strip().startswith("git archive")][0]
        command = shlex.split(line.strip())
        cls._folder = tempfile.TemporaryDirectory()
        target = Path(cls._folder.name) / ZIP_NAME
        command[command.index("-o") + 1] = str(target)
        result = subprocess.run(command, cwd=str(ROOT), capture_output=True, text=True)
        if result.returncode != 0:
            raise AssertionError(result.stderr)
        with zipfile.ZipFile(str(target)) as archive:
            cls.names = set(archive.namelist())

    @classmethod
    def tearDownClass(cls):
        cls._folder.cleanup()

    def test_project_files_are_inside(self):
        for name in ("students/task1.py", "students/task5.py", "settings.py", "Makefile",
                     "globe.bat", "globe.py", ".env.example", "docs/student_guide.md",
                     "docs/teacher_guide.md", "arduino/TouchTheGlobe/TouchTheGlobe.ino"):
            self.assertTrue("Touch_The_Globe/" + name in self.names, name)

    def test_solutions_secrets_and_work_files_are_not(self):
        for name in (".env", "tests/fixtures/solutions/task1.py"):
            self.assertFalse("Touch_The_Globe/" + name in self.names, name)
        for prefix in ("Touch_The_Globe/tests/fixtures/solutions/", "Touch_The_Globe/docs/superpowers/",
                       "Touch_The_Globe/.superpowers/", "Touch_The_Globe/sd_card/"):
            self.assertFalse([name for name in self.names if name.startswith(prefix)], prefix)
        self.assertFalse([name for name in self.names if "__pycache__" in name])


class GlobeBatTests(unittest.TestCase):
    def setUp(self):
        self.raw = (ROOT / "globe.bat").read_bytes()

    def test_crlf_line_endings(self):
        self.assertIn(b"\r\n", self.raw)
        self.assertEqual(self.raw.count(b"\n"), self.raw.count(b"\r\n"))

    def test_utf8_and_python_search(self):
        text = self.raw.decode("utf-8")
        self.assertIn("chcp 65001", text)
        self.assertIn("py -3", text)
        self.assertIn("globe.py %*", text)

    def test_gitattributes_keeps_crlf(self):
        self.assertIn("*.bat text eol=crlf", (ROOT / ".gitattributes").read_text(encoding="utf-8"))


if __name__ == "__main__":
    unittest.main()
