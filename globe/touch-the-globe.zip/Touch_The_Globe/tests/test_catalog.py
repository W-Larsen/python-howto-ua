"""Тести читання файлів країн."""

import unittest

from globe_core.catalog import ContentError, parse_country_file
from tests.helpers import TempContentCase, country_text


class ParseTests(unittest.TestCase):
    def test_reads_header_and_text(self):
        fields, texts = parse_country_file("UA", country_text(name="Україна"))
        self.assertEqual(fields["name"], "Україна")
        self.assertEqual(fields["lcd_capital"], "Testburg")
        self.assertEqual(texts[0], "Тут живуть тести.")

    def test_keys_are_case_insensitive(self):
        fields, _ = parse_country_file("UA", "NAME: Україна\n---\nтекст\n")
        self.assertEqual(fields["name"], "Україна")

    def test_comments_and_blank_lines_are_ignored(self):
        raw = "# це коментар\n\nname: Україна\n---\nтекст\n"
        fields, _ = parse_country_file("UA", raw)
        self.assertEqual(fields["name"], "Україна")

    def test_windows_line_endings(self):
        fields, texts = parse_country_file("UA", "name: Україна\r\n---\r\nтекст\r\n")
        self.assertEqual(fields["name"], "Україна")
        self.assertEqual(texts[0], "текст")

    def test_extra_sections_become_modes(self):
        raw = "name: Україна\n---\nфакт\n---\nісторія\n"
        _, texts = parse_country_file("UA", raw)
        self.assertEqual(texts, ["факт", "історія"])

    def test_text_keeps_several_lines(self):
        raw = "name: Україна\n---\nперший рядок\nдругий рядок\n"
        _, texts = parse_country_file("UA", raw)
        self.assertEqual(texts[0], "перший рядок\nдругий рядок")

    # -- помилки, які має побачити учень -------------------------------
    def test_missing_separator_is_explained(self):
        with self.assertRaises(ContentError) as caught:
            parse_country_file("UA", "name: Україна\nтекст без розділювача\n")
        self.assertIn("---", str(caught.exception))

    def test_missing_name_is_explained(self):
        with self.assertRaises(ContentError) as caught:
            parse_country_file("UA", "capital: Київ\n---\nтекст\n")
        self.assertIn("name", str(caught.exception))

    def test_empty_text_is_explained(self):
        with self.assertRaises(ContentError) as caught:
            parse_country_file("UA", "name: Україна\n---\n\n")
        self.assertIn("немає тексту", str(caught.exception))

    def test_broken_header_line_reports_line_number(self):
        raw = "name: Україна\nце зовсім не пара ключ значення\n---\nтекст\n"
        with self.assertRaises(ContentError) as caught:
            parse_country_file("UA", raw)
        self.assertIn("рядок 2", str(caught.exception))

    def test_track_must_be_a_number(self):
        raw = "name: Україна\ntrack: перший\n---\nтекст\n"
        with self.assertRaises(ContentError) as caught:
            parse_country_file("UA", raw)
        self.assertIn("числом", str(caught.exception))


class FallbackTests(TempContentCase):
    def test_lcd_capital_falls_back_to_lcd_name(self):
        self.write_country("XX", raw="name: Ікс\nlcd_name: Iks\n---\nтекст\n")
        country = self.load().get("XX")
        self.assertEqual(country.lcd_capital, "Iks")

    def test_lcd_name_falls_back_to_id(self):
        self.write_country("XX", raw="name: Ікс\n---\nтекст\n")
        country = self.load().get("XX")
        self.assertEqual(country.lcd_name, "XX")

    def test_text_for_unknown_mode_returns_main_text(self):
        self.write_country("XX", text="основний факт")
        country = self.load().get("XX")
        self.assertEqual(country.text_for_mode("story"), "основний факт")
        self.assertEqual(country.text_for_mode("немаєтакого"), "основний факт")


    def test_bom_from_windows_notepad_is_accepted(self):
        path = self.countries_dir / "UA.txt"
        path.write_bytes(b"\xef\xbb\xbf" + country_text(name="Україна").encode("utf-8"))
        catalog = self.load()
        self.assertEqual(catalog.get("UA").name, "Україна")

    def test_utf16_country_file_gives_a_friendly_error(self):
        path = self.countries_dir / "UA.txt"
        path.write_bytes(country_text(name="Україна").encode("utf-16"))
        with self.assertRaises(ContentError) as caught:
            self.load()
        self.assertIn("UTF-8", str(caught.exception))
        self.assertIn("UA", str(caught.exception))

    def test_invalid_byte_in_country_file_gives_a_friendly_error(self):
        path = self.countries_dir / "UA.txt"
        path.write_bytes(b"name: \xff\xfe\n---\ntext\n")
        with self.assertRaises(ContentError) as caught:
            self.load()
        self.assertIn("UTF-8", str(caught.exception))


class DiscoveryTests(TempContentCase):
    def test_finds_all_files_and_sorts_them(self):
        for country_id in ("UA", "JP", "BR"):
            self.write_country(country_id)
        catalog = self.load()
        self.assertEqual(len(catalog), 3)
        self.assertEqual(catalog.ids(), ["BR", "JP", "UA"])

    def test_service_files_are_skipped(self):
        self.write_country("UA")
        self.write_country("_TEMPLATE")
        (self.countries_dir / "notes.md").write_text("нотатки", encoding="utf-8")
        self.assertEqual(self.load().ids(), ["UA"])

    def test_lookup_ignores_case(self):
        self.write_country("UA")
        catalog = self.load()
        self.assertIsNotNone(catalog.get("ua"))
        self.assertTrue(catalog.has("Ua"))

    def test_missing_country_lists_available_ones(self):
        self.write_country("UA")
        with self.assertRaises(ContentError) as caught:
            self.load().require("ZZ")
        self.assertIn("UA", str(caught.exception))

    def test_missing_directory_is_explained(self):
        from globe_core.catalog import load_catalog

        with self.assertRaises(ContentError) as caught:
            load_catalog(str(self.countries_dir / "немає"))
        self.assertIn("Немає папки", str(caught.exception))


class TrackTests(TempContentCase):
    def test_tracks_follow_alphabet(self):
        for country_id in ("UA", "AU", "JP"):
            self.write_country(country_id)
        catalog = self.load()
        self.assertEqual(
            [(c.id, c.track) for c in catalog], [("AU", 1), ("JP", 2), ("UA", 3)]
        )

    def test_manual_track_is_respected(self):
        self.write_country("AU")
        self.write_country("UA", raw="name: Україна\ntrack: 1\n---\nтекст\n")
        catalog = self.load()
        self.assertEqual(catalog.get("UA").track, 1)
        # AU у алфавіті перша, але місце 1 вже зайняте
        self.assertEqual(catalog.get("AU").track, 2)

    def test_duplicate_manual_tracks_are_rejected(self):
        self.write_country("AU", raw="name: А\ntrack: 2\n---\nтекст\n")
        self.write_country("UA", raw="name: У\ntrack: 2\n---\nтекст\n")
        with self.assertRaises(ContentError) as caught:
            self.load()
        self.assertIn("однаковий track", str(caught.exception))

    def test_by_track_finds_country(self):
        self.write_country("UA")
        self.assertEqual(self.load().by_track(1).id, "UA")


class RealContentTests(unittest.TestCase):
    """Перевіряє справжній контент проєкту, а не тимчасовий."""

    def setUp(self):
        from globe_core.catalog import LCD_WIDTH, load_catalog
        from tests import ROOT

        self.LCD_WIDTH = LCD_WIDTH
        self.catalog = load_catalog(str(ROOT / "content" / "countries"))

    def test_only_ukraine_is_shipped_as_an_example(self):
        # Решту країн (текст і аудіо) додає вчитель на сайті.
        self.assertEqual(self.catalog.ids(), ["UA"])

    def test_demo_fixture_countries_load(self):
        from globe_core.catalog import load_catalog
        from tests import DEMO_COUNTRIES

        demo = load_catalog(str(DEMO_COUNTRIES))
        self.assertEqual(sorted(demo.ids()), ["AU", "BR", "EG", "JP", "UA", "US"])

    def test_lcd_fields_fit_the_display(self):
        for country in self.catalog:
            for field in ("lcd_name", "lcd_capital"):
                value = getattr(country, field)
                self.assertTrue(
                    value.isascii(),
                    "{}.{} має бути латиницею: {}".format(country.id, field, value),
                )
                self.assertLessEqual(
                    len(value),
                    self.LCD_WIDTH,
                    "{}.{} задовге: {}".format(country.id, field, value),
                )

    def test_tracks_are_unique(self):
        tracks = [country.track for country in self.catalog]
        self.assertEqual(len(tracks), len(set(tracks)))


if __name__ == "__main__":
    unittest.main()
