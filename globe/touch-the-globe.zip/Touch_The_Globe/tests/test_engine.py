"""Тести ядра: API для учнів, запуск, звичайний режим."""

import random
import unittest

from globe_core.engine import FINISHED, NORMAL, GlobeEngine
from globe_core.fakes import (
    DictAudioSource,
    FakeClock,
    FakeSleep,
    RecordingDisplay,
    RecordingSpeaker,
)
from globe_core.settings import default_settings
from tests.helpers import TempContentCase


class EngineCase(TempContentCase):
    def setUp(self):
        TempContentCase.setUp(self)
        self.write_country("UA", name="Україна", lcd_name="Ukraine", lcd_capital="Kyiv")
        self.write_country("JP", name="Японія", lcd_name="Japan", lcd_capital="Tokyo")
        self.clock = FakeClock()
        self.sleep = FakeSleep(self.clock)
        self.display = RecordingDisplay()
        self.speaker = RecordingSpeaker()
        self.warnings = []
        self.notes = []
        self.engine = GlobeEngine(
            self.load(),
            default_settings(),
            display=self.display,
            speaker=self.speaker,
            audio_source=DictAudioSource({"UA": "ua.mp3", "JP": "jp.mp3"}),
            clock=self.clock,
            sleep=self.sleep,
            rng=random.Random(1),
            on_warning=self.warnings.append,
            on_note=self.notes.append,
        )
        self.api = self.engine.api()

    def on_button_ua_jp(self):
        api = self.api

        def on_button(number):
            if number == 1:
                api["play_sound"]("UA")
                api["show_country"]("UA")
            elif number == 2:
                api["play_sound"]("JP")
                api["show_country"]("JP")

        return on_button

    def screen(self):
        return self.engine.screen.snapshot()


class ApiTableTests(EngineCase):
    def test_api_has_every_function_from_the_table(self):
        from globe_core.hooks import API

        self.assertEqual(sorted(self.api), sorted(API))


class BootTests(EngineCase):
    def test_loading_then_hello_screen(self):
        calls = []
        self.engine.set_hooks(
            {
                "loading": lambda: calls.append("loading"),
                "hello_screen": lambda: calls.append("hello"),
                "on_button": lambda number: None,
            }
        )
        self.engine.boot()
        self.assertEqual(calls, ["loading", "hello"])
        self.assertEqual(self.warnings, [])

    def test_default_screen_without_hello(self):
        self.engine.set_hooks({"on_button": lambda number: None})
        self.engine.boot()
        self.assertEqual(self.screen()[0], "TouchTheGlobe")
        self.assertEqual(self.display.last, self.screen())

    def test_warns_without_task1(self):
        self.engine.boot()
        self.assertTrue(any("task1.py" in warning for warning in self.warnings))


class NormalModeTests(EngineCase):
    def setUp(self):
        EngineCase.setUp(self)
        self.engine.set_hooks({"on_button": self.on_button_ua_jp()})

    def test_button_shows_country_and_plays_sound(self):
        self.engine.touch_button(1)
        self.assertEqual(self.screen(), ("Ukraine", "Kyiv", "", "", "", "x1"))
        self.assertTrue(self.engine.screen.inverted[0])
        self.assertEqual(self.speaker.played, ["ua.mp3"])
        self.assertEqual(self.display.last, self.screen())
        self.assertEqual(self.engine.mode, NORMAL)

    def test_press_count_grows_per_country(self):
        self.engine.touch_button(1)
        self.engine.touch_button(2)
        self.engine.touch_button(1)
        self.assertEqual(self.screen()[5], "x2")
        self.assertEqual(self.engine.press_count("ua"), 2)
        self.assertEqual(self.engine.press_count("JP"), 1)

    def test_show_fact_runs_after_the_country_screen(self):
        seen = []

        def show_fact(country):
            seen.append((country.id, self.engine.screen.snapshot()[0]))
            self.api["show_text"](2, "Borscht!")

        self.engine.set_hooks({"on_button": self.on_button_ua_jp(), "show_fact": show_fact})
        self.engine.touch_button(1)
        self.assertEqual(seen, [("UA", "Ukraine")])
        self.assertEqual(self.screen()[2], "Borscht!")

    def test_show_country_inside_show_fact_does_not_recurse(self):
        # Аналізатор такого не пропустить, але й ядро не має зациклитися.
        seen = []

        def show_fact(country):
            seen.append(country.id)
            self.api["show_country"]("JP")

        self.engine.set_hooks({"on_button": self.on_button_ua_jp(), "show_fact": show_fact})
        self.engine.touch_button(1)
        self.assertEqual(seen, ["UA"])
        self.assertEqual(self.warnings, [])
        self.assertEqual(self.screen()[0], "Japan")
        # Наступне торкання - знову з фактом.
        self.engine.touch_button(2)
        self.assertEqual(seen, ["UA", "JP"])

    def test_button_out_of_range_warns(self):
        self.engine.touch_button(9)
        self.assertTrue(any("кнопки 9" in warning for warning in self.warnings))

    def test_finished_mode_returns_to_normal(self):
        self.engine.mode = FINISHED
        self.engine.touch_button(1)
        self.assertEqual(self.engine.mode, NORMAL)
        self.assertEqual(self.screen()[0], "Ukraine")

    def test_missing_on_button_warns_once(self):
        self.engine.set_hooks({})
        self.engine.touch_button(1)
        self.engine.touch_button(1)
        self.assertEqual(len([w for w in self.warnings if "task1.py" in w]), 1)


class ApiFunctionTests(EngineCase):
    def test_unknown_country_warns(self):
        self.api["show_country"]("XX")
        self.api["play_sound"]("XX")
        self.assertTrue(self.warnings)
        self.assertIn("UA", self.warnings[0])
        self.assertEqual(self.speaker.played, [])

    def test_show_text_clips_and_warns(self):
        self.api["show_text"](3, "a" * 20)
        self.assertEqual(self.screen()[3], "a" * 14)
        self.assertTrue(any("14" in warning for warning in self.warnings))

    def test_show_text_cyrillic_from_variable(self):
        self.api["show_text"](3, "Київ")
        self.assertEqual(self.screen()[3], "?" * 8)
        self.assertTrue(any("українські" in warning for warning in self.warnings))

    def test_show_text_bad_row(self):
        self.api["show_text"](7, "a")
        self.assertTrue(any("від 0 до 5" in warning for warning in self.warnings))

    def test_wait_refreshes_then_sleeps(self):
        self.api["show_text"](2, "=")
        self.api["wait"](150)
        self.assertEqual(self.display.last[2], "=")
        self.assertEqual(self.sleep.calls, [0.15])

    def test_negative_wait_is_ignored(self):
        self.api["wait"](-5)
        self.assertEqual(self.sleep.calls, [])

    def test_blink(self):
        self.api["blink"](3)
        self.assertEqual(self.display.blinks, [3])
        self.assertEqual(len(self.sleep.calls), 1)

    def test_clear_screen(self):
        self.api["show_text"](2, "a")
        self.api["clear_screen"]()
        self.assertEqual(self.screen(), ("",) * 6)

    def test_random_number_bounds(self):
        for _ in range(50):
            value = self.api["random_number"](1, 5)
            self.assertTrue(1 <= value <= 5)
        self.assertEqual(self.api["random_number"](5, 1), 5)

    def test_target_and_ask_outside_games_warn(self):
        self.api["target"]("JP", "Tokyo!")
        self.api["ask"]("Where?", "JP")
        self.assertEqual(len(self.warnings), 2)

    def test_crashing_hook_names_the_file(self):
        def on_button(number):
            raise ZeroDivisionError("division by zero")

        self.engine.set_hooks({"on_button": on_button})
        self.engine.touch_button(1)
        self.assertTrue(any("task1.py" in w and "ділення на нуль" in w for w in self.warnings), self.warnings)
        self.assertFalse(any("ZeroDivisionError" in w for w in self.warnings), self.warnings)

    def crash_message(self, exc):
        def on_button(number):
            raise exc

        self.engine.set_hooks({"on_button": on_button})
        self.engine.touch_button(1)
        self.assertEqual(len(self.warnings), 1, self.warnings)
        self.assertIn("on_button() з task1.py зупинилася з помилкою", self.warnings[0])
        return self.warnings[0]

    def test_crash_messages_are_ukrainian(self):
        self.assertIn("занадто глибокий виклик", self.crash_message(RecursionError("maximum recursion depth")))

    def test_missing_value_message(self):
        message = self.crash_message(UnboundLocalError("local variable 'x' referenced before assignment"))
        self.assertIn("не вистачає значення", message)
        self.assertNotIn("referenced", message)

    def test_unknown_crash_keeps_the_python_message(self):
        self.assertIn("RuntimeError: boom", self.crash_message(RuntimeError("boom")))

    def test_crash_names_the_line_of_the_student_code(self):
        from globe_core.student_loader import compile_task

        hooks = compile_task(
            "task1.py",
            "def on_button(number):\n    zero = 0\n    x = 5 // zero\n",
            self.api,
            self.engine.loop_stuck,
        )
        self.engine.set_hooks(hooks)
        self.engine.touch_button(1)
        self.assertTrue(any("зупинилася з помилкою в рядку 3: ділення на нуль" in w for w in self.warnings), self.warnings)

    def test_loop_stuck_message(self):
        self.engine.loop_stuck("task2.py", 5)
        self.assertIn("task2.py, рядок 5", self.warnings[0])
        self.assertIn("while", self.warnings[0])

    def test_broken_speaker_does_not_stop_the_screen(self):
        class BrokenSpeaker:
            def play(self, ref):
                raise RuntimeError("no sound card")

        self.engine.speaker = BrokenSpeaker()
        self.engine.set_hooks({"on_button": self.on_button_ua_jp()})
        self.engine.touch_button(1)
        self.assertEqual(self.screen()[0], "Ukraine")
        self.assertTrue(self.warnings)

    def test_broken_display_blink_does_not_stop_the_student_code(self):
        class BrokenBlinkDisplay(RecordingDisplay):
            def blink(self, times):
                raise RuntimeError("no backlight")

        self.engine.display = BrokenBlinkDisplay()
        self.api["blink"](2)
        self.assertTrue(any("помигати" in warning for warning in self.warnings))
        self.assertEqual(len(self.sleep.calls), 1)

    def test_failing_warning_callback_does_not_propagate(self):
        def broken(message):
            raise RuntimeError("log is closed")

        self.engine._on_warning = broken
        self.engine.warn("щось сталося")


if __name__ == "__main__":
    unittest.main()
