"""Перевірка паритету: ці гілки мають давати однаковий результат у Python і C++."""


def on_button(number):
    if number == 1:
        a = -7
        print(a // 2, a % 2, 7 // -2, 7 % -2)
    elif number == 2:
        text = "Score " + str(-15)
        ok = number == 2
        print(text, ok, str(ok), not ok)
        print("quote \" back \\ q??")
    elif number == 3:
        total = 0
        for i in range(10, 0, -3):
            total += i
        print(total, i)
    elif number == 4:
        count = 0
        for i in range(5):
            if i == 1:
                continue
            for j in range(5):
                if j > i:
                    break
                count += 1
        print(count)
    elif number == 5:
        steps = 0
        while True:
            steps += 1
        print(steps)
    elif number == 6:
        if number > 3 and number < 10 or number == 0:
            label = "middle"
        else:
            label = "edge"
        print(label)
    elif number == 7:
        limit = 3
        for i in range(limit):
            limit += 1
        print(limit)
    elif number == 9:
        b = -2
        print(-7 // b, -7 % b, -8 // 2, -8 % 2)
        print(0 // -3, 0 % -3, 7 // 2, 7 % 2)
        print(-8 // -2, -8 % -2, -1 // -3, -1 % -3)
    elif number == 10:
        # Змінні, яким значення дають лише в деяких гілках, і змінна циклу
        # після порожнього range: на платі вони 0 / "" / False з початку функції.
        if number > 50:
            label = "never"
            flag = True
        for k in range(0):
            steps = 7
        print("[" + label + "]", flag, k, steps)
        show_text(4, label)
    else:
        word = ""
        for i in range(20):
            word += "ab"
        show_text(3, word)
        print("Привіт", random_number(1, 6), random_number(1, 6))


def hello_screen():
    show_text(0, "Hi")
