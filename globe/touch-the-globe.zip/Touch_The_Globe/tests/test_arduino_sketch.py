"""Тести скетча для Arduino Uno - без самої плати.

Скетч перевірити складніше, ніж Python: помилка в ньому виявляється аж
тоді, коли зібраний глобус мовчить. Тому тут ми читаємо його файли як
текст і ловимо те, що найчастіше ламається: два пристрої на одному піні,
сенсор на зайнятому піні, забутий make build або build_arduino_data.py.

Справжня компіляція (повільна) - лише з GLOBE_COMPILE=1 (make selftest).
"""

import os
import re
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from globe_core.catalog import load_catalog
from globe_core.pins import PinError, to_pin
from globe_core.settings import MAX_BUTTONS, load_settings
from tests import ROOT
from tools.build_arduino_data import render_header
from tools.build_student_code import render

SKETCH_DIR = ROOT / "arduino" / "TouchTheGlobe"

# const char* const LCD_RST = "D2";
PIN_LINE = re.compile(r'const char\* const (\w+)\s*=\s*"([^"]*)"')

# #include "globe_engine.h"
INCLUDE_LINE = re.compile(r'#include "([^"]+)"')


def read(name):
    return (SKETCH_DIR / name).read_text(encoding="utf-8")


def hardware_pins():
    """Піни із hardware_pins.h у вигляді {назва: "D2"} (порожні пропущено)."""
    return {name: label for name, label in PIN_LINE.findall(read("hardware_pins.h")) if label}


class SketchFilesTests(unittest.TestCase):
    def test_sketch_folder_matches_the_main_file(self):
        self.assertTrue((SKETCH_DIR / "TouchTheGlobe.ino").is_file())

    def test_every_include_exists(self):
        for path in SKETCH_DIR.glob("*"):
            if path.suffix not in (".ino", ".h", ".cpp"):
                continue
            for name in INCLUDE_LINE.findall(path.read_text(encoding="utf-8")):
                self.assertTrue(
                    (SKETCH_DIR / name).is_file(),
                    "{} підключає {}, якого немає".format(path.name, name),
                )

    def test_student_code_is_included_only_by_the_sketch(self):
        for path in SKETCH_DIR.glob("*"):
            if path.suffix in (".h", ".cpp") and path.name != "student_code.h":
                self.assertNotIn('#include "student_code.h"', path.read_text(encoding="utf-8"), path.name)


def function_body(source, signature):
    """Текст між фігурними дужками функції (з урахуванням вкладених)."""
    start = source.index(signature)
    opening = source.index("{", start)
    depth = 0
    for position in range(opening, len(source)):
        if source[position] == "{":
            depth += 1
        elif source[position] == "}":
            depth -= 1
            if depth == 0:
                return source[opening + 1:position]
    raise AssertionError("не знайшов кінця функції " + signature)


class RandomSeedTests(unittest.TestCase):
    """Щоб «Блискавка» не загадувала те саме після кожного ввімкнення."""

    def setUp(self):
        self.sketch = read("TouchTheGlobe.ino")

    def test_noise_is_not_read_from_a_fixed_pin(self):
        # Будь-який A0-A5 може бути сенсором (settings.py), а сенсор TTP223
        # тримає лінію - з нього завжди читається те саме число.
        self.assertIsNone(re.search(r"analogRead\(\s*A\d\s*\)", self.sketch))

    def test_seed_is_set_at_start_and_again_on_first_touch(self):
        self.assertIn("randomSeed(", function_body(self.sketch, "void setup()"))
        self.assertIn("randomSeed(", function_body(self.sketch, "void loop()"))


class EngineGuardsTests(unittest.TestCase):
    """Ті самі запобіжники, що й у globe_core/engine.py (без плати - читаємо текст)."""

    def setUp(self):
        self.header = read("globe_engine.h")
        self.engine = read("globe_engine.cpp")

    def test_show_fact_is_not_reentered(self):
        # show_country() усередині show_fact() інакше викликала б її знову й знову.
        self.assertRegex(self.header, r"bool\s+_inFact\s*;")
        body = function_body(self.engine, "void GlobeEngine::showCountry(")
        guard = body.index("_inFact")
        call = body.index("student_show_fact(")
        self.assertLess(guard, call)
        self.assertRegex(body, r"if\s*\(\s*_inFact\s*\)")
        self.assertRegex(body[call:], r"_inFact\s*=\s*false")

    def test_reading_an_answer_does_not_draw_or_wait(self):
        self.assertRegex(self.header, r"bool\s+_reading\s*;")
        touch = function_body(self.engine, "void GlobeEngine::touchButton(")
        game_part = touch[touch.index("_answer = -1"):]
        self.assertRegex(game_part, r"_reading\s*=\s*true;\s*student_on_button\(number\);\s*_reading\s*=\s*false;")
        for signature in ("void GlobeEngine::showText(", "void GlobeEngine::clearScreen(",
                          "void GlobeEngine::blink(", "void GlobeEngine::wait("):
            body = function_body(self.engine, signature)
            self.assertRegex(body.lstrip(), r"^if\s*\(\s*_reading", signature)


class HardwareCheckSwitchTests(unittest.TestCase):
    def test_switch_can_be_set_from_the_command_line(self):
        # make upload передає -DENABLE_HARDWARE_CHECK=0, коли скетч не влазить:
        # без #ifndef hardware_pins.h перебив би це значення своєю 1.
        self.assertRegex(
            read("hardware_pins.h"),
            r"#ifndef ENABLE_HARDWARE_CHECK\s*\n\s*#define ENABLE_HARDWARE_CHECK 1\s*\n\s*#endif",
        )


class HardwarePinsTests(unittest.TestCase):
    def setUp(self):
        self.pins = hardware_pins()
        self.settings, _ = load_settings(ROOT / "settings.py")

    def number(self, name, label):
        try:
            return to_pin(label)
        except PinError as exc:
            self.fail("{} = {}: {}".format(name, label, exc))

    def test_pins_are_found(self):
        for name in ("LCD_RST", "LCD_CE", "LCD_DC", "LCD_DIN", "LCD_CLK", "DFPLAYER_TX", "DFPLAYER_RX"):
            self.assertIn(name, self.pins)

    def test_hardware_does_not_share_pins(self):
        used = {}
        for name, label in self.pins.items():
            number = self.number(name, label)
            self.assertNotIn(number, used, "{} і {} - той самий пін {}".format(used.get(number), name, label))
            used[number] = name

    def test_settings_pins_do_not_clash_with_hardware(self):
        taken = {self.number(name, label): name for name, label in self.pins.items()}
        sensors = self.settings.button_pins + [self.settings.quiz_pin, self.settings.game_pin]
        for pin in sensors:
            self.assertNotIn(self.number("сенсор", pin), taken, "сенсор {} займає пін {}".format(pin, taken.get(to_pin(pin))))

    def test_sensors_fit_into_the_panel(self):
        limit = int(re.search(r"MAX_BUTTONS\s*=\s*(\d+)", read("buttons.h")).group(1))
        self.assertEqual(limit, MAX_BUTTONS + 2)
        self.assertLessEqual(self.settings.button_count + 2, limit)


class GeneratedFilesTests(unittest.TestCase):
    def test_countries_header_matches_the_country_files(self):
        catalog = load_catalog(str(ROOT / "content" / "countries"))
        self.assertEqual(
            read("countries.h"), render_header(catalog),
            "countries.h застарів: запусти python3 tools/build_arduino_data.py",
        )

    def test_student_code_matches_students_folder(self):
        header, problems = render(ROOT)
        self.assertIsNotNone(header, [str(p) for p in problems])
        self.assertEqual(read("student_code.h"), header, "student_code.h застарів: запусти make build")

    def test_generated_files_are_marked(self):
        self.assertIn("ЗГЕНЕРОВАНО автоматично", read("countries.h"))
        self.assertIn("ЗГЕНЕРОВАНО автоматично", read("student_code.h"))


SIZE_LINE = re.compile(r"leaving (\d+) bytes for local variables")
FLASH_LINE = re.compile(r"Sketch uses (\d+) bytes")
# Так само збирає make upload, коли скетч не влазить у флеш.
NO_CHECK = ["--build-property", "build.extra_flags=-DENABLE_HARDWARE_CHECK=0"]


@unittest.skipUnless(
    os.environ.get("GLOBE_COMPILE") == "1" and shutil.which("arduino-cli"),
    "справжня компіляція: GLOBE_COMPILE=1 (make selftest) і arduino-cli",
)
class CompileTests(unittest.TestCase):
    def compile(self, sketch_dir, extra=()):
        result = subprocess.run(
            ["arduino-cli", "compile", "--profile", "uno"] + list(extra) + [str(sketch_dir)],
            capture_output=True, text=True, timeout=900,
        )
        self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
        print("\n" + "\n".join(line for line in result.stdout.splitlines() if "bytes" in line))
        return result.stdout

    def test_shipped_sketch_compiles(self):
        self.compile(SKETCH_DIR)

    def solutions_sketch(self, folder):
        header, problems = render(ROOT, ROOT / "tests" / "fixtures" / "solutions")
        self.assertIsNotNone(header, [str(p) for p in problems])
        sketch = Path(folder) / "TouchTheGlobe"
        shutil.copytree(str(SKETCH_DIR), str(sketch), ignore=shutil.ignore_patterns("build"))
        (sketch / "student_code.h").write_text(header, encoding="utf-8")
        return sketch

    def test_sketch_with_all_reference_solutions_fits(self):
        """Повний код п'яти учнів має влазити в Uno і лишати пам'ять на роботу."""
        with tempfile.TemporaryDirectory() as folder:
            output = self.compile(self.solutions_sketch(folder))
        free = int(SIZE_LINE.search(output).group(1))
        self.assertGreaterEqual(free, 400, "лишається {} байтів RAM - замало для String".format(free))

    def test_build_without_hardware_check_is_smaller(self):
        """Те, що робить make upload, коли скетч не влазить: -DENABLE_HARDWARE_CHECK=0."""
        with tempfile.TemporaryDirectory() as folder:
            sketch = self.solutions_sketch(folder)
            full = int(FLASH_LINE.search(self.compile(sketch)).group(1))
            lean = int(FLASH_LINE.search(self.compile(sketch, NO_CHECK)).group(1))
        self.assertLess(lean, full - 3000, "без команди check скетч мав стати меншим на кілька КБ")


if __name__ == "__main__":
    unittest.main()
