"""Консоль малює екран тієї самої ширини, що й справжній."""

import io
import unittest

from globe_core.screen import Screen
from pc.console_display import ConsoleDisplay, render_screen


class RenderTests(unittest.TestCase):
    def test_frame_has_eight_lines(self):
        screen = Screen()
        screen.write(0, "Ukraine", inverted=True)
        screen.write(1, "Kyiv")
        lines = render_screen(screen)
        self.assertEqual(len(lines), 8)
        self.assertEqual(lines[0], "┌" + "─" * 14 + "┐")
        self.assertEqual(lines[1], "┃Ukraine       ┃")
        self.assertEqual(lines[2], "│Kyiv          │")
        self.assertEqual(lines[7], "└" + "─" * 14 + "┘")


class ConsoleDisplayTests(unittest.TestCase):
    def setUp(self):
        self.stream = io.StringIO()
        self.screen = Screen()

    def test_refresh_prints_frame(self):
        display = ConsoleDisplay(stream=self.stream)
        self.screen.write(2, "Hello")
        display.refresh(self.screen)
        self.assertIn("│Hello         │", self.stream.getvalue())

    def test_same_frame_is_not_printed_twice(self):
        display = ConsoleDisplay(stream=self.stream)
        display.refresh(self.screen)
        display.refresh(self.screen)
        self.assertEqual(self.stream.getvalue().count("┌"), 1)

    def test_animation_redraws_in_place(self):
        display = ConsoleDisplay(stream=self.stream, animate=True)
        display.refresh(self.screen)
        self.screen.write(2, "=")
        display.refresh(self.screen)
        self.assertIn("\x1b[8F", self.stream.getvalue())

    def test_note_breaks_redraw(self):
        display = ConsoleDisplay(stream=self.stream, animate=True)
        display.refresh(self.screen)
        display.note("(загадано: JP)")
        self.screen.write(2, "=")
        display.refresh(self.screen)
        self.assertNotIn("\x1b[8F", self.stream.getvalue())
        self.assertIn("(загадано: JP)", self.stream.getvalue())

    def test_blink_is_shown(self):
        display = ConsoleDisplay(stream=self.stream)
        display.blink(3)
        self.assertIn("підсвітка", self.stream.getvalue())
        self.assertIn("3", self.stream.getvalue())

    def test_same_frame_after_a_note_is_printed_again(self):
        """Між кадрами CLI друкує нотатки: однаковий кадр після них не губиться."""
        display = ConsoleDisplay(stream=self.stream)
        display.refresh(self.screen)
        display.note("> натискаю 1")
        display.refresh(self.screen)
        self.assertEqual(self.stream.getvalue().count("┌"), 2)

    def test_same_frame_after_a_blink_is_printed_again(self):
        display = ConsoleDisplay(stream=self.stream)
        display.refresh(self.screen)
        display.blink(2)
        display.refresh(self.screen)
        self.assertEqual(self.stream.getvalue().count("┌"), 2)

    def test_same_frame_after_an_interrupt_is_printed_again(self):
        display = ConsoleDisplay(stream=self.stream)
        display.refresh(self.screen)
        display.interrupt()
        display.refresh(self.screen)
        self.assertEqual(self.stream.getvalue().count("┌"), 2)


if __name__ == "__main__":
    unittest.main()
