"""Перевірка мови учнів: що можна, чого не можна і що ми кажемо учню."""

import tempfile
import textwrap
import unittest
from pathlib import Path

from globe_core.hooks import BOOL, INT, STR
from globe_core.language import Context, analyze_task, read_task_sources
from globe_core.problems import has_errors

CONTEXT = Context(country_ids=["UA", "JP", "BR", "EG", "AU", "US"], button_count=5)


def check(source, file="task1.py", context=CONTEXT):
    info, problems = analyze_task(file, textwrap.dedent(source), context)
    return info, problems


def text(problems):
    return "\n".join(str(problem) for problem in problems)


class AcceptedCodeTests(unittest.TestCase):
    def test_card_example_task1(self):
        info, problems = check(
            '''
            """Опис задачі."""

            def on_button(number):
                if number == 1:
                    play_sound("UA")
                    show_country("UA")
                elif number == 2:
                    pass


            def hello_screen():
                show_text(0, "Touch")
            '''
        )
        self.assertEqual(problems, [], text(problems))
        self.assertEqual(sorted(info.functions), ["hello_screen", "on_button"])

    def test_variable_types_are_inferred(self):
        info, problems = check(
            """
            def on_hit(correct, ms):
                label = "ms: " + str(ms)
                fast = ms < 1000
                total = ms // 2 + 1
                show_text(3, label)
            """,
            file="task2.py",
        )
        self.assertEqual(problems, [], text(problems))
        variables = info.functions["on_hit"].variables
        self.assertEqual(variables, {"label": STR, "fast": BOOL, "total": INT})

    def test_params_take_types_from_the_hook_table(self):
        info, _ = check("def on_hit(ok, time):\n    pass\n", file="task2.py")
        self.assertEqual(info.functions["on_hit"].params, [("ok", BOOL), ("time", INT)])

    def test_for_while_break_continue(self):
        _, problems = check(
            """
            def loading():
                bar = ""
                for i in range(14):
                    if i == 3:
                        continue
                    bar = bar + "="
                    show_text(2, bar)
                n = 0
                while n < 5:
                    n += 1
                    if n == 4:
                        break
                for k in range(10, 0, -2):
                    wait(10)
            """,
            file="task5.py",
        )
        self.assertEqual(problems, [], text(problems))

    def test_round_is_a_valid_parameter_name(self):
        _, problems = check(
            'def next_target(round):\n    target("JP", "Tokyo!")\n', file="task2.py"
        )
        self.assertEqual(problems, [], text(problems))

    def test_variable_assigned_in_a_branch_is_known_later(self):
        _, problems = check(
            """
            def show_fact(country):
                if country.id == "UA":
                    fact = "Borscht!"
                else:
                    fact = "Cool"
                show_text(2, fact)
            """,
            file="task4.py",
        )
        self.assertEqual(problems, [], text(problems))

    def test_print_accepts_anything_and_cyrillic(self):
        _, problems = check('def hello_screen():\n    print("Привіт", 5, True)\n')
        self.assertEqual(problems, [], text(problems))


class RejectedCodeTests(unittest.TestCase):
    def assertProblem(self, source, fragment, file="task1.py"):
        _, problems = check(source, file=file)
        self.assertTrue(has_errors(problems), "очікувалась помилка: " + fragment)
        self.assertIn(fragment, text(problems))

    def test_division_suggests_floor_division(self):
        self.assertProblem("def on_button(number):\n    x = number / 2\n", "//")

    def test_fstring_suggests_str(self):
        self.assertProblem('def on_button(number):\n    x = f"{number}"\n', "str()")

    def test_string_plus_number_suggests_str(self):
        self.assertProblem('def on_button(number):\n    x = "n" + number\n', "str()")

    def test_list_is_rejected(self):
        self.assertProblem("def on_button(number):\n    x = [1, 2]\n", "списки")

    def test_global_code_is_rejected(self):
        self.assertProblem("x = 5\n", "поза функцією")

    def test_import_is_rejected(self):
        self.assertProblem("import random\n", "import")

    def test_helper_function_is_rejected(self):
        self.assertProblem("def helper():\n    pass\n", "Допоміжні")

    def test_hook_in_wrong_file(self):
        self.assertProblem("def on_button(number):\n    pass\n", "task1.py", file="task2.py")

    def test_hook_written_twice(self):
        self.assertProblem(
            "def hello_screen():\n    pass\n\ndef hello_screen():\n    pass\n", "двічі"
        )

    def test_wrong_number_of_parameters(self):
        self.assertProblem("def on_button():\n    pass\n", "def on_button(number)")

    def test_type_change_is_rejected(self):
        self.assertProblem('def on_button(number):\n    x = 5\n    x = "a"\n', "іншу назву")

    def test_use_before_assignment(self):
        self.assertProblem("def on_button(number):\n    show_text(1, str(y))\n", "ще не має значення")

    def test_unknown_function_suggests_close_match(self):
        self.assertProblem('def on_button(number):\n    show_txt(1, "a")\n', "show_text")

    def test_cyrillic_on_screen(self):
        self.assertProblem('def hello_screen():\n    show_text(0, "Привіт")\n', "латиницею")

    def test_too_long_text(self):
        self.assertProblem('def hello_screen():\n    show_text(0, "123456789012345")\n', "14")

    def test_ask_allows_42(self):
        _, problems = check('def question(number):\n    ask("' + "a" * 42 + '", "JP")\n', file="task3.py")
        self.assertEqual(problems, [], text(problems))
        self.assertProblem('def question(number):\n    ask("' + "a" * 43 + '", "JP")\n', "42", file="task3.py")

    def test_row_out_of_range(self):
        self.assertProblem('def hello_screen():\n    show_text(6, "a")\n', "від 0 до 5")

    def test_unknown_country(self):
        self.assertProblem('def on_button(number):\n    play_sound("XX")\n', "немає країни")

    def test_target_outside_next_target(self):
        self.assertProblem(
            'def on_hit(correct, ms):\n    target("JP", "a")\n', "next_target", file="task2.py"
        )

    def test_ask_outside_question(self):
        self.assertProblem(
            'def final(score, total):\n    ask("a", "JP")\n', "question", file="task3.py"
        )

    def test_cyrillic_variable_name(self):
        self.assertProblem("def on_button(number):\n    рахунок = 1\n", "латиницею")

    def test_api_name_as_variable(self):
        self.assertProblem("def on_button(number):\n    wait = 1\n", "назва нашої функції")

    def test_comparing_number_and_text(self):
        self.assertProblem('def on_button(number):\n    if number == "1":\n        pass\n', "лапки")

    def test_chained_comparison(self):
        self.assertProblem("def on_button(number):\n    if 0 < number < 3:\n        pass\n", "and")

    def test_method_call(self):
        self.assertProblem('def show_fact(country):\n    x = country.id.lower()\n', ".upper()", file="task4.py")

    def test_unknown_country_field(self):
        self.assertProblem("def show_fact(country):\n    x = country.name\n", "country.lcd_name", file="task4.py")

    def test_return_with_value(self):
        self.assertProblem("def on_button(number):\n    return 5\n", "return")

    def test_break_outside_loop(self):
        self.assertProblem("def on_button(number):\n    break\n", "циклу")

    def test_range_step_must_be_literal(self):
        self.assertProblem(
            "def on_button(number):\n    for i in range(0, 10, number):\n        pass\n", "крок"
        )

    def test_float(self):
        self.assertProblem("def on_button(number):\n    x = 1.5\n", "дробові")

    def test_input(self):
        self.assertProblem("def on_button(number):\n    x = input()\n", "клавіатури")

    def test_syntax_error_is_friendly(self):
        info, problems = check("def on_button(number)\n    pass\n")
        self.assertIsNone(info)
        self.assertIn("двокрапка", text(problems))
        self.assertIn("рядок 1", text(problems))

    def test_tabs_and_spaces(self):
        _, problems = check("def on_button(number):\n    x = 1\n\tx = 2\n")
        self.assertIn("пробіл", text(problems))

    def test_void_function_in_expression(self):
        self.assertProblem('def on_button(number):\n    x = show_text(1, "a")\n', "нічого не повертає")

    def test_random_result_unused(self):
        self.assertProblem("def on_button(number):\n    random_number(1, 5)\n", "ніде не використано")

    def test_country_cannot_be_copied(self):
        self.assertProblem("def show_fact(country):\n    c = country\n", "країну", file="task4.py")

    def test_show_country_inside_show_fact_is_rejected(self):
        # show_country() сама викликає show_fact() - на платі це нескінченний виклик.
        self.assertProblem(
            "def show_fact(country):\n    show_country(country.id)\n",
            "show_country() не можна викликати всередині show_fact(): вона сама його викликає",
            file="task4.py",
        )

    def test_show_country_elsewhere_is_accepted(self):
        _, problems = check('def on_button(number):\n    show_country("UA")\n')
        self.assertFalse(has_errors(problems), text(problems))

    def test_literal_zero_divisor_is_rejected(self):
        # На платі x // 0 дає 0, а на комп'ютері - помилку: краще не пустити.
        for line in ("x = number // 0", "x = number % 0", "x = number // -0",
                     "x = 5\n    x //= 0", "x = 5\n    x %= 0"):
            self.assertProblem("def on_button(number):\n    " + line + "\n", "ділити на нуль не можна")

    def test_non_zero_or_variable_divisor_is_accepted(self):
        _, problems = check("def on_button(number):\n    x = number // 2 + number % -3\n    x //= number\n")
        self.assertFalse(has_errors(problems), text(problems))


class AndOrAndPrintTests(unittest.TestCase):
    """and/or лише з умовами (інакше Python і плата дають різне); print(country) не підтримується."""

    def assertRejected(self, source, fragment, file="task2.py"):
        _, problems = check(source, file=file)
        self.assertTrue(has_errors(problems), "очікувалась помилка: " + fragment)
        self.assertIn(fragment, text(problems))

    def assertAccepted(self, source, file="task2.py"):
        _, problems = check(source, file=file)
        self.assertFalse(has_errors(problems), text(problems))

    def test_and_or_with_int_operand_rejected(self):
        for expression in ("ms and 5", "ms or 7", "ms and score"):
            source = "def on_hit(correct, ms):\n    score = 2\n    x = {}\n".format(expression)
            self.assertRejected(source, "and/or працюють з умовами")

    def test_and_or_with_int_in_if_rejected(self):
        self.assertRejected(
            "def on_hit(correct, ms):\n    score = 2\n    if ms and score:\n        pass\n",
            "x != 0 and y > 0",
        )

    def test_and_or_with_conditions_accepted(self):
        for condition in ("ms > 0 and ms < 5", "correct and ms > 1", "not correct or ms == 1"):
            self.assertAccepted(
                "def on_hit(correct, ms):\n    if {}:\n        pass\n".format(condition)
            )

    def test_plain_int_condition_and_not_still_allowed(self):
        self.assertAccepted("def on_hit(correct, ms):\n    if ms:\n        pass\n    while not ms:\n        break\n")

    def test_print_country_rejected(self):
        self.assertRejected("def show_fact(country):\n    print(country)\n", "country.lcd_name", file="task4.py")
        self.assertRejected('def show_fact(country):\n    print("x", country)\n', "country.lcd_name", file="task4.py")

    def test_print_country_field_accepted(self):
        self.assertAccepted("def show_fact(country):\n    print(country.lcd_name)\n", file="task4.py")


class WarningTests(unittest.TestCase):
    def test_missing_button_is_a_warning(self):
        _, problems = check("def on_button(number):\n    if number == 7:\n        pass\n")
        self.assertFalse(has_errors(problems))
        self.assertIn("кнопки 7 немає", text(problems))

    def test_foreign_row_is_a_warning(self):
        _, problems = check('def show_fact(country):\n    show_text(0, "a")\n', file="task4.py")
        self.assertFalse(has_errors(problems))
        self.assertIn("рядок 0", text(problems))


class ReadSourcesTests(unittest.TestCase):
    def setUp(self):
        self._folder = tempfile.TemporaryDirectory()
        self.folder = Path(self._folder.name)

    def tearDown(self):
        self._folder.cleanup()

    def test_bom_and_crlf_are_accepted(self):
        (self.folder / "task1.py").write_bytes(
            b"\xef\xbb\xbfdef hello_screen():\r\n    pass\r\n"
        )
        sources, problems = read_task_sources(self.folder)
        self.assertEqual(problems, [])
        self.assertEqual(sources["task1.py"], "def hello_screen():\n    pass\n")

    def test_ansi_file_gets_a_hint(self):
        (self.folder / "task1.py").write_bytes("# Привіт\n".encode("cp1251"))
        sources, problems = read_task_sources(self.folder)
        self.assertNotIn("task1.py", sources)
        self.assertIn("UTF-8", text(problems))

    def test_upper_case_name_is_accepted(self):
        (self.folder / "Task2.py").write_text("", encoding="utf-8")
        sources, problems = read_task_sources(self.folder)
        self.assertIn("task2.py", sources)

    def test_messenger_copy_is_reported(self):
        (self.folder / "task2 (1).py").write_text("", encoding="utf-8")
        (self.folder / "task3.py.txt").write_text("", encoding="utf-8")
        sources, problems = read_task_sources(self.folder)
        self.assertEqual(sources, {})
        self.assertIn("task2 (1).py", text(problems))
        self.assertIn("task3.py.txt", text(problems))
        self.assertFalse(has_errors(problems))

    def test_read_problems_name_the_task_they_belong_to(self):
        # Щоб globe test task2 показав попередження саме про task2.
        (self.folder / "task2 (1).py").write_text("", encoding="utf-8")
        (self.folder / "task3.py.txt").write_text("", encoding="utf-8")
        (self.folder / "task4.py").write_bytes("# Привіт\n".encode("cp1251"))
        (self.folder / "notes.py").write_text("", encoding="utf-8")
        _, problems = read_task_sources(self.folder)
        files = sorted(str(problem.file) for problem in problems)
        self.assertEqual(files, ["notes.py", "task2.py", "task3.py", "task4.py"])
        self.assertIn("перейменуй його на task2.py", text(problems))
        self.assertIn("перейменуй його на task3.py", text(problems))

    def test_missing_folder(self):
        sources, problems = read_task_sources(self.folder / "nope")
        self.assertEqual(sources, {})
        self.assertTrue(has_errors(problems))


class RobustnessTests(unittest.TestCase):
    def test_null_byte_does_not_raise(self):
        info, problems = check("def hello_screen():\n    pass\n\0")
        self.assertIsNone(info)
        self.assertTrue(has_errors(problems))
        self.assertIn("пошкоджено", text(problems))

    def test_very_deep_expression_does_not_raise(self):
        source = "def on_button(number):\n    x = " + "+".join(["1"] * 2000) + "\n"
        info, problems = check(source)
        self.assertIsNone(info)
        self.assertTrue(has_errors(problems))
        self.assertIn("занадто складний", text(problems))

    def test_duplicate_parameter_names(self):
        _, problems = check("def on_hit(a, a):\n    pass\n", file="task2.py")
        self.assertTrue(has_errors(problems))
        self.assertIn("різні назви", text(problems))

    def test_unreadable_file_is_reported(self):
        with tempfile.TemporaryDirectory() as name:
            path = Path(name) / "task1.py"
            path.write_text("", encoding="utf-8")
            path.chmod(0)
            try:
                try:
                    path.read_bytes()
                except OSError:
                    pass
                else:
                    self.skipTest("chmod не діє (наприклад, root)")
                sources, problems = read_task_sources(Path(name))
            finally:
                path.chmod(0o644)
        self.assertEqual(sources, {})
        self.assertTrue(has_errors(problems))
        self.assertIn("task1.py", text(problems))


if __name__ == "__main__":
    unittest.main()
