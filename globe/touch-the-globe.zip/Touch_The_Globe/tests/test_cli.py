"""Команди глобуса: press, test, list - у тимчасовому проєкті."""

import ast
import contextlib
import io
import os
import tempfile
import textwrap
import unittest
from pathlib import Path
from unittest import mock

from pc import players
from pc.cli import main, parse_token
from tests import ROOT
from tests.helpers import country_text

TASK1 = '''
def on_button(number):
    if number == 1:
        play_sound("UA")
        show_country("UA")
    elif number == 2:
        play_sound("JP")
        show_country("JP")
'''

TASK3 = '''
def question(number):
    if number == 1:
        ask("Where is Tokyo?", "JP")
'''


class ParseTokenTests(unittest.TestCase):
    def test_tokens(self):
        self.assertEqual(parse_token("1"), ("button", 1, None))
        self.assertEqual(parse_token("3:600"), ("button", 3, 600))
        self.assertEqual(parse_token("3@600"), ("button", 3, 600))
        self.assertEqual(parse_token("Q"), ("quiz", None, None))
        self.assertEqual(parse_token("g"), ("game", None, None))
        self.assertIsNone(parse_token("x"))
        self.assertIsNone(parse_token("1:"))


class ProjectCase(unittest.TestCase):
    """Маленький проєкт у тимчасовій папці: дві країни, settings.py, students/."""

    def setUp(self):
        self._folder = tempfile.TemporaryDirectory()
        self.root = Path(self._folder.name)
        countries = self.root / "content" / "countries"
        countries.mkdir(parents=True)
        (countries / "UA.txt").write_text(
            country_text(name="Україна", lcd_name="Ukraine", lcd_capital="Kyiv"), encoding="utf-8"
        )
        (countries / "JP.txt").write_text(
            country_text(name="Японія", lcd_name="Japan", lcd_capital="Tokyo"), encoding="utf-8"
        )
        (self.root / "settings.py").write_text(
            (ROOT / "settings.py").read_text(encoding="utf-8"), encoding="utf-8"
        )
        (self.root / "students").mkdir()
        self.env = mock.patch.dict(os.environ, {"GLOBE_PLAYER": "none", "GLOBE_AUDIO_MODE": "prerecorded"})
        self.env.start()

    def tearDown(self):
        self.env.stop()
        self._folder.cleanup()

    def task(self, name, source):
        (self.root / "students" / name).write_text(textwrap.dedent(source), encoding="utf-8")

    def run_cli(self, *argv):
        output = io.StringIO()
        with contextlib.redirect_stdout(output):
            code = main(list(argv), root=self.root)
        return code, output.getvalue()


class PressTests(ProjectCase):
    def test_press_shows_the_country(self):
        self.task("task1.py", TASK1)
        code, output = self.run_cli("press", "1")
        self.assertEqual(code, 0)
        self.assertIn("┃Ukraine       ┃", output)
        self.assertIn("│x1            │", output)

    def test_bad_token(self):
        code, output = self.run_cli("press", "банан")
        self.assertEqual(code, 1)
        self.assertIn("Не розумію", output)

    def test_no_keys(self):
        code, output = self.run_cli("press")
        self.assertEqual(code, 1)

    def test_quiz_shows_expected_button(self):
        self.task("task1.py", TASK1)
        self.task("task3.py", TASK3)
        code, output = self.run_cli("press", "q", "2")
        self.assertEqual(code, 0)
        self.assertIn("(загадано: JP — кнопка 2)", output)
        self.assertIn("Score: 1/1", output)

    def test_game_with_time(self):
        self.task("task1.py", TASK1)
        self.task(
            "task2.py",
            'def next_target(round):\n    target("JP", "Tokyo!")\n\n'
            'def on_hit(correct, ms):\n    show_text(4, str(ms) + " ms")\n',
        )
        code, output = self.run_cli("press", "g", "2:600", "2")
        self.assertEqual(code, 0)
        self.assertIn("600 ms", output)
        self.assertIn("1000 ms", output)

    def test_student_print_goes_to_console(self):
        self.task("task5.py", 'def loading():\n    print("hello", 5)\n')
        code, output = self.run_cli("press", "1")
        self.assertIn("hello 5", output)

    def test_broken_file_is_explained(self):
        self.task("task1.py", "def on_button(number):\n    x = [1]\n")
        code, output = self.run_cli("press", "1")
        self.assertIn("task1.py", output)
        self.assertIn("списки", output)


class EncodingErrorTests(ProjectCase):
    """Файл не в UTF-8 (Блокнот Windows: "Unicode") - українське повідомлення, а не трейсбек."""

    def test_utf16_country_file(self):
        (self.root / "content" / "countries" / "UA.txt").write_bytes(
            country_text(name="Україна").encode("utf-16")
        )
        code, output = self.run_cli("list")
        self.assertEqual(code, 1)
        self.assertIn("UTF-8", output)
        self.assertIn("UA", output)

    def test_bad_env_file(self):
        (self.root / ".env").write_bytes(b"GLOBE_PLAYER=\xff\xfe\n")
        code, output = self.run_cli("list")
        self.assertEqual(code, 1)
        self.assertIn(".env", output)
        self.assertIn("UTF-8", output)


class RunTests(ProjectCase):
    def test_run_does_not_spoil_the_answer(self):
        self.task("task1.py", TASK1)
        self.task("task3.py", TASK3)
        # time.sleep підміняємо, щоб пауза вікторини не гальмувала тест.
        with mock.patch("builtins.input", side_effect=["q", "2", "exit"]), mock.patch("time.sleep"):
            code, output = self.run_cli("run")
        self.assertEqual(code, 0)
        # Питання екран розбиває по словах: "Where is" / "Tokyo?".
        self.assertIn("│Where is      │", output)
        self.assertIn("│Tokyo?        │", output)
        self.assertNotIn("загадано", output)
        self.assertIn("Score: 1/1", output)


class TestCommandTests(ProjectCase):
    def test_all_good(self):
        self.task("task1.py", TASK1)
        code, output = self.run_cli("test")
        self.assertEqual(code, 0, output)
        self.assertIn("task1.py: усе гаразд", output)
        self.assertIn("task2.py: файлу немає", output)

    def test_error_gives_exit_code_1(self):
        self.task("task2.py", "def on_hit(correct, ms):\n    x = ms / 2\n")
        code, output = self.run_cli("test")
        self.assertEqual(code, 1)
        self.assertIn("//", output)

    def test_single_task(self):
        self.task("task1.py", TASK1)
        self.task("task2.py", "def on_hit(correct, ms):\n    x = ms / 2\n")
        code, output = self.run_cli("test", "task1")
        self.assertEqual(code, 0, output)
        self.assertNotIn("task2.py", output)

    def test_smoke_run_catches_runtime_errors(self):
        # Ділення на змінну, що дорівнює 0: аналізатор його не бачить.
        self.task("task4.py", "def show_fact(country):\n    zero = 0\n    x = 5 // zero\n")
        code, output = self.run_cli("test")
        self.assertIn("ділення на нуль", output)
        self.assertNotIn("ZeroDivisionError", output)

    def test_crash_in_trial_run_is_an_error(self):
        self.task("task4.py", "def show_fact(country):\n    zero = 0\n    x = 5 // zero\n")
        code, output = self.run_cli("test", "task4")
        self.assertEqual(code, 1, output)
        self.assertIn("[помилка] функція show_fact() з task4.py зупинилася з помилкою", output)
        self.assertIn("Помилок: 1", output)
        self.assertNotIn("Можна надсилати", output)

    def test_literal_zero_divisor_is_rejected(self):
        self.task("task4.py", "def show_fact(country):\n    x = 5 // 0\n")
        code, output = self.run_cli("test")
        self.assertEqual(code, 1, output)
        self.assertIn("ділити на нуль не можна", output)

    def test_endless_loop_is_reported(self):
        self.task("task5.py", "def loading():\n    while True:\n        pass\n")
        code, output = self.run_cli("test")
        self.assertIn("while", output)


class TestCommandReadProblemsTests(ProjectCase):
    """Файл, який не вдалося прочитати чи перейменований, не можна називати «файлу немає»."""

    def ansi_task3(self):
        (self.root / "students" / "task3.py").write_bytes(
            '# Вікторина\ndef question(number):\n    ask("Where is Tokyo?", "JP")\n'.encode("cp1251")
        )

    def test_single_task_with_ansi_file_fails(self):
        self.ansi_task3()
        code, output = self.run_cli("test", "task3")
        self.assertEqual(code, 1, output)
        self.assertIn("UTF-8", output)
        self.assertIn("файл є, але його не вдалося прочитати", output)
        self.assertNotIn("файлу немає", output)
        self.assertNotIn("Можна надсилати", output)

    def test_full_mode_with_ansi_file_does_not_say_missing(self):
        self.task("task1.py", TASK1)
        self.ansi_task3()
        code, output = self.run_cli("test")
        self.assertEqual(code, 1, output)
        self.assertIn("UTF-8", output)
        self.assertIn("task3.py: файл є, але його не вдалося прочитати", output)
        self.assertNotIn("task3.py: файлу немає", output)

    def test_single_task_with_messenger_copy_warns(self):
        (self.root / "students" / "task2 (1).py").write_text(
            'def next_target(round):\n    target("JP", "Tokyo!")\n', encoding="utf-8"
        )
        code, output = self.run_cli("test", "task2")
        self.assertIn("task2 (1).py", output)
        self.assertIn("перейменуй його на task2.py", output)
        self.assertNotIn("це нормально", output)
        self.assertIn("попереджень: 1", output)

    def test_single_task_with_txt_extension_warns(self):
        (self.root / "students" / "task2.py.txt").write_text("", encoding="utf-8")
        code, output = self.run_cli("test", "task2")
        self.assertIn("task2.py.txt", output)
        self.assertIn("перейменуй його на task2.py", output)
        self.assertNotIn("це нормально", output)

    def test_single_task_hides_other_files_problems(self):
        self.task("task1.py", TASK1)
        (self.root / "students" / "task2 (1).py").write_text("", encoding="utf-8")
        self.ansi_task3()
        code, output = self.run_cli("test", "task1")
        self.assertEqual(code, 0, output)
        self.assertNotIn("task2 (1).py", output)
        self.assertNotIn("UTF-8", output)


class ListTests(ProjectCase):
    def test_list_shows_buttons(self):
        self.task("task1.py", TASK1)
        code, output = self.run_cli("list")
        self.assertEqual(code, 0)
        self.assertIn("UA", output)
        line = [row for row in output.splitlines() if row.startswith("JP")][0]
        self.assertIn("2", line.split()[-2])


class EncodingLintTests(unittest.TestCase):
    """На Windows open() без encoding читає cp1252 - українські файли ламаються."""

    def test_every_open_names_an_encoding(self):
        files = [ROOT / "globe.py"]
        for folder in ("globe_core", "pc", "tools"):
            files.extend((ROOT / folder).glob("*.py"))
        for path in files:
            tree = ast.parse(path.read_text(encoding="utf-8"))
            for node in ast.walk(tree):
                if not isinstance(node, ast.Call):
                    continue
                func = node.func
                name = func.id if isinstance(func, ast.Name) else getattr(func, "attr", None)
                if name not in ("open", "read_text", "write_text"):
                    continue
                keywords = {keyword.arg for keyword in node.keywords}
                mode = node.args[1].value if len(node.args) > 1 and isinstance(node.args[1], ast.Constant) else ""
                if "b" in str(mode) or name == "open" and isinstance(func, ast.Attribute):
                    continue
                self.assertIn(
                    "encoding", keywords, "{}:{} - {}() без encoding".format(path.name, node.lineno, name)
                )


class WindowsPlayerTests(unittest.TestCase):
    def test_powershell_is_a_candidate_on_windows(self):
        names = [name for name, _, _ in players.candidates("win32")]
        self.assertIn("powershell", names)
        self.assertNotIn("powershell", [name for name, _, _ in players.candidates("darwin")])

    def test_apostrophe_is_escaped_for_powershell(self):
        name, command, escape = [c for c in players.candidates("win32") if c[0] == "powershell"][0]
        player = players.SystemPlayer(name, command, escape=escape)
        self.assertIn("Обов''язково", player.command_for("C:/Обов'язково/UA.mp3")[-1])


if __name__ == "__main__":
    unittest.main()
