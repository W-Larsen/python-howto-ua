"""Налаштування з settings.py: читаються без виконання коду і перевіряються."""

import tempfile
import unittest
from pathlib import Path

from globe_core.problems import has_errors
from globe_core.settings import DEFAULTS, load_settings, parse_settings
from tests import ROOT

GOOD = """
BUTTON_PINS = ["A0", "A1", "A2", "A3", "A4"]
QUIZ_PIN = "D10"
QUIZ_PAUSE_MS = 1500
GAME_PIN = "D11"
GAME_ROUNDS = 5
GAME_TIMEOUT_MS = 5000
GAME_PAUSE_MS = 1500
"""


def messages(problems):
    return "\n".join(str(problem) for problem in problems)


class ParseSettingsTests(unittest.TestCase):
    def test_good_file_has_no_problems(self):
        settings, problems = parse_settings(GOOD)
        self.assertEqual(problems, [], messages(problems))
        self.assertEqual(settings.button_pins, ["A0", "A1", "A2", "A3", "A4"])
        self.assertEqual(settings.button_count, 5)
        self.assertEqual(settings.quiz_pin, "D10")
        self.assertEqual(settings.game_timeout_ms, 5000)

    def test_shipped_settings_file_is_valid(self):
        settings, problems = load_settings(ROOT / "settings.py")
        self.assertFalse(has_errors(problems), messages(problems))
        self.assertEqual(problems, [], messages(problems))

    def test_pins_are_upper_case(self):
        settings, _ = parse_settings(GOOD.replace('"A0"', '"a0"'))
        self.assertEqual(settings.button_pins[0], "A0")

    def test_busy_pin_is_an_error(self):
        _, problems = parse_settings(GOOD.replace('"A4"', '"D5"'))
        self.assertTrue(has_errors(problems))
        self.assertIn("D5", messages(problems))
        self.assertIn("зайнятий", messages(problems))

    def test_duplicate_pin_is_an_error(self):
        _, problems = parse_settings(GOOD.replace('"A4"', '"A0"'))
        self.assertIn("двічі", messages(problems))

    def test_quiz_pin_cannot_be_a_country_button(self):
        _, problems = parse_settings(GOOD.replace('QUIZ_PIN = "D10"', 'QUIZ_PIN = "A1"'))
        self.assertIn("QUIZ_PIN", messages(problems))
        self.assertTrue(has_errors(problems))

    def test_unknown_pin_is_an_error(self):
        _, problems = parse_settings(GOOD.replace('"A4"', '"A9"'))
        self.assertIn("A9", messages(problems))

    def test_too_many_buttons(self):
        source = GOOD.replace(
            '["A0", "A1", "A2", "A3", "A4"]',
            '["A0", "A1", "A2", "A3", "A4", "A5", "D12", "D13", "D10"]',
        )
        _, problems = parse_settings(source)
        self.assertIn("8", messages(problems))

    def test_timeout_out_of_range(self):
        _, problems = parse_settings(GOOD.replace("5000", "50"))
        self.assertIn("GAME_TIMEOUT_MS", messages(problems))
        self.assertTrue(has_errors(problems))

    def test_wrong_type(self):
        settings, problems = parse_settings(GOOD.replace("GAME_ROUNDS = 5", 'GAME_ROUNDS = "five"'))
        self.assertIn("GAME_ROUNDS", messages(problems))
        self.assertEqual(settings.game_rounds, DEFAULTS["GAME_ROUNDS"])

    def test_bool_is_not_a_number(self):
        _, problems = parse_settings(GOOD.replace("GAME_ROUNDS = 5", "GAME_ROUNDS = True"))
        self.assertIn("GAME_ROUNDS", messages(problems))

    def test_unknown_name_is_a_warning(self):
        _, problems = parse_settings(GOOD + "\nQUIZ_PAUZE_MS = 100\n")
        self.assertFalse(has_errors(problems))
        self.assertIn("QUIZ_PAUZE_MS", messages(problems))

    def test_missing_name_uses_default_with_warning(self):
        source = GOOD.replace("GAME_PAUSE_MS = 1500\n", "")
        settings, problems = parse_settings(source)
        self.assertEqual(settings.game_pause_ms, 1500)
        self.assertIn("GAME_PAUSE_MS", messages(problems))
        self.assertFalse(has_errors(problems))

    def test_syntax_error_gives_defaults(self):
        settings, problems = parse_settings("QUIZ_PIN = \n")
        self.assertTrue(has_errors(problems))
        self.assertEqual(settings.quiz_pin, "D10")

    def test_code_is_never_executed(self):
        settings, problems = parse_settings('QUIZ_PIN = __import__("os").getcwd()\n')
        self.assertIn("QUIZ_PIN", messages(problems))
        self.assertEqual(settings.quiz_pin, "D10")

    def test_unhashable_literal_does_not_crash(self):
        settings, problems = parse_settings("QUIZ_PIN = {[1]: 2}\n")
        self.assertTrue(has_errors(problems))
        self.assertIn("QUIZ_PIN", messages(problems))
        self.assertEqual(settings.quiz_pin, "D10")

    def test_null_byte_does_not_crash(self):
        settings, problems = parse_settings('QUIZ_PIN = "D10"\x00\n')
        self.assertTrue(has_errors(problems))
        self.assertEqual(settings.quiz_pin, "D10")

    def test_line_numbers_are_reported(self):
        _, problems = parse_settings(GOOD.replace('"A4"', '"D5"'))
        self.assertTrue(any("settings.py" in str(problem) for problem in problems))


class LoadSettingsTests(unittest.TestCase):
    def test_missing_file_gives_defaults_with_warning(self):
        with tempfile.TemporaryDirectory() as folder:
            settings, problems = load_settings(Path(folder) / "settings.py")
        self.assertEqual(settings.quiz_pin, "D10")
        self.assertFalse(has_errors(problems))
        self.assertIn("settings.py", messages(problems))

    def test_bom_is_accepted(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "settings.py"
            path.write_bytes(b"\xef\xbb\xbf" + GOOD.encode("utf-8"))
            _, problems = load_settings(path)
        self.assertEqual(problems, [], messages(problems))


if __name__ == "__main__":
    unittest.main()
