"""Тести вибору й роботи плеєра на комп'ютері.

Замість справжнього afplay підставляємо команди sleep і true - тоді
можна перевірити, що програма справді чекає кінця запису й справді
вміє перебивати попередній звук, і при цьому нічого не звучить.
"""

import time
import unittest

from pc import players


class NullPlayerTests(unittest.TestCase):
    def test_does_nothing_quietly(self):
        player = players.NullPlayer()
        player.play("/такого/файлу/немає.mp3")
        player.wait()
        player.stop()
        self.assertIn("вимкнено", player.describe())


class SystemPlayerTests(unittest.TestCase):
    def test_wait_blocks_until_the_end(self):
        player = players.SystemPlayer("sleep", ["sleep", "0.4"])
        started = time.monotonic()
        player.play("не важливо")
        player.wait()
        self.assertGreater(time.monotonic() - started, 0.3)

    def test_stop_interrupts_playback(self):
        player = players.SystemPlayer("sleep", ["sleep", "30"])
        player.play("не важливо")
        started = time.monotonic()
        player.stop()
        self.assertLess(time.monotonic() - started, 3)

    def test_new_playback_replaces_the_previous_one(self):
        """Так на глобусі нове натискання перебиває попередню розповідь."""
        player = players.SystemPlayer("sleep", ["sleep", "30"])
        player.play("перший")
        first = player._process
        player.play("другий")
        self.assertIsNot(player._process, first)
        self.assertIsNotNone(first.poll(), "попередній процес не зупинили")
        player.stop()

    def test_file_name_is_substituted(self):
        player = players.SystemPlayer("echo", ["echo", "{file}"])
        player.play("/audio/UA.mp3")
        player.wait()

    def test_missing_program_is_explained(self):
        player = players.SystemPlayer("немає", ["такої-програми-немає"])
        with self.assertRaises(players.PlayerError) as caught:
            player.play("файл.mp3")
        self.assertIn("немає", str(caught.exception))

    def test_wait_without_playback_is_safe(self):
        players.SystemPlayer("sleep", ["sleep", "0"]).wait()

    def test_stop_without_playback_is_safe(self):
        players.SystemPlayer("sleep", ["sleep", "0"]).stop()


class CreatePlayerTests(unittest.TestCase):
    def test_none_gives_silent_player(self):
        self.assertIsInstance(players.create_player("none"), players.NullPlayer)

    def test_auto_finds_something(self):
        player = players.create_player("auto", warn=lambda message: None)
        self.assertTrue(hasattr(player, "play"))
        self.assertTrue(hasattr(player, "describe"))

    def test_unknown_choice_warns_but_still_works(self):
        warnings = []
        player = players.create_player("качка", warn=warnings.append)
        self.assertTrue(warnings)
        self.assertIn("auto", warnings[0])
        self.assertTrue(hasattr(player, "play"))

    def test_missing_pygame_falls_back_to_silence(self):
        real_find = players.find_system_player
        warnings = []
        try:
            # Робимо вигляд, що системного плеєра немає
            players.find_system_player = lambda: None
            player = players.create_player("system", warn=warnings.append)
        finally:
            players.find_system_player = real_find

        self.assertIsInstance(player, players.NullPlayer)
        self.assertTrue(warnings)

    def test_install_hint_is_not_empty(self):
        self.assertTrue(players.install_hint())


class RecordingPlayer:
    def __init__(self):
        self.played = []
        self.waited = 0
        self.stopped = 0

    def play(self, path):
        self.played.append(path)

    def wait(self):
        self.waited += 1

    def stop(self):
        self.stopped += 1


class SpeakerTests(unittest.TestCase):
    def test_speaker_passes_path_to_player(self):
        player = RecordingPlayer()
        players.PcSpeaker(player).play("/audio/UA.mp3")
        self.assertEqual(player.played, ["/audio/UA.mp3"])

    def test_none_is_not_played(self):
        player = RecordingPlayer()
        players.PcSpeaker(player).play(None)
        self.assertEqual(player.played, [])

    def test_blocking_speaker_waits(self):
        player = RecordingPlayer()
        players.PcSpeaker(player, blocking=True).play("/audio/UA.mp3")
        self.assertEqual(player.waited, 1)

    def test_non_blocking_speaker_does_not_wait(self):
        """Для інтерактивного режиму: щоб кнопки не залипали."""
        player = RecordingPlayer()
        players.PcSpeaker(player, blocking=False).play("/audio/UA.mp3")
        self.assertEqual(player.waited, 0)

    def test_speaker_cannot_talk_without_elevenlabs(self):
        self.assertFalse(hasattr(players.PcSpeaker(RecordingPlayer()), "say"))


if __name__ == "__main__":
    unittest.main()
