"""Вікторина (task3) і «Блискавка» (task2) у ядрі на комп'ютері."""

import unittest

from globe_core.engine import FINISHED, GAME, NORMAL, QUIZ
from tests.test_engine import EngineCase


def secret_button(engine, api):
    """on_button з «секретною» кнопкою 5 (бонус картки task1): малює і чекає."""
    plain = engine.hooks["on_button"]

    def on_button(number):
        if number == 5:
            api["clear_screen"]()
            api["show_text"](2, "Secret!")
            api["blink"](2)
            api["wait"](700)
        else:
            plain(number)

    return on_button


class QuizTests(EngineCase):
    def setUp(self):
        EngineCase.setUp(self)
        api = self.api
        self.answers = []
        self.finals = []

        def question(number):
            if number == 1:
                api["ask"]("Where is Tokyo?", "JP")
            elif number == 2:
                api["ask"]("Borscht?", "UA")

        def on_answer(correct, score):
            self.answers.append((correct, score))
            api["show_text"](3, "Bravo!" if correct else "Nope :(")

        def final(score, total):
            self.finals.append((score, total))
            api["show_text"](2, "GENIUS!")

        self.engine.set_hooks(
            {
                "on_button": self.on_button_ua_jp(),
                "question": question,
                "on_answer": on_answer,
                "final": final,
            }
        )

    def test_first_question_is_shown(self):
        self.engine.touch_quiz()
        self.assertEqual(self.engine.mode, QUIZ)
        self.assertEqual(self.screen()[:2], ("Where is", "Tokyo?"))
        self.assertTrue(any("JP" in note and "кнопка 2" in note for note in self.notes))

    def test_full_quiz(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)   # JP - правильно
        self.assertEqual(self.answers, [(True, 1)])
        self.engine.touch_button(2)   # JP замість UA - неправильно
        self.assertEqual(self.answers, [(True, 1), (False, 1)])
        self.assertEqual(self.finals, [(1, 2)])
        self.assertEqual(self.screen()[2], "GENIUS!")
        self.assertEqual(self.screen()[5], "Score: 1/2")
        self.assertEqual(self.engine.mode, FINISHED)

    def test_score_row_after_answer(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)
        self.assertIn(("Where is", "Tokyo?", "", "Bravo!", "", "Score: 1/1"), self.display.frames)

    def test_pause_between_questions(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)
        self.assertIn(1.5, self.sleep.calls)

    def test_sound_is_silent_and_counts_do_not_change(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)
        self.assertEqual(self.speaker.played, [])
        self.assertEqual(self.engine.press_count("JP"), 0)

    def test_touch_without_answer_is_ignored(self):
        self.engine.touch_quiz()
        self.engine.touch_button(3)
        self.assertEqual(self.answers, [])
        self.assertEqual(self.engine.mode, QUIZ)

    def test_after_finish_next_touch_is_normal(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)
        self.engine.touch_button(1)
        self.engine.touch_button(1)
        self.assertEqual(self.engine.mode, NORMAL)
        self.assertEqual(self.screen()[0], "Ukraine")

    def test_no_questions(self):
        self.engine.set_hooks({"on_button": self.on_button_ua_jp()})
        self.engine.touch_quiz()
        self.assertEqual(self.screen()[2], "No questions")
        self.assertEqual(self.engine.mode, NORMAL)
        self.assertTrue(any("task3.py" in warning for warning in self.warnings))

    def test_secret_button_does_not_wipe_the_question(self):
        self.engine.set_hooks(dict(self.engine.hooks, on_button=secret_button(self.engine, self.api)))
        self.engine.touch_quiz()
        before = self.screen()
        sleeps = list(self.sleep.calls)
        self.engine.touch_button(5)
        self.assertEqual(self.screen(), before)
        self.assertEqual(self.screen()[:2], ("Where is", "Tokyo?"))
        self.assertEqual(self.sleep.calls, sleeps)
        self.assertEqual(self.display.blinks, [])
        self.assertEqual(self.engine.mode, QUIZ)
        # Відповідь після цього зараховується як завжди.
        self.engine.touch_button(2)
        self.assertEqual(self.answers, [(True, 1)])

    def test_secret_button_still_works_outside_games(self):
        self.engine.set_hooks(dict(self.engine.hooks, on_button=secret_button(self.engine, self.api)))
        self.engine.touch_button(5)
        self.assertEqual(self.screen()[2], "Secret!")
        self.assertEqual(self.display.blinks, [2])
        self.assertIn(0.7, self.sleep.calls)

    def test_endless_quiz_is_limited(self):
        api = self.api
        self.engine.set_hooks(
            {"on_button": self.on_button_ua_jp(), "question": lambda n: api["ask"]("Q", "UA")}
        )
        self.engine.touch_quiz()
        for _ in range(50):
            self.engine.touch_button(1)
        self.assertEqual(self.engine.mode, FINISHED)
        self.assertEqual(self.screen()[5], "Score: 50/50")

    def test_quiz_button_during_game_is_ignored(self):
        self.engine.touch_quiz()
        self.engine.touch_quiz()
        self.engine.touch_game()
        self.assertEqual(self.engine.mode, QUIZ)


class GameTests(EngineCase):
    def setUp(self):
        EngineCase.setUp(self)
        api = self.api
        self.hits = []
        self.overs = []

        def next_target(round):
            if round % 2 == 1:
                api["target"]("JP", "Tokyo!")
            else:
                api["target"]("UA", "Borscht!")

        def on_hit(correct, ms):
            self.hits.append((correct, ms))
            api["show_text"](4, str(ms) + " ms")

        def game_over(score, rounds):
            self.overs.append((score, rounds))

        self.engine.set_hooks(
            {
                "on_button": self.on_button_ua_jp(),
                "next_target": next_target,
                "on_hit": on_hit,
                "game_over": game_over,
            }
        )

    def test_countdown_and_first_round(self):
        self.engine.touch_game()
        self.assertEqual(self.sleep.calls[:3], [0.5, 0.5, 0.5])
        self.assertEqual(self.engine.mode, GAME)
        self.assertEqual(self.screen()[0], "Round 1/5")
        self.assertEqual(self.screen()[1], "Tokyo!")
        self.assertEqual(self.screen()[5], "Score: 0")

    def test_explicit_ms(self):
        self.engine.touch_game()
        self.engine.touch_button(2, ms=600)
        self.assertEqual(self.hits, [(True, 600)])
        self.assertIn(1.5, self.sleep.calls)
        self.assertEqual(self.screen()[0], "Round 2/5")

    def test_measured_ms(self):
        self.engine.touch_game()
        self.clock.advance(0.8)
        self.engine.touch_button(2)
        self.assertEqual(self.hits, [(True, 800)])

    def test_wrong_country(self):
        self.engine.touch_game()
        self.engine.touch_button(1, ms=300)
        self.assertEqual(self.hits, [(False, 300)])

    def test_too_slow_counts_as_miss(self):
        self.engine.touch_game()
        self.engine.touch_button(2, ms=7000)
        self.assertEqual(self.hits, [(False, 5000)])

    def test_tick_ends_round_on_timeout(self):
        self.engine.touch_game()
        self.clock.advance(4.0)
        self.engine.tick()
        self.assertEqual(self.hits, [])
        self.clock.advance(1.5)
        self.engine.tick()
        self.assertEqual(self.hits, [(False, 5000)])

    def test_full_game(self):
        self.engine.touch_game()
        for number in (2, 1, 2, 2, 2):
            self.engine.touch_button(number, ms=500)
        self.assertEqual(self.overs, [(4, 5)])
        self.assertEqual(self.screen()[5], "Score: 4/5")
        self.assertEqual(self.engine.mode, FINISHED)

    def test_sound_is_silent(self):
        self.engine.touch_game()
        self.engine.touch_button(2, ms=500)
        self.assertEqual(self.speaker.played, [])

    def test_no_targets(self):
        self.engine.set_hooks({"on_button": self.on_button_ua_jp()})
        self.engine.touch_game()
        self.assertEqual(self.screen()[2], "No game")
        self.assertEqual(self.engine.mode, NORMAL)
        self.assertTrue(any("task2.py" in warning for warning in self.warnings))

    def test_target_only_on_some_rounds_ends_game(self):
        api = self.api
        self.engine.set_hooks(
            {
                "on_button": self.on_button_ua_jp(),
                "next_target": lambda r: api["target"]("JP", "T") if r == 1 else None,
                "game_over": lambda score, rounds: self.overs.append((score, rounds)),
            }
        )
        self.engine.touch_game()
        self.engine.touch_button(2, ms=100)
        self.assertEqual(self.overs, [(1, 5)])

    def test_timeout_round(self):
        self.engine.touch_game()
        self.engine.timeout_round()
        self.assertEqual(self.hits, [(False, 5000)])
        self.assertEqual(self.screen()[0], "Round 2/5")

    def test_secret_button_does_not_wipe_the_hint_or_add_time(self):
        self.engine.set_hooks(dict(self.engine.hooks, on_button=secret_button(self.engine, self.api)))
        self.engine.touch_game()
        before = self.screen()
        sleeps = list(self.sleep.calls)
        self.engine.touch_button(5)
        self.assertEqual(self.screen(), before)
        self.assertEqual(self.screen()[1], "Tokyo!")
        self.assertEqual(self.sleep.calls, sleeps)
        self.assertEqual(self.display.blinks, [])
        self.assertEqual(self.engine.mode, GAME)
        # Секретна кнопка не з'їла часу: відповідь через 0,3 с - це 300 мс.
        self.clock.advance(0.3)
        self.engine.touch_button(2)
        self.assertEqual(self.hits, [(True, 300)])
        self.assertFalse(self.engine._probing)

    def test_button_for_probe_has_no_side_effects(self):
        self.assertEqual(self.engine.button_for("JP"), 2)
        self.assertEqual(self.engine.button_for("US"), None)
        self.assertEqual(self.speaker.played, [])
        self.assertEqual(self.engine.press_count("JP"), 0)


if __name__ == "__main__":
    unittest.main()
