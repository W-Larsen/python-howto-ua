"""Вікторина (task3) і «Блискавка» (task2) у ядрі на комп'ютері."""

import unittest

from globe_core.engine import FINISHED, GAME, NORMAL, QUIZ
from globe_core.settings import DEFAULTS, Settings
from tests.test_engine import EngineCase


def secret_button(engine, api):
    """on_button з «секретною» кнопкою 5 (бонус картки task1): малює і чекає."""
    plain = engine.hooks["on_button"]

    def on_button(number):
        if number == 5:
            api["clear_screen"]()
            api["show_text"](2, "Secret!")
            api["blink"](2)
            api["wait"](700)
        else:
            plain(number)

    return on_button


class QuizTests(EngineCase):
    def setUp(self):
        EngineCase.setUp(self)
        api = self.api
        self.answers = []
        self.finals = []

        def question(number):
            if number == 1:
                api["ask"]("Where is Tokyo?", "JP")
            elif number == 2:
                api["ask"]("Borscht?", "UA")

        def on_answer(correct, score):
            self.answers.append((correct, score))
            api["show_text"](3, "Bravo!" if correct else "Nope :(")

        def final(score, total):
            self.finals.append((score, total))
            api["show_text"](2, "GENIUS!")

        self.engine.set_hooks(
            {
                "on_button": self.on_button_ua_jp(),
                "question": question,
                "on_answer": on_answer,
                "final": final,
            }
        )

    def test_first_question_is_shown(self):
        self.engine.touch_quiz()
        self.assertEqual(self.engine.mode, QUIZ)
        self.assertEqual(self.screen()[:2], ("Where is", "Tokyo?"))
        self.assertTrue(any("JP" in note and "кнопка 2" in note for note in self.notes))

    def test_full_quiz(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)   # JP - правильно
        self.assertEqual(self.answers, [(True, 1)])
        self.engine.touch_button(2)   # JP замість UA - неправильно
        self.assertEqual(self.answers, [(True, 1), (False, 1)])
        self.assertEqual(self.finals, [(1, 2)])
        self.assertEqual(self.screen()[2], "GENIUS!")
        self.assertEqual(self.screen()[5], "Score: 1/2")
        self.assertEqual(self.engine.mode, FINISHED)

    def test_score_row_after_answer(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)
        self.assertIn(("Where is", "Tokyo?", "", "Bravo!", "", "Score: 1/1"), self.display.frames)

    def test_pause_between_questions(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)
        self.assertIn(1.5, self.sleep.calls)

    def test_sound_is_silent_and_counts_do_not_change(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)
        self.assertEqual(self.speaker.played, [])
        self.assertEqual(self.engine.press_count("JP"), 0)

    def test_touch_without_answer_is_ignored(self):
        self.engine.touch_quiz()
        self.engine.touch_button(3)
        self.assertEqual(self.answers, [])
        self.assertEqual(self.engine.mode, QUIZ)

    def test_after_finish_next_touch_is_normal(self):
        self.engine.touch_quiz()
        self.engine.touch_button(2)
        self.engine.touch_button(1)
        self.engine.touch_button(1)
        self.assertEqual(self.engine.mode, NORMAL)
        self.assertEqual(self.screen()[0], "Ukraine")

    def test_no_questions(self):
        self.engine.set_hooks({"on_button": self.on_button_ua_jp()})
        self.engine.touch_quiz()
        self.assertEqual(self.screen()[2], "No questions")
        self.assertEqual(self.engine.mode, NORMAL)
        self.assertTrue(any("task3.py" in warning for warning in self.warnings))

    def test_secret_button_does_not_wipe_the_question(self):
        self.engine.set_hooks(dict(self.engine.hooks, on_button=secret_button(self.engine, self.api)))
        self.engine.touch_quiz()
        before = self.screen()
        sleeps = list(self.sleep.calls)
        self.engine.touch_button(5)
        self.assertEqual(self.screen(), before)
        self.assertEqual(self.screen()[:2], ("Where is", "Tokyo?"))
        self.assertEqual(self.sleep.calls, sleeps)
        self.assertEqual(self.display.blinks, [])
        self.assertEqual(self.engine.mode, QUIZ)
        # Відповідь після цього зараховується як завжди.
        self.engine.touch_button(2)
        self.assertEqual(self.answers, [(True, 1)])

    def test_secret_button_still_works_outside_games(self):
        self.engine.set_hooks(dict(self.engine.hooks, on_button=secret_button(self.engine, self.api)))
        self.engine.touch_button(5)
        self.assertEqual(self.screen()[2], "Secret!")
        self.assertEqual(self.display.blinks, [2])
        self.assertIn(0.7, self.sleep.calls)

    def test_endless_quiz_is_limited(self):
        api = self.api
        self.engine.set_hooks(
            {"on_button": self.on_button_ua_jp(), "question": lambda n: api["ask"]("Q", "UA")}
        )
        self.engine.touch_quiz()
        for _ in range(50):
            self.engine.touch_button(1)
        self.assertEqual(self.engine.mode, FINISHED)
        self.assertEqual(self.screen()[5], "Score: 50/50")

    def test_quiz_button_during_game_is_ignored(self):
        self.engine.touch_quiz()
        self.engine.touch_quiz()
        self.engine.touch_game()
        self.assertEqual(self.engine.mode, QUIZ)


class GameTests(EngineCase):
    def setUp(self):
        EngineCase.setUp(self)
        api = self.api
        self.hits = []
        self.overs = []

        def next_target(round):
            if round % 2 == 1:
                api["target"]("JP", "Tokyo!")
            else:
                api["target"]("UA", "Borscht!")

        def on_hit(correct, ms):
            self.hits.append((correct, ms))
            api["show_text"](4, str(ms) + " ms")

        def game_over(score, rounds):
            self.overs.append((score, rounds))

        self.engine.set_hooks(
            {
                "on_button": self.on_button_ua_jp(),
                "next_target": next_target,
                "on_hit": on_hit,
                "game_over": game_over,
            }
        )

    def test_countdown_and_first_round(self):
        self.engine.touch_game()
        self.assertEqual(self.sleep.calls[:3], [0.5, 0.5, 0.5])
        self.assertEqual(self.engine.mode, GAME)
        self.assertEqual(self.screen()[0], "Round 1/5")
        self.assertEqual(self.screen()[1], "Tokyo!")
        self.assertEqual(self.screen()[5], "Score: 0")

    def test_explicit_ms(self):
        self.engine.touch_game()
        self.engine.touch_button(2, ms=600)
        self.assertEqual(self.hits, [(True, 600)])
        self.assertIn(1.5, self.sleep.calls)
        self.assertEqual(self.screen()[0], "Round 2/5")

    def test_measured_ms(self):
        self.engine.touch_game()
        self.clock.advance(0.8)
        self.engine.touch_button(2)
        self.assertEqual(self.hits, [(True, 800)])

    def test_wrong_country(self):
        self.engine.touch_game()
        self.engine.touch_button(1, ms=300)
        self.assertEqual(self.hits, [(False, 300)])

    def test_too_slow_counts_as_miss(self):
        self.engine.touch_game()
        self.engine.touch_button(2, ms=7000)
        self.assertEqual(self.hits, [(False, 5000)])

    def test_tick_ends_round_on_timeout(self):
        self.engine.touch_game()
        self.clock.advance(4.0)
        self.engine.tick()
        self.assertEqual(self.hits, [])
        self.clock.advance(1.5)
        self.engine.tick()
        self.assertEqual(self.hits, [(False, 5000)])

    def test_full_game(self):
        self.engine.touch_game()
        for number in (2, 1, 2, 2, 2):
            self.engine.touch_button(number, ms=500)
        self.assertEqual(self.overs, [(4, 5)])
        self.assertEqual(self.screen()[5], "Score: 4/5")
        self.assertEqual(self.engine.mode, FINISHED)

    def test_sound_is_silent(self):
        self.engine.touch_game()
        self.engine.touch_button(2, ms=500)
        self.assertEqual(self.speaker.played, [])

    def test_no_targets(self):
        self.engine.set_hooks({"on_button": self.on_button_ua_jp()})
        self.engine.touch_game()
        self.assertEqual(self.screen()[2], "No game")
        self.assertEqual(self.engine.mode, NORMAL)
        self.assertTrue(any("task2.py" in warning for warning in self.warnings))

    def test_target_only_on_some_rounds_ends_game(self):
        api = self.api
        self.engine.set_hooks(
            {
                "on_button": self.on_button_ua_jp(),
                "next_target": lambda r: api["target"]("JP", "T") if r == 1 else None,
                "game_over": lambda score, rounds: self.overs.append((score, rounds)),
            }
        )
        self.engine.touch_game()
        self.engine.touch_button(2, ms=100)
        self.assertEqual(self.overs, [(1, 5)])

    def test_timeout_round(self):
        self.engine.touch_game()
        self.engine.timeout_round()
        self.assertEqual(self.hits, [(False, 5000)])
        self.assertEqual(self.screen()[0], "Round 2/5")

    def test_secret_button_does_not_wipe_the_hint_or_add_time(self):
        self.engine.set_hooks(dict(self.engine.hooks, on_button=secret_button(self.engine, self.api)))
        self.engine.touch_game()
        before = self.screen()
        sleeps = list(self.sleep.calls)
        self.engine.touch_button(5)
        self.assertEqual(self.screen(), before)
        self.assertEqual(self.screen()[1], "Tokyo!")
        self.assertEqual(self.sleep.calls, sleeps)
        self.assertEqual(self.display.blinks, [])
        self.assertEqual(self.engine.mode, GAME)
        # Секретна кнопка не з'їла часу: відповідь через 0,3 с - це 300 мс.
        self.clock.advance(0.3)
        self.engine.touch_button(2)
        self.assertEqual(self.hits, [(True, 300)])
        self.assertFalse(self.engine._probing)

    def test_button_for_probe_has_no_side_effects(self):
        self.assertEqual(self.engine.button_for("JP"), 2)
        self.assertEqual(self.engine.button_for("US"), None)
        self.assertEqual(self.speaker.played, [])
        self.assertEqual(self.engine.press_count("JP"), 0)


class ButtonMappingTests(EngineCase):
    """Таблиця «кнопка -> країна» від вчителя: ігри не залежать від task1."""

    def setUp(self):
        EngineCase.setUp(self)
        self.engine.settings = Settings(dict(DEFAULTS, BUTTON_COUNTRIES=["UA", "JP", ""]))
        api = self.api
        self.hits = []

        def next_target(round):
            api["target"]("JP", "Tokyo!")

        self.engine.set_hooks(
            {
                "on_button": lambda number: None,   # task1 ще порожній
                "next_target": next_target,
                "on_hit": lambda correct, ms: self.hits.append((correct, ms)),
            }
        )

    def test_game_reads_the_answer_from_the_table_not_from_task1(self):
        self.engine.touch_game()
        self.assertEqual(self.engine.mode, GAME)
        self.assertTrue(any("JP" in note and "кнопка 2" in note for note in self.notes))
        self.engine.touch_button(2, ms=400)
        self.assertEqual(self.hits, [(True, 400)])

    def test_wrong_button_is_wrong_even_if_task1_is_silent(self):
        self.engine.touch_game()
        self.engine.touch_button(1, ms=400)
        self.assertEqual(self.hits, [(False, 400)])

    def test_task1_cannot_change_the_answer(self):
        self.engine.set_hooks(dict(self.engine.hooks, on_button=self.on_button_ua_jp()))
        self.engine.hooks["on_button"] = lambda number: self.api["show_country"]("UA")
        self.engine.touch_game()
        self.engine.touch_button(2, ms=400)
        self.assertEqual(self.hits, [(True, 400)])

    def test_button_without_a_table_entry_falls_back_to_task1(self):
        self.engine.set_hooks(dict(self.engine.hooks, on_button=lambda n: self.api["show_country"]("UA") if n == 3 else None))
        self.assertEqual(self.engine.button_for("UA"), 1)
        self.assertEqual(self.engine.button_for("JP"), 2)
        self.engine.settings = Settings(dict(DEFAULTS, BUTTON_COUNTRIES=["", "JP"]))
        self.assertEqual(self.engine.button_for("UA"), 3)

    def test_button_for_does_not_need_task1(self):
        self.assertEqual(self.engine.button_for("UA"), 1)
        self.assertEqual(self.engine.button_for("JP"), 2)
        self.assertIsNone(self.engine.button_for("US"))

    def test_unknown_country_in_the_table_is_reported_and_skipped(self):
        self.engine.settings = Settings(dict(DEFAULTS, BUTTON_COUNTRIES=["XX"]))
        self.assertIsNone(self.engine.mapped_country(1))
        self.assertTrue(any("XX" in warning for warning in self.warnings))


class CheckButtonsTests(EngineCase):
    """task1 проти таблиці вчителя: розбіжність - попередження, не помилка."""

    def setUp(self):
        EngineCase.setUp(self)
        self.engine.settings = Settings(dict(DEFAULTS, BUTTON_COUNTRIES=["UA", "JP"]))

    def test_matching_task1_is_quiet(self):
        self.engine.set_hooks({"on_button": self.on_button_ua_jp()})
        self.engine.check_buttons()
        self.assertEqual(self.warnings, [])

    def test_other_country_is_a_warning_and_the_code_still_runs(self):
        api = self.api
        self.engine.set_hooks(
            {"on_button": lambda n: api["show_country"]("JP" if n == 1 else "UA")}
        )
        self.engine.check_buttons()
        self.assertEqual(len(self.warnings), 2)
        self.assertIn("кнопка 1", self.warnings[0])
        self.assertIn("UA", self.warnings[0])
        self.assertIn("JP", self.warnings[0])
        self.engine.touch_button(1)
        self.assertEqual(self.screen()[0], "Japan")

    def test_button_that_shows_nothing_is_a_warning(self):
        self.engine.set_hooks({"on_button": lambda n: None})
        self.engine.check_buttons()
        self.assertEqual(len(self.warnings), 2)
        self.assertIn("нічого", self.warnings[0])

    def test_check_has_no_side_effects(self):
        self.engine.set_hooks({"on_button": self.on_button_ua_jp()})
        self.engine.check_buttons()
        self.assertEqual(self.speaker.played, [])
        self.assertEqual(self.engine.press_count("UA"), 0)
        self.assertFalse(self.engine._probing)

    def test_without_task1_or_table_nothing_to_check(self):
        self.engine.check_buttons()
        self.engine.settings = Settings(dict(DEFAULTS))
        self.engine.set_hooks({"on_button": lambda n: None})
        self.engine.check_buttons()
        self.assertEqual(self.warnings, [])


if __name__ == "__main__":
    unittest.main()
