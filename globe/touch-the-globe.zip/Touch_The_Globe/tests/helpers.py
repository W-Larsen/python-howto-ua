"""Спільні дрібниці для тестів."""

import tempfile
import unittest
from pathlib import Path

from globe_core.catalog import load_catalog

SAMPLE = """name: {name}
capital: {capital}
continent: {continent}
lcd_name: {lcd_name}
lcd_capital: {lcd_capital}
---
{text}
"""


def country_text(
    name="Тестленд",
    capital="Тестбург",
    continent="Європа",
    lcd_name="Testland",
    lcd_capital="Testburg",
    text="Тут живуть тести.",
):
    return SAMPLE.format(
        name=name,
        capital=capital,
        continent=continent,
        lcd_name=lcd_name,
        lcd_capital=lcd_capital,
        text=text,
    )


class TempContentCase(unittest.TestCase):
    """Створює тимчасову папку countries/ і прибирає її після тесту."""

    def setUp(self):
        self._temporary = tempfile.TemporaryDirectory()
        self.countries_dir = Path(self._temporary.name) / "countries"
        self.countries_dir.mkdir()

    def tearDown(self):
        self._temporary.cleanup()

    def write_country(self, country_id, **kwargs):
        raw = kwargs.pop("raw", None)
        if raw is None:
            raw = country_text(**kwargs)
        path = self.countries_dir / (country_id + ".txt")
        path.write_text(raw, encoding="utf-8")
        return path

    def load(self):
        return load_catalog(str(self.countries_dir))
