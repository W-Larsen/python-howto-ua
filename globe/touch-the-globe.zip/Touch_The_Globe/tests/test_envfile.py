"""Тести читача .env."""

import tempfile
import unittest
from pathlib import Path

from globe_core.envfile import load_env_file, parse_env
from pc.config import ConfigError, load_config


class ParseTests(unittest.TestCase):
    def test_simple_pairs(self):
        values = parse_env("GLOBE_CONTENT_DIR=content\nGLOBE_PLAYER=system\n")
        self.assertEqual(
            values, {"GLOBE_CONTENT_DIR": "content", "GLOBE_PLAYER": "system"}
        )

    def test_comments_and_blank_lines(self):
        values = parse_env("# коментар\n\nGLOBE_PLAYER=system\n")
        self.assertEqual(values, {"GLOBE_PLAYER": "system"})

    def test_spaces_around_equals(self):
        self.assertEqual(
            parse_env("  GLOBE_PLAYER = system  \n"), {"GLOBE_PLAYER": "system"}
        )

    def test_quotes_are_removed(self):
        values = parse_env("A=\"один\"\nB='два'\n")
        self.assertEqual(values, {"A": "один", "B": "два"})

    def test_export_prefix(self):
        self.assertEqual(
            parse_env("export GLOBE_PLAYER=system\n"), {"GLOBE_PLAYER": "system"}
        )

    def test_trailing_comment_is_cut(self):
        values = parse_env("GLOBE_PLAYER=system # так швидше\n")
        self.assertEqual(values["GLOBE_PLAYER"], "system")

    def test_hash_inside_quotes_is_kept(self):
        values = parse_env("KEY=\"abc#def\"\n")
        self.assertEqual(values["KEY"], "abc#def")

    def test_empty_value(self):
        self.assertEqual(parse_env("ELEVENLABS_API_KEY=\n"), {"ELEVENLABS_API_KEY": ""})

    def test_lines_without_equals_are_skipped(self):
        self.assertEqual(parse_env("просто текст\nA=1\n"), {"A": "1"})

    def test_windows_line_endings(self):
        self.assertEqual(parse_env("A=1\r\nB=2\r\n"), {"A": "1", "B": "2"})


class FileTests(unittest.TestCase):
    def test_missing_file_gives_empty_dict(self):
        self.assertEqual(load_env_file("/такого/файлу/немає/.env"), {})

    def test_reads_real_file(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / ".env"
            path.write_text("GLOBE_PLAYER=system\n", encoding="utf-8")
            self.assertEqual(load_env_file(str(path)), {"GLOBE_PLAYER": "system"})

    def test_non_utf8_env_is_a_friendly_config_error(self):
        with tempfile.TemporaryDirectory() as directory:
            (Path(directory) / ".env").write_bytes(b"GLOBE_PLAYER=\xff\xfe\n")
            with self.assertRaises(ConfigError) as caught:
                load_config(root=directory)
        self.assertIn("UTF-8", str(caught.exception))
        self.assertIn(".env", str(caught.exception))


if __name__ == "__main__":
    unittest.main()
