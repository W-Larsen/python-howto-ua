"""Екран 6x14: що справді покаже Nokia 5110."""

import unittest

from globe_core.screen import Screen, sanitize, wrap_words


class SanitizeTests(unittest.TestCase):
    def test_latin_is_kept(self):
        self.assertEqual(sanitize("Kyiv 5!"), "Kyiv 5!")

    def test_cyrillic_becomes_question_marks_per_byte(self):
        # Плата бачить байти UTF-8: кожна українська літера - це два байти.
        self.assertEqual(sanitize("Київ"), "?" * 8)

    def test_clipped_to_width(self):
        self.assertEqual(sanitize("a" * 20), "a" * 14)

    def test_control_characters(self):
        self.assertEqual(sanitize("a\nb"), "a?b")

    def test_numbers_become_text(self):
        self.assertEqual(sanitize(42), "42")


class WrapWordsTests(unittest.TestCase):
    def test_question_is_split_by_words(self):
        self.assertEqual(wrap_words("Where is Tokyo?"), ["Where is", "Tokyo?"])

    def test_long_word_is_cut(self):
        self.assertEqual(wrap_words("a" * 20), ["a" * 14, "a" * 6])

    def test_no_more_than_three_lines(self):
        lines = wrap_words("aaaa bbbb cccc dddd eeee ffff gggg hhhh iiii jjjj")
        self.assertEqual(len(lines), 3)
        for line in lines:
            self.assertLessEqual(len(line), 14)

    def test_extra_spaces_are_ignored(self):
        self.assertEqual(wrap_words("  a   b  "), ["a b"])

    def test_empty(self):
        self.assertEqual(wrap_words(""), [])


class ScreenTests(unittest.TestCase):
    def test_write_and_snapshot(self):
        screen = Screen()
        self.assertTrue(screen.write(0, "Ukraine", inverted=True))
        self.assertTrue(screen.write(5, "x3"))
        self.assertEqual(screen.snapshot(), ("Ukraine", "", "", "", "", "x3"))
        self.assertTrue(screen.inverted[0])

    def test_row_out_of_range(self):
        screen = Screen()
        self.assertFalse(screen.write(6, "a"))
        self.assertFalse(screen.write(-1, "a"))

    def test_clear(self):
        screen = Screen()
        screen.write(1, "a", inverted=True)
        screen.clear()
        self.assertEqual(screen.snapshot(), ("",) * 6)
        self.assertEqual(screen.inverted, [False] * 6)


if __name__ == "__main__":
    unittest.main()
