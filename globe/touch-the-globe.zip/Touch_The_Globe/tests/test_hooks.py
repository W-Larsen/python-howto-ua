"""Таблиця хуків і функцій - спільна для перевірки, перекладача й ядра."""

import unittest

from globe_core.hooks import (
    API,
    BUILTINS,
    HOOK_LIST,
    HOOKS,
    TASK_FILES,
    hooks_for_file,
)

# Слова, які в Arduino вже зайняті макросами або функціями ядра.
ARDUINO_TAKEN = {
    "round", "min", "max", "abs", "constrain", "map", "random", "delay",
    "millis", "bit", "sq", "radians", "degrees", "lowByte", "highByte",
}


class HookTableTests(unittest.TestCase):
    def test_every_task_file_has_hooks(self):
        for file in TASK_FILES:
            self.assertTrue(hooks_for_file(file), file)

    def test_hook_names_are_unique(self):
        names = [hook.name for hook in HOOK_LIST]
        self.assertEqual(len(names), len(set(names)))

    def test_api_names_do_not_clash(self):
        for name in API:
            self.assertNotIn(name, HOOKS)
            self.assertNotIn(name, BUILTINS)
            self.assertNotIn(name, ARDUINO_TAKEN)

    def test_task_numbers(self):
        self.assertEqual(HOOKS["on_button"].task_number, 1)
        self.assertEqual(HOOKS["loading"].task_number, 5)

    def test_only_in_points_to_real_hooks(self):
        for function in API.values():
            if function.only_in is not None:
                self.assertIn(function.only_in, HOOKS)


if __name__ == "__main__":
    unittest.main()
