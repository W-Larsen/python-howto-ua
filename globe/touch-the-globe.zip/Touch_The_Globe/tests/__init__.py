"""Тести проєкту.

Запуск:  python3 -m unittest discover -s tests -v
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
# Шість демо-країн (UA, JP, BR, EG, AU, US) для еталонних розв'язків і паритету
# Python/C++: у самому проєкті лишається лише Україна, решту додає вчитель.
DEMO_COUNTRIES = ROOT / "tests" / "fixtures" / "countries"
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
