"""Документація посилається на те, що справді існує."""

import re
import unittest

from globe_core.hooks import API, HOOK_LIST, TASK_FILES
from tests import ROOT

DOCS = ROOT / "docs"
LINK = re.compile(r"\]\(([^)#]+)(?:#[^)]*)?\)")


class DocsTests(unittest.TestCase):
    def test_guides_exist(self):
        for name in ("student_guide.md", "teacher_guide.md"):
            self.assertTrue((DOCS / name).is_file(), name)
        for file in TASK_FILES:
            self.assertTrue((DOCS / "tasks" / file.replace(".py", ".md")).is_file(), file)

    def test_student_guide_lists_every_api_function(self):
        text = (DOCS / "student_guide.md").read_text(encoding="utf-8")
        for name in API:
            self.assertIn("`{}(".format(name), text, name)

    def test_task_cards_name_their_hooks(self):
        for hook in HOOK_LIST:
            card = (DOCS / "tasks" / hook.file.replace(".py", ".md")).read_text(encoding="utf-8")
            self.assertIn(hook.name, card, hook.file)

    def test_relative_links_point_to_real_files(self):
        pages = [ROOT / "README.md"] + list(DOCS.glob("*.md")) + list((DOCS / "tasks").glob("*.md"))
        for page in pages:
            for target in LINK.findall(page.read_text(encoding="utf-8")):
                if target.startswith("http"):
                    continue
                self.assertTrue((page.parent / target).resolve().exists(), "{} -> {}".format(page.name, target))

    def test_no_references_to_removed_files(self):
        pages = [ROOT / "README.md"] + list(DOCS.glob("*.md")) + list((DOCS / "tasks").glob("*.md"))
        for page in pages:
            text = page.read_text(encoding="utf-8")
            self.assertNotIn("student_code.py", text, page.name)
            self.assertNotIn("make_lcd_line", text, page.name)
            self.assertNotIn("on_repeat_press", text, page.name)


if __name__ == "__main__":
    unittest.main()
