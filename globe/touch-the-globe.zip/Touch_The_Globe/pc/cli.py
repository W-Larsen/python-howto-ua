"""Команди глобуса для комп'ютера.

    globe run              натискати кнопки з клавіатури
    globe press 1 1 3      ніби торкнулися кнопок (q - вікторина, g - гра)
    globe press g 2:600    у грі: відповідь кнопкою 2 за 600 мс
    globe test             перевірити свій код (task1.py ... task5.py)
    globe test task2       перевірити лише один файл
    globe list             які країни є і на яких вони кнопках
    globe build            перекласти код учнів у C++ для плати

На Mac замість globe пиши make: make run, make press 1 1 3, make test.
"""

import argparse
import os
import random
import re
import sys
from pathlib import Path

# Щоб команда працювала з будь-якої папки, а не лише з кореня проєкту.
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from globe_core.catalog import ContentError, load_catalog  # noqa: E402
from globe_core.engine import CRASHED, GAME, QUIZ, GlobeEngine  # noqa: E402
from globe_core.hooks import TASK_FILES  # noqa: E402
from globe_core.language import Context, analyze_task, read_task_sources  # noqa: E402
from globe_core.problems import WARNING, has_errors  # noqa: E402
from globe_core.settings import load_settings  # noqa: E402
from globe_core.student_loader import load_students  # noqa: E402
from pc import audio_local, players  # noqa: E402
from pc.config import MODE_ELEVENLABS, ConfigError, load_config  # noqa: E402
from pc.console_display import ConsoleDisplay  # noqa: E402

USAGE = __doc__.strip()
EXIT_WORDS = ("exit", "quit", "вихід", "вийти")
TOKEN = re.compile(r"^(\d+)(?:[:@](\d+))?$")
# Скільки "думав" гравець у грі, якщо час не вказано: globe press g 2
DEFAULT_MS = 1000
BAD_TOKEN = (
    "Не розумію '{}'. Пиши номер кнопки (1, 2, 3...), q - вікторина, "
    "g - гра, а в грі можна вказати час: 2:600"
)


# ---------------------------------------------------------------------------
# Консоль
# ---------------------------------------------------------------------------
def setup_console():
    """UTF-8 у консолі: інакше у cmd на Windows замість літер будуть знаки питання."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, ValueError):
            pass


def enable_ansi(stream=None):
    """Чи можна перемальовувати кадр на місці (керувати курсором)."""
    stream = stream or sys.stdout
    try:
        if not stream.isatty():
            return False
    except (AttributeError, ValueError):
        return False
    if os.name != "nt":
        return True
    try:
        import ctypes

        kernel32 = ctypes.windll.kernel32
        handle = kernel32.GetStdHandle(-11)
        mode = ctypes.c_uint32()
        if not kernel32.GetConsoleMode(handle, ctypes.byref(mode)):
            return False
        # ENABLE_VIRTUAL_TERMINAL_PROCESSING
        return bool(kernel32.SetConsoleMode(handle, mode.value | 0x0004))
    except Exception:
        return False


def fail(message):
    print("Помилка: " + message)
    return 1


def problem_lines(problems):
    lines = []
    for problem in problems:
        label = "увага" if problem.level == WARNING else "помилка"
        lines.append("[{}] {}".format(label, problem))
    return lines


class Paths:
    def __init__(self, root):
        self.root = Path(root)
        self.settings = self.root / "settings.py"
        self.students = self.root / "students"


def parse_token(text):
    """'1' -> кнопка 1, '3:600' -> кнопка 3 за 600 мс, 'q' - вікторина, 'g' - гра."""
    word = text.strip().lower()
    if word == "q":
        return ("quiz", None, None)
    if word == "g":
        return ("game", None, None)
    match = TOKEN.match(word)
    if match is None:
        return None
    ms = int(match.group(2)) if match.group(2) else None
    return ("button", int(match.group(1)), ms)


# ---------------------------------------------------------------------------
# Збирання глобуса
# ---------------------------------------------------------------------------
def build_audio_source(config, warn):
    if config.audio_mode == MODE_ELEVENLABS:
        from pc.audio_elevenlabs import ElevenLabsAudioSource

        return ElevenLabsAudioSource(config, warn=warn)
    return audio_local.LocalAudioSource(config, warn=warn)


def build_speaker(config, player, warn):
    # blocking=False: нове торкання перебиває попередній запис, як на глобусі.
    if config.audio_mode == MODE_ELEVENLABS:
        from pc.audio_elevenlabs import TalkingSpeaker

        return TalkingSpeaker(config, player, blocking=False, warn=warn)
    return players.PcSpeaker(player, blocking=False)


def build_globe(config, paths, display, realtime, hints=False):
    """Глобус із консольним дисплеєм і звуком. Повертає (ядро, колонка, проблеми).

    hints=True додає підказки на кшталт «(загадано: JP — кнопка 2)»: вони
    потрібні для press (там відповіді задаєш наперед), але псують гру в run.
    """
    catalog = load_catalog(str(config.countries_dir))
    settings, problems = load_settings(paths.settings)

    def warn(message):
        display.note("[увага] " + message)

    player = players.create_player(config.player, warn=warn)
    speaker = build_speaker(config, player, warn)
    engine = GlobeEngine(
        catalog,
        settings,
        display=display,
        speaker=speaker,
        audio_source=build_audio_source(config, warn),
        sleep=None if realtime else (lambda seconds: None),
        on_warning=warn,
        on_note=display.note if hints else None,
    )
    api = engine.api()
    # print() з коду учня теж іде через дисплей, щоб не ламати анімацію.
    api["print"] = lambda *args: display.note(" ".join(str(arg) for arg in args))
    context = Context(catalog.ids(), settings.button_count)
    code = load_students(paths.students, api, context, engine.loop_stuck)
    engine.set_hooks(code.hooks)
    return engine, speaker, problems + code.problems


def quiet_engine(catalog, settings, students_dir, warnings):
    """Глобус без екрана, звуку й пауз - для перевірок."""
    engine = GlobeEngine(
        catalog,
        settings,
        sleep=lambda seconds: None,
        rng=random.Random(7),
        on_warning=warnings.append,
    )
    api = engine.api()
    api["print"] = lambda *args: None
    context = Context(catalog.ids(), settings.button_count)
    code = load_students(students_dir, api, context, engine.loop_stuck)
    engine.set_hooks(code.hooks)
    return engine


def smoke_run(catalog, settings, students_dir):
    """Проганяє всі хуки учнів: кнопки, факти, гру, вікторину.

    Повертає попередження, які глобус видав по дорозі (помилки в коді,
    задовгі тексти, нескінченні цикли). Про відсутні файли не каже -
    це нормально, коли кожен учень перевіряє лише своє.
    """
    warnings = []
    engine = quiet_engine(catalog, settings, students_dir, warnings)
    count = settings.button_count

    engine.boot()
    for number in range(1, count + 1):
        engine.touch_button(number)
    for country in catalog:
        engine.show_country(country.id)

    # Кожну кнопку пробуємо по черзі: перша, що показує країну, завершує
    # раунд. Цикл обмежений, тож гра без жодної відповіді нас не затримає.
    engine.touch_game()
    for _ in range(settings.game_rounds * count):
        if engine.mode != GAME:
            break
        for number in range(1, count + 1):
            engine.touch_button(number, ms=500)
            if engine.mode != GAME:
                break
    # Якщо жодна кнопка не показує загадану країну - завершуємо раунди тайм-аутом.
    for _ in range(settings.game_rounds):
        if engine.mode != GAME:
            break
        engine.timeout_round()

    engine.touch_quiz()
    for step in range(60):
        if engine.mode != QUIZ:
            break
        engine.touch_button(step % count + 1)

    return [message for message in warnings if not message.startswith("немає task")]


def wait_for_sound(speaker):
    try:
        speaker.wait()
    except KeyboardInterrupt:
        speaker.stop()
    except AttributeError:
        pass


# ---------------------------------------------------------------------------
# Команди
# ---------------------------------------------------------------------------
def command_press(config, paths, args):
    if not args.keys:
        print("Після press напиши, які кнопки натиснути: globe press 1 2 (q - вікторина, g - гра)")
        return 1
    tokens = []
    for raw in args.keys:
        token = parse_token(raw)
        if token is None:
            print(BAD_TOKEN.format(raw))
            return 1
        tokens.append((raw, token))

    display = ConsoleDisplay()
    engine, speaker, problems = build_globe(config, paths, display, realtime=False, hints=True)
    for line in problem_lines(problems):
        display.note(line)

    engine.boot()
    for raw, (kind, number, ms) in tokens:
        display.note("> натискаю " + raw)
        if kind == "quiz":
            engine.touch_quiz()
        elif kind == "game":
            engine.touch_game()
        else:
            if ms is None and engine.mode == GAME:
                ms = DEFAULT_MS
            engine.touch_button(number, ms)
    wait_for_sound(speaker)
    return 0


def command_run(config, paths, args):
    display = ConsoleDisplay(animate=enable_ansi())
    engine, speaker, problems = build_globe(config, paths, display, realtime=True, hints=False)
    for line in problem_lines(problems):
        display.note(line)

    print(
        "Глобус запущено. 1-{} - кнопки країн, q - вікторина, g - «Блискавка».".format(
            engine.settings.button_count
        )
    )
    print("list - країни, help - довідка, exit або Ctrl+C - вихід.")
    engine.boot()
    try:
        while True:
            try:
                raw = input("> ").strip()
            except EOFError:
                break
            display.interrupt()
            word = raw.lower()
            if not word:
                continue
            if word in EXIT_WORDS:
                break
            if word == "list":
                print("  " + ", ".join(engine.catalog.ids()))
                continue
            if word == "help":
                print(USAGE)
                continue
            token = parse_token(word)
            if token is None:
                print(BAD_TOKEN.format(raw))
                continue
            kind, number, ms = token
            if kind == "quiz":
                engine.touch_quiz()
            elif kind == "game":
                engine.touch_game()
            else:
                engine.touch_button(number, ms)
    except KeyboardInterrupt:
        print()
    finally:
        try:
            speaker.stop()
        except Exception:
            pass
    print("Бувай!")
    return 0


def task_file(name):
    """'task2', '2', 'task2.py' -> 'task2.py' або None."""
    word = name.strip().lower()
    if word.isdigit():
        word = "task" + word
    if not word.endswith(".py"):
        word += ".py"
    return word if word in TASK_FILES else None


def command_test(config, paths, args):
    wanted = None
    if args.task:
        wanted = task_file(args.task)
        if wanted is None:
            print("Не знаю задачі '{}'. Є: {}".format(args.task, ", ".join(TASK_FILES)))
            return 1

    catalog = load_catalog(str(config.countries_dir))
    settings, settings_problems = load_settings(paths.settings)
    errors = 0
    warnings = 0

    def report(problems):
        nonlocal errors, warnings
        for problem in problems:
            if problem.is_error:
                errors += 1
            else:
                warnings += 1
        for line in problem_lines(problems):
            print("  " + line)

    print("=== Налаштування (settings.py) ===")
    if settings_problems:
        report(settings_problems)
    else:
        print("  усе гаразд")

    print()
    print("=== Задачі ===")
    sources, read_problems = read_task_sources(paths.students)
    # Про одну задачу - лише її проблеми (і спільні, без файлу, як-от немає папки).
    if wanted is not None:
        read_problems = [
            problem for problem in read_problems if problem.file in (None, wanted)
        ]
    report(read_problems)
    unreadable = {problem.file for problem in read_problems if problem.is_error}
    renamed = {problem.file for problem in read_problems if not problem.is_error}
    context = Context(catalog.ids(), settings.button_count)
    for file in TASK_FILES:
        if wanted is not None and file != wanted:
            continue
        if file not in sources:
            if file in unreadable:
                print("{}: файл є, але його не вдалося прочитати - див. помилку вище".format(file))
            elif file in renamed:
                print("{}: файлу з такою назвою немає, але є схожий - див. попередження вище".format(file))
            else:
                print("{}: файлу немає - це нормально, якщо цю задачу робить хтось інший".format(file))
            continue
        info, problems = analyze_task(file, sources[file], context)
        if problems:
            print(file + ":")
            report(problems)
        else:
            names = ", ".join(name + "()" for name in info.functions) or "функцій немає"
            print("{}: усе гаразд ({})".format(file, names))

    print()
    print("=== Пробний запуск ===")
    smoke = smoke_run(catalog, settings, paths.students)
    if smoke:
        for message in smoke:
            # Хук, що впав, на платі поведеться інакше (ділення на нуль дасть 0,
            # нескінченний виклик зламає плату) - це помилка, а не дрібниця.
            if CRASHED in message:
                errors += 1
                print("  [помилка] " + message)
            else:
                warnings += 1
                print("  [увага] " + message)
    else:
        print("  глобус відпрацював усі кнопки й ігри без зауважень")

    print()
    print("Помилок: {}, попереджень: {}".format(errors, warnings))
    if errors:
        print("Виправ помилки - інакше цей код не потрапить на глобус.")
        return 1
    print("Можна надсилати вчителю!")
    return 0


def command_list(config, paths, args):
    catalog = load_catalog(str(config.countries_dir))
    settings, _ = load_settings(paths.settings)
    warnings = []
    engine = quiet_engine(catalog, settings, paths.students, warnings)

    if not len(catalog):
        print("У папці {} немає жодної країни.".format(config.countries_dir))
        return 0

    rows = [("ID", "КРАЇНА", "НА ЕКРАНІ", "КНОПКА", "АУДІО")]
    for country in catalog:
        audio = audio_local.find_audio_file(config.audio_dir, country.id)
        if audio is None and config.audio_mode == MODE_ELEVENLABS:
            audio = audio_local.find_audio_file(config.tts_cache_dir, country.id)
        button = engine.button_for(country.id)
        rows.append(
            (
                country.id,
                country.name,
                "{} / {}".format(country.lcd_name, country.lcd_capital),
                str(button) if button is not None else "-",
                "є" if audio else "немає",
            )
        )

    widths = [max(len(row[index]) for row in rows) for index in range(len(rows[0]))]
    for index, row in enumerate(rows):
        print("  ".join(row[column].ljust(widths[column]) for column in range(len(row))).rstrip())
        if index == 0:
            print("  ".join("-" * width for width in widths))
    print()
    print("Кнопку показує task1.py (on_button). Пін кожної кнопки - у settings.py.")
    return 0


def command_build(config, paths, args):
    try:
        from tools.build_student_code import main as build_main
    except ImportError:
        print("Перекладач у C++ ще не готовий (tools/build_student_code.py).")
        return 1
    return build_main(["--root", str(paths.root)])


def command_help(config, paths, args):
    print(USAGE)
    return 0


# ---------------------------------------------------------------------------
# Точка входу
# ---------------------------------------------------------------------------
def build_parser():
    parser = argparse.ArgumentParser(prog="globe", description="Touch The Globe на комп'ютері.")
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("run", help="натискати кнопки з клавіатури")
    press = subparsers.add_parser("press", help="ніби торкнулися кнопок")
    press.add_argument("keys", nargs="*", help="1 2 3, q - вікторина, g - гра, 2:600 - час у грі")
    test = subparsers.add_parser("test", help="перевірити код учнів")
    test.add_argument("task", nargs="?", help="одна задача: task2")
    subparsers.add_parser("list", help="країни та кнопки")
    subparsers.add_parser("build", help="перекласти код учнів у C++ для плати")
    subparsers.add_parser("help", help="довідка")
    return parser


COMMANDS = {
    "run": command_run,
    "press": command_press,
    "test": command_test,
    "list": command_list,
    "build": command_build,
    "help": command_help,
}


def main(argv=None, root=None):
    setup_console()
    args = build_parser().parse_args(argv)
    if not args.command:
        print(USAGE)
        return 0

    paths = Paths(root or ROOT)
    try:
        config = load_config(root=paths.root)
    except ConfigError as exc:
        return fail(str(exc))

    try:
        return COMMANDS[args.command](config, paths, args)
    except ContentError as exc:
        return fail(str(exc))
    except KeyboardInterrupt:
        print()
        return 130


if __name__ == "__main__":
    sys.exit(main())
