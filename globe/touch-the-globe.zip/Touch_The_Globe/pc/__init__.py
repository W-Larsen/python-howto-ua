"""Версія Touch The Globe для комп'ютера."""
