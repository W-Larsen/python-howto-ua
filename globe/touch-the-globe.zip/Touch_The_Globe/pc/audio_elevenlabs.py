"""Озвучення тексту голосом через ElevenLabs (GLOBE_AUDIO_MODE=elevenlabs).

Використовується лише urllib зі стандартної бібліотеки, щоб школі не
довелося встановлювати SDK.

Безкоштовний тариф ElevenLabs дає 10 000 символів на місяць, а один символ
тексту = один кредит. Тому все, що вже озвучено, зберігається у
content/audio_tts/uk/ і другий раз не генерується.
"""

import hashlib
import json
import urllib.error
import urllib.request

from pc.audio_local import find_audio_file
from pc.players import PcSpeaker

API_URL = "https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
OUTPUT_FORMAT = "mp3_44100_128"
TIMEOUT_SECONDS = 60


class ElevenLabsError(Exception):
    """Повідомлення українською - його читатимуть учні."""


def _friendly_http_error(exc, config):
    """Перетворює код відповіді сервера в зрозумілу пораду."""
    if exc.code == 401:
        return ElevenLabsError(
            "ElevenLabs не прийняв ключ (401).\n"
            "  Перевір ELEVENLABS_API_KEY у файлі .env - можливо, скопіювався\n"
            "  з пробілом або ключ уже видалено.\n"
            "  Новий ключ: https://elevenlabs.io/app/settings/api-keys"
        )
    if exc.code == 422:
        return ElevenLabsError(
            "ElevenLabs не зрозумів запит (422).\n"
            "  Найчастіша причина - неправильний ELEVENLABS_VOICE_ID.\n"
            "  Вибери голос тут: https://elevenlabs.io/app/voice-library\n"
            "  Зараз вказано: {}".format(config.elevenlabs_voice_id or "(порожньо)")
        )
    if exc.code == 429:
        return ElevenLabsError(
            "Забагато запитів або скінчилися безкоштовні кредити (429).\n"
            "  На безкоштовному тарифі це 10 000 символів на місяць.\n"
            "  Залишок видно тут: https://elevenlabs.io/app/usage\n"
            "  Порада: озвучуй по одній країні, а не всі одразу."
        )

    details = ""
    try:
        body = exc.read().decode("utf-8", "replace")
        if body:
            details = "\n  Відповідь сервера: " + body[:400]
    except Exception:
        pass
    return ElevenLabsError(
        "ElevenLabs відповів помилкою {} {}.{}".format(exc.code, exc.reason, details)
    )


class ElevenLabsClient:
    """Найтонша обгортка над одним запитом до API."""

    def __init__(self, config):
        self.config = config

    def check_ready(self):
        if not self.config.elevenlabs_api_key:
            raise ElevenLabsError(
                "Немає ключа ElevenLabs.\n"
                "  1. Зареєструйся на https://elevenlabs.io (безкоштовно)\n"
                "  2. Візьми ключ тут: "
                "https://elevenlabs.io/app/settings/api-keys\n"
                "  3. Впиши його у файл .env:  ELEVENLABS_API_KEY=твій_ключ"
            )
        if not self.config.elevenlabs_voice_id:
            raise ElevenLabsError(
                "Не вказано ELEVENLABS_VOICE_ID у файлі .env.\n"
                "  Голоси: https://elevenlabs.io/app/voice-library"
            )

    def synthesize(self, text):
        """Повертає готовий mp3 у вигляді байтів."""
        self.check_ready()

        url = API_URL.format(voice_id=self.config.elevenlabs_voice_id)
        url += "?output_format=" + OUTPUT_FORMAT
        payload = json.dumps(
            {"text": text, "model_id": self.config.elevenlabs_model_id}
        ).encode("utf-8")

        request = urllib.request.Request(
            url,
            data=payload,
            method="POST",
            headers={
                "xi-api-key": self.config.elevenlabs_api_key,
                "Content-Type": "application/json",
                "Accept": "audio/mpeg",
            },
        )

        try:
            with urllib.request.urlopen(request, timeout=TIMEOUT_SECONDS) as response:
                audio = response.read()
        except urllib.error.HTTPError as exc:
            raise _friendly_http_error(exc, self.config)
        except urllib.error.URLError as exc:
            raise ElevenLabsError(
                "Не вдалося зв'язатися з ElevenLabs: {}\n"
                "  Перевір інтернет. Якщо інтернету немає, постав у .env\n"
                "  GLOBE_AUDIO_MODE=prerecorded - тоді гратимуть записані файли.".format(
                    exc.reason
                )
            )

        if not audio:
            raise ElevenLabsError("ElevenLabs повернув порожній файл.")
        return audio


class TextToSpeech:
    """Озвучення з кешем на диску."""

    def __init__(self, config, warn=None):
        self.config = config
        self.client = ElevenLabsClient(config)
        self._warn = warn

    # -- країни --------------------------------------------------------
    def country_path(self, country):
        return self.config.tts_cache_dir / (country.id + ".mp3")

    def cached_country(self, country):
        """Готове аудіо країни: спочатку записане вручну, потім кеш."""
        manual = find_audio_file(self.config.audio_dir, country.id)
        if manual is not None:
            return manual
        path = self.country_path(country)
        return path if path.is_file() else None

    def ensure_country(self, country, force=False):
        """Повертає шлях до аудіо країни, за потреби озвучивши текст."""
        if not force:
            existing = self.cached_country(country)
            if existing is not None:
                return existing
        return self._write(self.country_path(country), country.text)

    # -- довільний текст (для сюрпризів) -------------------------------
    def phrase_path(self, text):
        digest = hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]
        return self.config.tts_cache_dir / "phrases" / (digest + ".mp3")

    def ensure_phrase(self, text):
        path = self.phrase_path(text)
        if path.is_file():
            return path
        return self._write(path, text)

    # -- спільне -------------------------------------------------------
    def _write(self, path, text):
        audio = self.client.synthesize(text)
        path.parent.mkdir(parents=True, exist_ok=True)
        # Спочатку в тимчасовий файл: якщо програму перервати посеред запису,
        # у кеші не залишиться битого mp3, який потім складно знайти.
        temporary = path.with_suffix(".part")
        temporary.write_bytes(audio)
        temporary.replace(path)
        return path


class ElevenLabsAudioSource:
    """Джерело аудіо для движка: озвучує текст країни за потреби."""

    def __init__(self, config, warn=None, tts=None):
        self.config = config
        self.tts = tts or TextToSpeech(config, warn=warn)
        self._warn = warn
        self._failed = set()

    def resolve(self, country):
        if country.id in self._failed:
            return self.tts.cached_country(country)
        try:
            return self.tts.ensure_country(country)
        except ElevenLabsError as exc:
            self._failed.add(country.id)
            if self._warn is not None:
                self._warn(str(exc))
            return self.tts.cached_country(country)


class TalkingSpeaker(PcSpeaker):
    """Колонка, яка вміє озвучити будь-який текст, а не лише готові файли.

    Саме через метод say() звучать сюрпризи з on_repeat_press().
    На платі такого немає: DFPlayer грає тільки заздалегідь записані треки.
    """

    def __init__(self, config, player, blocking=False, warn=None, tts=None):
        PcSpeaker.__init__(self, player, blocking=blocking)
        self.tts = tts or TextToSpeech(config, warn=warn)
        self._warn = warn

    def say(self, text):
        # Помилку навмисно не ховаємо: движок її перехопить і замість
        # сюрпризу програє звичайний факт про країну.
        self.play(self.tts.ensure_phrase(text))
