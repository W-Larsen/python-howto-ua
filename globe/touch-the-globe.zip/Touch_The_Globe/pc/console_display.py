"""Виведення в консоль.

Малює рамку рівно такої ширини, як справжній екран Nokia 5110: 6 рядків
по 14 символів. Рядок "білим по чорному" (назва країни) обведено
жирною рамкою. Так одразу видно, чи вміщається написане.

Коли консоль уміє керувати курсором (animate=True), наступний кадр
малюється на місці попереднього - смужка завантаження росте, а не
біжить униз екраном.
"""

import sys

from globe_core.screen import WIDTH

TOP = "┌" + "─" * WIDTH + "┐"
BOTTOM = "└" + "─" * WIDTH + "┘"


def render_screen(screen):
    """Рядки рамки - завжди рівно вісім, щоб кадр можна було перемалювати."""
    lines = [TOP]
    for index, text in enumerate(screen.rows):
        edge = "┃" if screen.inverted[index] else "│"
        lines.append(edge + text.ljust(WIDTH) + edge)
    lines.append(BOTTOM)
    return lines


class ConsoleDisplay:
    """Дисплей = вікно термінала."""

    def __init__(self, stream=None, animate=False):
        self.stream = stream
        self.animate = animate
        self._last = None
        self._can_redraw = False

    def _out(self):
        return self.stream if self.stream is not None else sys.stdout

    def _write(self, text):
        self._out().write(text + "\n")

    def refresh(self, screen):
        lines = render_screen(screen)
        if lines == self._last:
            return
        if self.animate and self._can_redraw:
            # Курсор на вісім рядків угору - і малюємо поверх старого кадру.
            self._out().write("\x1b[{}F".format(len(lines)))
        for line in lines:
            self._write(line)
        self._out().flush()
        self._last = lines
        self._can_redraw = True

    def blink(self, times):
        self._write("  (підсвітка мигнула: {}x)".format(times))
        self._can_redraw = False
        self._last = None

    def note(self, text):
        self._write("  " + text)
        self._can_redraw = False
        # Однаковий кадр після нотатки має знову з'явитися на екрані.
        self._last = None

    def interrupt(self):
        """Після будь-якого іншого виводу в консоль перемальовувати не можна."""
        self._can_redraw = False
        self._last = None
