"""Чим програвати звук на комп'ютері.

За замовчуванням використовується той плеєр, який уже є в системі
(afplay на macOS, ffplay або mpg123 на Linux), щоб школі не довелося
нічого встановлювати через pip.
"""

import shutil
import subprocess
import sys

# Команди, які вміють програти mp3 з командного рядка.
# Перша знайдена в системі і буде використана.
CANDIDATES = (
    # macOS - є завжди, нічого встановлювати не треба
    ("afplay", ["afplay", "{file}"]),
    # Linux / будь-де, де стоїть ffmpeg
    ("ffplay", ["ffplay", "-nodisp", "-autoexit", "-loglevel", "quiet", "{file}"]),
    ("mpg123", ["mpg123", "-q", "{file}"]),
    ("mpv", ["mpv", "--no-video", "--really-quiet", "{file}"]),
    ("cvlc", ["cvlc", "--play-and-exit", "--intf", "dummy", "{file}"]),
)


# У Windows немає консольного mp3-плеєра, зате є PowerShell, а в ньому -
# той самий програвач, що й у Windows Media Player. Скрипт чекає, поки
# запис догра, щоб wait() і stop() працювали так само, як з afplay.
WINDOWS_PLAYER = (
    "powershell",
    [
        "powershell",
        "-NoProfile",
        "-NonInteractive",
        "-Command",
        "Add-Type -AssemblyName PresentationCore; "
        "$p = New-Object System.Windows.Media.MediaPlayer; "
        "$p.Open([Uri]'{file}'); $p.Play(); Start-Sleep -Milliseconds 500; "
        "while ($p.NaturalDuration.HasTimeSpan -and "
        "$p.Position -lt $p.NaturalDuration.TimeSpan) {{ Start-Sleep -Milliseconds 200 }}",
    ],
    # У PowerShell апостроф усередині '...' пишеться двічі: Обов''язково.
    lambda path: path.replace("'", "''"),
)


def candidates(platform=None):
    """(назва, команда, escape) усіх плеєрів, які варто шукати на цій системі."""
    platform = platform or sys.platform
    found = [(name, command, None) for name, command in CANDIDATES]
    if platform.startswith("win"):
        found.append(WINDOWS_PLAYER)
    return tuple(found)


class PlayerError(Exception):
    pass


class NullPlayer:
    """Не грає нічого. Використовується для GLOBE_PLAYER=none і в тестах."""

    name = "none"
    available = True

    def play(self, path):
        pass

    def wait(self):
        pass

    def stop(self):
        pass

    def describe(self):
        return "звук вимкнено (GLOBE_PLAYER=none)"


class SystemPlayer:
    """Запускає системний плеєр окремим процесом (не блокує програму)."""

    available = True

    def __init__(self, name, command, escape=None):
        self.name = name
        self.command = command
        # Як підготувати шлях до файлу для цієї програми (лапки тощо).
        self.escape = escape
        self._process = None

    def command_for(self, path):
        path = str(path)
        if self.escape is not None:
            path = self.escape(path)
        return [part.format(file=path) for part in self.command]

    def play(self, path):
        self.stop()
        command = self.command_for(path)
        try:
            self._process = subprocess.Popen(
                command,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
        except OSError as exc:
            raise PlayerError(
                "Не вдалося запустити плеєр '{}': {}".format(self.name, exc)
            )

    def wait(self):
        """Чекає, поки запис догра до кінця."""
        if self._process is None:
            return
        try:
            self._process.wait()
        except KeyboardInterrupt:
            self.stop()
            raise
        finally:
            self._process = None

    def stop(self):
        if self._process is None:
            return
        if self._process.poll() is None:
            self._process.terminate()
            try:
                self._process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self._process.kill()
        self._process = None

    def describe(self):
        return "системний плеєр '{}'".format(self.name)


class PygamePlayer:
    """Резервний варіант через pygame - потрібен переважно на Windows."""

    name = "pygame"
    available = True

    def __init__(self):
        try:
            import pygame
        except ImportError:
            raise PlayerError(
                "GLOBE_PLAYER=pygame, але pygame не встановлено.\n"
                "  Встанови його командою:  pip install pygame-ce"
            )
        self._pygame = pygame
        try:
            pygame.mixer.init()
        except Exception as exc:
            raise PlayerError("Не вдалося увімкнути звук через pygame: {}".format(exc))

    def play(self, path):
        self._pygame.mixer.music.load(str(path))
        self._pygame.mixer.music.play()

    def wait(self):
        clock = self._pygame.time.Clock()
        while self._pygame.mixer.music.get_busy():
            clock.tick(20)

    def stop(self):
        try:
            self._pygame.mixer.music.stop()
        except Exception:
            pass

    def describe(self):
        return "pygame"


def find_system_player():
    """Перший доступний системний плеєр або None."""
    for name, command, escape in candidates():
        if shutil.which(command[0]):
            return SystemPlayer(name, command, escape=escape)
    return None


def install_hint():
    if sys.platform == "darwin":
        return "На macOS afplay має бути завжди - спробуй GLOBE_PLAYER=system."
    if sys.platform.startswith("win"):
        return (
            "На Windows звук грає через PowerShell. Якщо його не чути - перевір "
            "гучність, або постав pygame-ce і GLOBE_PLAYER=pygame у .env."
        )
    return (
        "На Linux встанови один із плеєрів, наприклад:\n"
        "  sudo apt install ffmpeg      (дає ffplay)\n"
        "  sudo apt install mpg123"
    )


def create_player(choice="auto", warn=None):
    """Створює плеєр за значенням GLOBE_PLAYER із .env.

    Якщо звук увімкнути не вдалося, повертає NullPlayer: текст усе одно
    покажеться, а учень побачить підказку, що саме встановити.
    """
    choice = (choice or "auto").lower()

    def complain(message):
        if warn is not None:
            warn(message)

    if choice == "none":
        return NullPlayer()

    if choice == "pygame":
        try:
            return PygamePlayer()
        except PlayerError as exc:
            complain(str(exc))
            return NullPlayer()

    if choice == "system":
        player = find_system_player()
        if player is not None:
            return player
        complain(
            "Не знайдено жодного системного плеєра.\n" + install_hint()
        )
        return NullPlayer()

    if choice != "auto":
        complain(
            "У .env вказано GLOBE_PLAYER={}, а можливі значення: "
            "auto, system, pygame, none. Використовую auto.".format(choice)
        )

    player = find_system_player()
    if player is not None:
        return player
    try:
        return PygamePlayer()
    except PlayerError:
        pass
    complain("Звук програти нічим, буде лише текст.\n" + install_hint())
    return NullPlayer()


class PcSpeaker:
    """Колонка комп'ютера: вміє програвати готові файли.

    Довільний текст говорити не вміє - для цього потрібен режим elevenlabs
    (див. pc/audio_elevenlabs.py).
    """

    def __init__(self, player, blocking=False):
        self.player = player
        self.blocking = blocking
        self.last_played = None

    def play(self, audio_ref):
        if audio_ref is None:
            return
        self.last_played = audio_ref
        self.player.play(audio_ref)
        if self.blocking:
            self.player.wait()

    def wait(self):
        self.player.wait()

    def stop(self):
        self.player.stop()
