"""Пошук заздалегідь записаних аудіофайлів (режим GLOBE_AUDIO_MODE=prerecorded).

Файл для країни з ID "UA" шукається як content/audio/UA.mp3.
Регістр назви не важливий, розширення може бути й іншим.
"""

EXTENSIONS = (".mp3", ".wav", ".ogg", ".m4a", ".flac")


def find_audio_file(directory, country_id):
    """Шукає аудіо для країни в папці. Повертає Path або None."""
    if not directory.is_dir():
        return None

    wanted = country_id.upper()
    for extension in EXTENSIONS:
        candidate = directory / (country_id + extension)
        if candidate.is_file():
            return candidate

    # Назва файлу могла бути написана іншим регістром - ua.mp3, Ua.MP3 тощо.
    for path in sorted(directory.iterdir()):
        if not path.is_file():
            continue
        if path.suffix.lower() not in EXTENSIONS:
            continue
        if path.stem.upper() == wanted:
            return path
    return None


class LocalAudioSource:
    """Віддає шлях до записаного файлу; якщо його немає - None."""

    def __init__(self, config, warn=None):
        self.config = config
        self._warn = warn
        self._missing_reported = set()

    def resolve(self, country):
        path = find_audio_file(self.config.audio_dir, country.id)
        if path is None:
            self._report_missing(country)
            return None
        return path

    def _report_missing(self, country):
        if country.id in self._missing_reported:
            return
        self._missing_reported.add(country.id)
        if self._warn is None:
            return
        self._warn(
            "Немає аудіо для країни {} ({}).\n"
            "         Поклади запис у {}/{}.mp3\n"
            "         або згенеруй голос: python3 tools/generate_audio.py {}".format(
                country.id,
                country.name,
                self.config.audio_dir,
                country.id,
                country.id,
            )
        )
