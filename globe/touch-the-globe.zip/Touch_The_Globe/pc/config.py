"""Налаштування ПК-версії: читаються з .env і зі змінних оточення."""

import os
from pathlib import Path

from globe_core.envfile import load_env_file

MODE_PRERECORDED = "prerecorded"
MODE_ELEVENLABS = "elevenlabs"
AUDIO_MODES = (MODE_PRERECORDED, MODE_ELEVENLABS)

DEFAULTS = {
    "GLOBE_AUDIO_MODE": MODE_PRERECORDED,
    "GLOBE_CONTENT_DIR": "content",
    "GLOBE_PLAYER": "auto",
    "ELEVENLABS_API_KEY": "",
    "ELEVENLABS_VOICE_ID": "21m00Tcm4TlvDq8ikWAM",
    "ELEVENLABS_MODEL_ID": "eleven_multilingual_v2",
}


class ConfigError(Exception):
    """Помилка в налаштуваннях. Повідомлення - українською, для учнів."""


def project_root():
    """Корінь проєкту - папка, у якій лежить settings.py."""
    return Path(__file__).resolve().parent.parent


class Config:
    def __init__(self, values, root):
        self.root = root
        self._values = values

        self.audio_mode = values["GLOBE_AUDIO_MODE"].strip().lower()
        if self.audio_mode not in AUDIO_MODES:
            raise ConfigError(
                "У .env вказано GLOBE_AUDIO_MODE={}, а можливі лише: {}".format(
                    self.audio_mode, " або ".join(AUDIO_MODES)
                )
            )

        self.player = values["GLOBE_PLAYER"].strip().lower() or "auto"

        content = Path(values["GLOBE_CONTENT_DIR"].strip() or "content")
        self.content_dir = content if content.is_absolute() else root / content

        self.elevenlabs_api_key = values["ELEVENLABS_API_KEY"].strip()
        self.elevenlabs_voice_id = values["ELEVENLABS_VOICE_ID"].strip()
        self.elevenlabs_model_id = values["ELEVENLABS_MODEL_ID"].strip()

    # -- шляхи ---------------------------------------------------------
    @property
    def countries_dir(self):
        return self.content_dir / "countries"

    @property
    def audio_dir(self):
        """Записані вручну mp3."""
        return self.content_dir / "audio"

    @property
    def tts_cache_dir(self):
        """Кеш озвучення від ElevenLabs."""
        return self.content_dir / "audio_tts"

    @property
    def track_map_path(self):
        return self.content_dir / ".track_map.json"

    @property
    def sd_card_dir(self):
        return self.root / "sd_card"

    @property
    def env_path(self):
        return self.root / ".env"

    def describe(self):
        return {
            "GLOBE_AUDIO_MODE": self.audio_mode,
            "GLOBE_CONTENT_DIR": str(self.content_dir),
            "GLOBE_PLAYER": self.player,
            "ELEVENLABS_API_KEY": "вказано" if self.elevenlabs_api_key else "немає",
            "ELEVENLABS_VOICE_ID": self.elevenlabs_voice_id or "немає",
            "ELEVENLABS_MODEL_ID": self.elevenlabs_model_id or "немає",
        }


def load_config(root=None, overrides=None):
    """Збирає налаштування: спочатку дефолти, потім .env, потім оточення.

    Змінні оточення мають вищий приоритет за .env, щоб можна було
    запустити разово по-іншому:

        GLOBE_AUDIO_MODE=elevenlabs python3 -m pc.cli play UA
    """
    root = Path(root) if root else project_root()

    values = dict(DEFAULTS)
    try:
        values.update(load_env_file(str(root / ".env")))
    except UnicodeDecodeError:
        raise ConfigError(
            "Файл .env збережено не в кодуванні UTF-8. "
            "У Блокноті: Файл -> Зберегти як -> Кодування: UTF-8."
        )

    for key in DEFAULTS:
        from_environ = os.environ.get(key)
        if from_environ is not None:
            values[key] = from_environ

    if overrides:
        values.update(overrides)

    return Config(values, root)
