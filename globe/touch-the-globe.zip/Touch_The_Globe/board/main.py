"""Головний файл програми. Запускається сам, коли плата отримує живлення.

Цей файл виконується вже НА ПЛАТІ, тому шляхи тут інші, ніж на комп'ютері:
tools/sync_board.py копіює потрібні файли так, щоб на платі вони лежали
поруч у корені:

    /main.py                <- цей файл
    /student_code.py        <- твій код
    /hardware_pins.py       <- твої піни
    /globe_core/            <- спільне ядро (те саме, що на комп'ютері)
    /drivers/               <- дисплей, аудіомодуль, кнопки
    /content/countries/     <- файли країн

Найважливіше: рядок GlobeEngine(...) нижче - точно такий самий, як у
версії для комп'ютера. Уся різниця лише в тому, що замість консолі
й колонок підставлені дисплей і DFPlayer.
"""

import time

import hardware_pins
from drivers.buttons import ButtonPanel
from drivers.dfplayer import DFPlayer, DFPlayerSpeaker, make_uart
from drivers.lcd1602_i2c import Lcd1602, Lcd1602Display, describe_scan, make_i2c
from drivers.pins import PinError
from globe_core.catalog import ContentError, load_catalog
from globe_core.engine import GlobeEngine
from globe_core.fakes import NullDisplay, NullSpeaker, TrackAudioSource

COUNTRIES_DIR = "content/countries"

# Скільки разів на секунду опитувати кнопки.
POLL_INTERVAL_MS = 20


def log(message):
    """Пише в USB-консоль: видно в Arduino Lab for MicroPython."""
    print(message)


def load_student_code():
    """Підключає код учня, не падаючи від його помилок."""
    try:
        import student_code

        return student_code
    except SyntaxError as exc:
        log("[увага] У student_code.py помилка в тексті програми: " + str(exc))
    except ImportError:
        log("[увага] На платі немає файлу student_code.py")
    except Exception as exc:
        log("[увага] student_code.py не запустився: " + str(exc))
    log("         Глобус працюватиме без твого коду.")
    return None


def setup_display():
    """Дисплей. Якщо його немає, глобус усе одно грає звук."""
    try:
        i2c = make_i2c(hardware_pins.I2C_SDA, hardware_pins.I2C_SCL)
    except PinError as exc:
        log("[увага] Піни I2C у hardware_pins.py вказані неправильно:")
        log(str(exc))
        return None, NullDisplay()

    try:
        lcd = Lcd1602(
            i2c,
            address=hardware_pins.LCD_ADDRESS,
            columns=hardware_pins.LCD_COLUMNS,
            rows=hardware_pins.LCD_ROWS,
        )
    except Exception as exc:
        log("[увага] Дисплей не запустився:")
        log(str(exc))
        log(describe_scan(i2c))
        return None, NullDisplay()

    display = Lcd1602Display(lcd)
    display.message("Touch The Globe", "zapusk...")
    return lcd, display


def setup_speaker():
    """Аудіомодуль. Якщо його немає, залишається лише дисплей."""
    try:
        uart = make_uart(hardware_pins.DFPLAYER_TX, hardware_pins.DFPLAYER_RX)
    except PinError as exc:
        log("[увага] Піни DFPlayer у hardware_pins.py вказані неправильно:")
        log(str(exc))
        return NullSpeaker()

    try:
        player = DFPlayer(
            uart,
            volume=hardware_pins.DFPLAYER_VOLUME,
            folder=hardware_pins.DFPLAYER_FOLDER,
        )
    except Exception as exc:
        log("[увага] DFPlayer не відповів: " + str(exc))
        log("         Перевір дроти RX/TX (вони йдуть навхрест) і живлення 5V.")
        return NullSpeaker()

    return DFPlayerSpeaker(player)


def setup_buttons(engine, display):
    """Кнопки беруться з BUTTONS у student_code.py."""
    if not engine.buttons:
        log("[увага] У student_code.py словник BUTTONS порожній.")
        log("         Глобусу нічого опитувати - додай туди кнопки.")
        display.message("BUTTONS pustyi", "dyv. student_code")
        return None

    try:
        return ButtonPanel(
            sorted(engine.buttons.keys()),
            debounce_ms=hardware_pins.BUTTON_DEBOUNCE_MS,
        )
    except PinError as exc:
        log("[увага] У BUTTONS вказано пін, якого немає на платі:")
        log(str(exc))
        display.message("Pomylka pinu", "dyv. konsol")
        return None


def main():
    log("=== Touch The Globe ===")

    lcd, display = setup_display()

    try:
        catalog = load_catalog(COUNTRIES_DIR)
    except ContentError as exc:
        log("[помилка] Не вдалося прочитати країни:")
        log(str(exc))
        display.message("Nemae krain", "sync_board.py")
        return

    log("Країн знайдено: {}".format(len(catalog)))

    speaker = setup_speaker()
    hooks = load_student_code()

    engine = GlobeEngine(
        catalog=catalog,
        display=display,
        speaker=speaker,
        audio_source=TrackAudioSource(),
        hooks=hooks,
        on_warning=lambda message: log("[увага] " + message),
    )

    buttons = setup_buttons(engine, display)
    if buttons is None:
        return

    log("Кнопки: " + ", ".join(buttons.labels))
    display.message("Torkny krainu!", "")
    log("Готово. Натискай кнопки на глобусі.")

    while True:
        for label in buttons.pressed_now():
            log("Натиснуто {}".format(label))
            engine.press_pin(label)
        time.sleep_ms(POLL_INTERVAL_MS)


# Помилку показуємо і в консолі, і на дисплеї: інакше глобус просто
# "не працює" без жодного натяку, що саме сталося.
try:
    main()
except KeyboardInterrupt:
    print("Зупинено вручну.")
except Exception as error:
    print("[помилка] Глобус зупинився: {}: {}".format(type(error).__name__, error))
    raise
