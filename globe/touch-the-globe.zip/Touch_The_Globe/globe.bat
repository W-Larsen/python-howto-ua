@echo off
rem Команди глобуса для Windows. Запускати з папки проєкту:
rem     globe run          натискати кнопки з клавіатури
rem     globe press 1 2    ніби торкнулися кнопок 1 і 2 (q - вікторина, g - гра)
rem     globe test         перевірити свій код
rem     globe list         які країни є
chcp 65001 >nul
setlocal
cd /d "%~dp0"
set "PYTHONIOENCODING=utf-8"
set "PY="
py -3 --version >nul 2>&1 && set "PY=py -3"
if not defined PY (python --version >nul 2>&1 && set "PY=python")
if not defined PY goto nopython
if "%~1"=="" goto help
%PY% globe.py %*
exit /b %errorlevel%

:help
%PY% globe.py help
pause
exit /b 0

:nopython
echo Не знайдено Python.
echo Встанови його з https://www.python.org/downloads/
echo і під час встановлення постав галочку "Add python.exe to PATH".
pause
exit /b 1
